@echo off
setlocal EnableExtensions
chcp 65001 >nul

echo ============================================================
echo Local Color Fields Native HUD 2.5.28
echo Local Hue+Chroma Field + Independent Lightness Bar
echo ============================================================
echo.
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo ERROR: .NET Framework C# compiler was not found.
  echo Expected csc.exe under C:\Windows\Microsoft.NET\Framework...
  pause
  exit /b 1
)

set "ROOT=%~dp0"
set "SRC=%ROOT%Native"
set "BUILD=%ROOT%build"
set "OUT=%BUILD%\LocalColorFieldsNativeHUD.exe"
set "DEST=%APPDATA%\LocalColorFields\NativeHUD"
set "PSDIR=D:\PhotoShopCC2018\Adobe Photoshop CC 2018\Presets\Scripts"
set "PSSCRIPT=%PSDIR%\Local Color Fields Quick.jsx"
set "BACKUP=%APPDATA%\LocalColorFields\backup"

if not exist "%BUILD%" mkdir "%BUILD%"

echo Compiling native HUD...
"%CSC%" /nologo /target:winexe /optimize+ /platform:anycpu /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:Microsoft.CSharp.dll /out:"%OUT%" ^
  "%SRC%\ColorTypes.cs" ^
  "%SRC%\HudSettings.cs" ^
  "%SRC%\ColorMath.cs" ^
  "%SRC%\PhotoshopBridge.cs" ^
  "%SRC%\BrushDrag.cs" ^
  "%SRC%\HudForm.Core.cs" ^
  "%SRC%\HudForm.Hold.cs" ^
  "%SRC%\HudForm.Rendering.cs" ^
  "%SRC%\HudForm.Interaction.cs" ^
  "%SRC%\Program.cs"
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  pause
  exit /b 1
)

echo Build OK.
if not exist "%DEST%" mkdir "%DEST%"

echo Stopping every previous HUD process...
set /a STOP_TRIES=0
:stop_old_hud
tasklist /FI "IMAGENAME eq LocalColorFieldsNativeHUD.exe" 2>nul | find /I "LocalColorFieldsNativeHUD.exe" >nul
if errorlevel 1 goto old_hud_stopped
taskkill /IM LocalColorFieldsNativeHUD.exe /F >nul 2>&1
set /a STOP_TRIES+=1
if %STOP_TRIES% GEQ 8 (
  echo ERROR: Previous Native HUD process could not be stopped.
  echo Close Photoshop and run this installer again.
  pause
  exit /b 1
)
timeout /t 1 /nobreak >nul
goto stop_old_hud

:old_hud_stopped
rem Delete the installed EXE before copying. While it is absent, CEP cannot relaunch an old binary.
del /F /Q "%DEST%\LocalColorFieldsNativeHUD.exe" >nul 2>&1
if exist "%DEST%\LocalColorFieldsNativeHUD.exe" (
  echo ERROR: Old Native HUD EXE is still locked.
  echo Close Photoshop and run this installer again.
  pause
  exit /b 1
)

copy /Y "%OUT%" "%DEST%\LocalColorFieldsNativeHUD.exe" >nul
if errorlevel 1 (
  echo ERROR: Could not copy EXE to %DEST%
  pause
  exit /b 1
)
>"%DEST%\installed_version.txt" echo 2.5.28

if not exist "%BACKUP%" mkdir "%BACKUP%"
if exist "%PSSCRIPT%" copy /Y "%PSSCRIPT%" "%BACKUP%\Local Color Fields Quick_PreNative250_Backup.jsx" >nul

if not exist "%PSDIR%" (
  echo.
  echo WARNING: Photoshop Scripts folder was not found:
  echo %PSDIR%
  echo HUD installed, but Photoshop shortcut script was not copied.
  goto launch
)

copy /Y "%ROOT%Local Color Fields Quick.jsx" "%PSSCRIPT%" >nul
if errorlevel 1 (
  echo.
  echo WARNING: Could not update Photoshop shortcut script.
  echo Run this BAT as administrator and try again.
) else (
  echo Photoshop shortcut bridge installed.
)

:launch
echo.
tasklist /FI "IMAGENAME eq Photoshop.exe" 2>nul | find /I "Photoshop.exe" >nul
if not errorlevel 1 (
  echo Photoshop is running. Starting lifecycle-bound resident HUD...
  start "" "%DEST%\LocalColorFieldsNativeHUD.exe" --ensure-resident --follow-photoshop
) else (
  echo Photoshop is not running. HUD will start automatically with Photoshop.
)

echo.
echo Installed native HUD:
echo   %DEST%\LocalColorFieldsNativeHUD.exe
echo Installed version: 2.5.28
if exist "%DEST%\running_version.txt" (
  set /p RUNNING_VERSION=<"%DEST%\running_version.txt"
  echo Last running version: %RUNNING_VERSION%
)
echo.
echo 2.5.28 keeps the stable color HUD and adds direct brush Size/Opacity drag without Photoshop HUD.
echo The resident HUD now starts with Photoshop through CEP and exits automatically after Photoshop closes.
echo F11 uses the low-level keyboard hook; Native no longer calls Photoshop COM/DoJavaScript on hold down/up.
echo Hold key is fixed to F11. Brush Size/Opacity drag keys are configurable in CEP settings.
echo In F11 Hold mode, entering either field forcibly returns the OTHER field marker to its F11 Home position.
echo Marker UI is now one thin hollow white circle.
echo Runtime version can be verified in the tray menu or %DEST%\running_version.txt.
echo The hold HUD is fully click-through so Photoshop remains the pen input target.
echo.
pause
