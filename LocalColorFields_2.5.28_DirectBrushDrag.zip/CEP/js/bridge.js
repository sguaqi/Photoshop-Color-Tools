(function(){
"use strict";

// Photoshop scripting stays inside CEP. Native only exchanges tiny JSON state/command files,
// which keeps the keyboard/pointer hooks independent from Photoshop COM/DoJavaScript.
var fs=null,path=null;
try{fs=require("fs");path=require("path");}catch(e){}
if(!fs||!path||!window.__adobe_cep__||typeof window.__adobe_cep__.evalScript!=="function")return;

var root=path.join(process.env.APPDATA||"","LocalColorFields","CepBridge");
var statePath=path.join(root,"foreground_state.json");
var commandPath=path.join(root,"foreground_command.json");
var brushStatePath=path.join(root,"brush_state.json");
var brushCommandPath=path.join(root,"brush_command.json");
var leasePath=path.join(root,"bridge_owner.lock");
var owner=(typeof process!=="undefined"&&process.pid?String(process.pid):"cep")+"_"+Date.now()+"_"+Math.floor(Math.random()*1000000);
var ownsLease=false,evalBusy=false,lastReadAt=0,lastStateKey="",lastBrushStateKey="",lastLeaseTouch=0;
var lastBrushSize=-1,lastBrushOpacity=-1;
var readIntervalMs=90,leaseStaleMs=1200,leaseTouchMs=250;

function ensureDir(){
  try{
    var parent=path.dirname(root);
    if(!fs.existsSync(parent))fs.mkdirSync(parent);
    if(!fs.existsSync(root))fs.mkdirSync(root);
    return true;
  }catch(e){return false;}
}
function now(){return Date.now();}
function clampByte(v){v=Math.round(Number(v));if(!isFinite(v))v=0;return Math.max(0,Math.min(255,v));}
function clamp(v,a,b){v=Number(v);if(!isFinite(v))v=a;return Math.max(a,Math.min(b,v));}
function safeUnlink(p){try{if(fs.existsSync(p))fs.unlinkSync(p);}catch(e){}}
function releaseLease(){
  if(!ownsLease)return;
  try{if(fs.existsSync(leasePath)&&String(fs.readFileSync(leasePath,"utf8"))===owner)fs.unlinkSync(leasePath);}catch(e){}
  ownsLease=false;
}
function touchLease(){
  if(!ownsLease)return false;
  var t=now();if(t-lastLeaseTouch<leaseTouchMs)return true;lastLeaseTouch=t;
  try{fs.writeFileSync(leasePath,owner,"utf8");return true;}catch(e){ownsLease=false;return false;}
}
function createLease(){
  var fd=null;
  try{
    fd=fs.openSync(leasePath,"wx");fs.writeSync(fd,owner,0,"utf8");fs.closeSync(fd);fd=null;
    ownsLease=true;lastLeaseTouch=0;return touchLease();
  }catch(e){try{if(fd!==null)fs.closeSync(fd);}catch(ignore){}return false;}
}
function acquireLease(){
  if(!ensureDir())return false;
  if(ownsLease)return touchLease();
  if(createLease())return true;
  try{
    var st=fs.statSync(leasePath);
    if(now()-new Date(st.mtime).getTime()>leaseStaleMs){safeUnlink(leasePath);return createLease();}
  }catch(ignore){}
  return false;
}
function cepEval(script,done){
  try{window.__adobe_cep__.evalScript(script,function(result){done(String(result==null?"":result));});}
  catch(e){done("");}
}
function parseRgb(text){
  var m=String(text||"").match(/^\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*$/);
  return m?[clampByte(m[1]),clampByte(m[2]),clampByte(m[3])]:null;
}
function writeState(r,g,b,force){
  r=clampByte(r);g=clampByte(g);b=clampByte(b);
  var key=r+","+g+","+b;if(!force&&key===lastStateKey)return;
  try{fs.writeFileSync(statePath,JSON.stringify({r:r,g:g,b:b,updated:now()}),"utf8");lastStateKey=key;}catch(e){}
}
function writeBrushState(size,opacity,force){
  size=Number(size);opacity=Number(opacity);
  if(!isFinite(size)||size<=0||!isFinite(opacity)||opacity<=0)return;
  size=Math.round(size*10)/10;opacity=Math.round(opacity);
  var key=size+","+opacity;if(!force&&key===lastBrushStateKey)return;
  try{
    fs.writeFileSync(brushStatePath,JSON.stringify({size:size,opacity:opacity,updated:now()}),"utf8");
    lastBrushStateKey=key;lastBrushSize=size;lastBrushOpacity=opacity;
  }catch(e){}
}
function readColorCommand(){
  if(!fs.existsSync(commandPath))return null;
  try{
    var cmd=JSON.parse(fs.readFileSync(commandPath,"utf8"));
    if(!cmd||!isFinite(Number(cmd.serial)))return null;
    return {serial:Number(cmd.serial),r:clampByte(cmd.r),g:clampByte(cmd.g),b:clampByte(cmd.b)};
  }catch(e){return null;}
}
function readBrushCommand(){
  if(!fs.existsSync(brushCommandPath))return null;
  try{
    var cmd=JSON.parse(fs.readFileSync(brushCommandPath,"utf8"));
    var kind=String(cmd&&cmd.kind||"").toLowerCase(),value=Number(cmd&&cmd.value);
    if(!cmd||!isFinite(Number(cmd.serial))||(kind!=="size"&&kind!=="opacity")||!isFinite(value))return null;
    return {serial:Number(cmd.serial),kind:kind,value:value};
  }catch(e){return null;}
}
function applyPendingColorCommand(cmd){
  evalBusy=true;
  var script="(function(){try{var c=new SolidColor();c.rgb.red="+cmd.r+";c.rgb.green="+cmd.g+";c.rgb.blue="+cmd.b+";app.foregroundColor=c;return 'OK';}catch(e){return 'ERR';}})()";
  cepEval(script,function(result){
    evalBusy=false;
    if(result!=="OK")return;
    try{var current=readColorCommand();if(current&&current.serial===cmd.serial)safeUnlink(commandPath);}catch(ignore){}
    writeState(cmd.r,cmd.g,cmd.b,true);
  });
}
function applyPendingBrushCommand(cmd){
  evalBusy=true;
  var value=cmd.kind==="size"?clamp(cmd.value,1,5000):clamp(cmd.value,1,100);
  var script;
  if(cmd.kind==="size"){
    // masterDiameter changes the current brush size without replacing sampled/custom brush tips.
    script="(function(){try{var d=new ActionDescriptor();var r=new ActionReference();r.putEnumerated(charIDToTypeID('Brsh'),charIDToTypeID('Ordn'),charIDToTypeID('Trgt'));d.putReference(charIDToTypeID('null'),r);var b=new ActionDescriptor();b.putUnitDouble(stringIDToTypeID('masterDiameter'),charIDToTypeID('#Pxl'),"+value+");d.putObject(charIDToTypeID('T   '),charIDToTypeID('Brsh'),b);executeAction(charIDToTypeID('setd'),d,DialogModes.NO);return 'OK';}catch(e){return 'ERR';}})()";
  }else{
    // Paintbrush opacity is a tool option, not a brush-tip property.
    script="(function(){try{var d=new ActionDescriptor();var r=new ActionReference();r.putClass(charIDToTypeID('PbTl'));d.putReference(charIDToTypeID('null'),r);var o=new ActionDescriptor();o.putUnitDouble(charIDToTypeID('Opct'),charIDToTypeID('#Prc'),"+value+");d.putObject(charIDToTypeID('T   '),charIDToTypeID('null'),o);executeAction(charIDToTypeID('setd'),d,DialogModes.NO);return 'OK';}catch(e){return 'ERR';}})()";
  }
  cepEval(script,function(result){
    evalBusy=false;
    if(result!=="OK")return;
    try{var current=readBrushCommand();if(current&&current.serial===cmd.serial)safeUnlink(brushCommandPath);}catch(ignore){}
    if(cmd.kind==="size")lastBrushSize=value;else lastBrushOpacity=value;
    if(lastBrushSize>0&&lastBrushOpacity>0)writeBrushState(lastBrushSize,lastBrushOpacity,true);
  });
}
function readPhotoshopState(){
  evalBusy=true;lastReadAt=now();
  var script="(function(){try{var c=app.foregroundColor.rgb;var sz=-1,op=-1;try{var ar=new ActionReference();ar.putProperty(charIDToTypeID('Prpr'),stringIDToTypeID('tool'));ar.putEnumerated(charIDToTypeID('capp'),charIDToTypeID('Ordn'),charIDToTypeID('Trgt'));var ret=executeActionGet(ar);var opts=ret.getObjectValue(stringIDToTypeID('currentToolOptions'));var bid=stringIDToTypeID('brush');if(opts.hasKey(bid)){var br=opts.getObjectValue(bid);var did=stringIDToTypeID('diameter');if(br.hasKey(did)){try{sz=br.getUnitDoubleValue(did);}catch(e1){try{sz=br.getDouble(did);}catch(e2){}}}}var oid=stringIDToTypeID('opacity');if(opts.hasKey(oid)){try{op=opts.getInteger(oid);}catch(e3){try{op=opts.getUnitDoubleValue(oid);}catch(e4){try{op=opts.getDouble(oid);}catch(e5){}}}}}catch(ignore){}return Math.round(c.red)+','+Math.round(c.green)+','+Math.round(c.blue)+'|'+sz+'|'+op;}catch(e){return 'ERR';}})()";
  cepEval(script,function(result){
    evalBusy=false;
    var parts=String(result||"").split("|");
    if(parts.length!==3)return;
    var rgb=parseRgb(parts[0]);if(rgb)writeState(rgb[0],rgb[1],rgb[2],false);
    var sz=Number(parts[1]),op=Number(parts[2]);
    if(isFinite(sz)&&sz>0&&isFinite(op)&&op>0)writeBrushState(sz,op,false);
  });
}
function tick(){
  if(!acquireLease()||evalBusy)return;
  // Brush drag is latency-sensitive, so it always wins over color commits and idle polling.
  var brushCmd=readBrushCommand();if(brushCmd){applyPendingBrushCommand(brushCmd);return;}
  var colorCmd=readColorCommand();if(colorCmd){applyPendingColorCommand(colorCmd);return;}
  if(now()-lastReadAt>=readIntervalMs)readPhotoshopState();
}

ensureDir();
setTimeout(tick,30);
setInterval(tick,8);
try{window.addEventListener("beforeunload",releaseLease);}catch(e){}
})();
