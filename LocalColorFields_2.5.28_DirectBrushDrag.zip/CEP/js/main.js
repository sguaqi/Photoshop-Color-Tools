(function(){
"use strict";

var $=function(id){return document.getElementById(id);};
var fs=null,path=null,child=null,saveTimer=0,statusTimer=0;
try{fs=require("fs");path=require("path");child=require("child_process");}catch(e){}

var defaults={
  fieldSize:260,lightBarWidth:34,lightBarSide:"right",gap:10,cornerRadius:8,markerSize:12,cursorOffset:18,
  hueRange:45,chromaRange:8,chromaMin:0,chromaMax:35,
  lightnessRange:20,lightnessMin:5,lightnessMax:95,
  refreshAfterPick:true,closeOnPhotoshopClick:true,enableHoldF11:true,
  enableBrushDrag:true,brushSizeDragKey:"F9",brushOpacityDragKey:"F10",
  brushSizeDoublingPixels:140,brushOpacityFullRangePixels:320,brushDragDeadZone:2
};
var state={};

function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function num(v,fallback){v=Number(v);return isFinite(v)?v:fallback;}
function boolValue(v,fallback){return typeof v==="boolean"?v:fallback;}
function str(v,fallback){return typeof v==="string"&&v?v:fallback;}
function settingsPath(){return path?path.join(process.env.APPDATA||"","LocalColorFields","settings.json"):null;}

function load(){
  var raw={};
  try{
    var p=settingsPath();
    if(p&&fs&&fs.existsSync(p))raw=JSON.parse(fs.readFileSync(p,"utf8"))||{};
  }catch(e){raw={};}

  state.fieldSize=clamp(num(raw.fieldSize,num(raw.innerSize,num(raw.multiHeight,defaults.fieldSize))),120,620);
  state.lightBarWidth=clamp(num(raw.lightBarWidth,defaults.lightBarWidth),18,120);
  state.lightBarSide=/^left$/i.test(str(raw.lightBarSide,defaults.lightBarSide))?"left":"right";
  state.gap=clamp(num(raw.gap,defaults.gap),2,60);
  state.cornerRadius=clamp(num(raw.cornerRadius,defaults.cornerRadius),0,32);
  state.markerSize=clamp(num(raw.markerSize,defaults.markerSize),8,30);
  state.cursorOffset=clamp(num(raw.cursorOffset,defaults.cursorOffset),0,80);

  state.hueRange=clamp(num(raw.hueRange,num(raw.multiHueRange,defaults.hueRange)),5,180);
  state.chromaRange=clamp(num(raw.chromaRange,defaults.chromaRange),0.5,30);
  state.chromaMin=clamp(num(raw.chromaMin,defaults.chromaMin),0,59.5);
  state.chromaMax=clamp(num(raw.chromaMax,defaults.chromaMax),0.5,60);
  if(state.chromaMin>=state.chromaMax)state.chromaMin=Math.max(0,state.chromaMax-0.5);

  state.lightnessRange=clamp(num(raw.lightnessRange,num(raw.hlLRange,defaults.lightnessRange)),1,49.5);
  state.lightnessMin=clamp(num(raw.lightnessMin,num(raw.hlBlack,defaults.lightnessMin)),0,99);
  state.lightnessMax=clamp(num(raw.lightnessMax,num(raw.hlWhite,defaults.lightnessMax)),1,100);
  if(state.lightnessMin>=state.lightnessMax)state.lightnessMin=Math.max(0,state.lightnessMax-1);

  state.refreshAfterPick=boolValue(raw.refreshAfterPick,defaults.refreshAfterPick);
  state.closeOnPhotoshopClick=boolValue(raw.closeOnPhotoshopClick,defaults.closeOnPhotoshopClick);
  state.enableHoldF11=boolValue(raw.enableHoldF11,boolValue(raw.enableHoldF13,defaults.enableHoldF11));

  state.enableBrushDrag=boolValue(raw.enableBrushDrag,defaults.enableBrushDrag);
  state.brushSizeDragKey=str(raw.brushSizeDragKey,defaults.brushSizeDragKey);
  state.brushOpacityDragKey=str(raw.brushOpacityDragKey,defaults.brushOpacityDragKey);
  if(state.brushSizeDragKey===state.brushOpacityDragKey&&state.brushSizeDragKey!=="Off")state.brushOpacityDragKey=defaults.brushOpacityDragKey;
  state.brushSizeDoublingPixels=clamp(num(raw.brushSizeDoublingPixels,defaults.brushSizeDoublingPixels),40,600);
  state.brushOpacityFullRangePixels=clamp(num(raw.brushOpacityFullRangePixels,defaults.brushOpacityFullRangePixels),80,1000);
  state.brushDragDeadZone=clamp(num(raw.brushDragDeadZone,defaults.brushDragDeadZone),0,12);
}

function serializableState(){
  return {
    fieldSize:state.fieldSize,lightBarWidth:state.lightBarWidth,lightBarSide:state.lightBarSide,gap:state.gap,
    cornerRadius:state.cornerRadius,markerSize:state.markerSize,cursorOffset:state.cursorOffset,
    hueRange:state.hueRange,chromaRange:state.chromaRange,chromaMin:state.chromaMin,chromaMax:state.chromaMax,
    lightnessRange:state.lightnessRange,lightnessMin:state.lightnessMin,lightnessMax:state.lightnessMax,
    refreshAfterPick:state.refreshAfterPick,closeOnPhotoshopClick:state.closeOnPhotoshopClick,enableHoldF11:state.enableHoldF11,
    enableBrushDrag:state.enableBrushDrag,brushSizeDragKey:state.brushSizeDragKey,brushOpacityDragKey:state.brushOpacityDragKey,
    brushSizeDoublingPixels:state.brushSizeDoublingPixels,brushOpacityFullRangePixels:state.brushOpacityFullRangePixels,brushDragDeadZone:state.brushDragDeadZone
  };
}
function write(){
  if(!fs||!path)return false;
  try{
    var p=settingsPath(),dir=path.dirname(p);
    if(!fs.existsSync(dir))fs.mkdirSync(dir);
    fs.writeFileSync(p,JSON.stringify(serializableState(),null,2),"utf8");
    return true;
  }catch(e){setStatus("Save failed",true);return false;}
}
function setStatus(text,error){
  var box=$("saveState"),label=$("saveText");
  label.textContent=text;box.className="saveState "+(error?"error":"saved");
  clearTimeout(statusTimer);statusTimer=setTimeout(function(){box.className="saveState";},1300);
}
function scheduleSave(){
  clearTimeout(saveTimer);
  saveTimer=setTimeout(function(){if(write())setStatus("Saved · HUD updates automatically",false);},90);
}
function setPair(rangeId,numId,key,min,max,round){
  var r=$(rangeId),n=$(numId);
  function apply(v){
    v=clamp(num(v,state[key]),min,max);if(round)v=Math.round(v);
    state[key]=v;r.value=v;n.value=v;scheduleSave();
  }
  r.addEventListener("input",function(){apply(this.value);});
  n.addEventListener("input",function(){apply(this.value);});
  n.addEventListener("change",function(){apply(this.value);});
  r.value=state[key];n.value=state[key];
}
function normalizeBounds(changed){
  if(changed==="chromaMin"&&state.chromaMin>=state.chromaMax)state.chromaMin=Math.max(0,state.chromaMax-0.5);
  if(changed==="chromaMax"&&state.chromaMax<=state.chromaMin)state.chromaMax=Math.min(60,state.chromaMin+0.5);
  if(changed==="lightnessMin"&&state.lightnessMin>=state.lightnessMax)state.lightnessMin=Math.max(0,state.lightnessMax-1);
  if(changed==="lightnessMax"&&state.lightnessMax<=state.lightnessMin)state.lightnessMax=Math.min(100,state.lightnessMin+1);
}
function setNumber(id,key,min,max,round){
  var el=$(id);
  function apply(){
    var v=clamp(num(el.value,state[key]),min,max);if(round)v=Math.round(v);
    state[key]=v;normalizeBounds(key);el.value=state[key];
    if(key.indexOf("chroma")===0){$("chromaMin").value=state.chromaMin;$("chromaMax").value=state.chromaMax;}
    if(key.indexOf("lightness")===0){$("lightnessMin").value=state.lightnessMin;$("lightnessMax").value=state.lightnessMax;}
    scheduleSave();
  }
  el.value=state[key];el.addEventListener("input",apply);el.addEventListener("change",apply);
}
function setToggle(id,key){
  var el=$(id);el.checked=!!state[key];
  el.addEventListener("change",function(){state[key]=!!el.checked;scheduleSave();});
}

function setSelect(id,key){
  var el=$(id);el.value=state[key];
  el.addEventListener("change",function(){
    state[key]=el.value;
    if(state.brushSizeDragKey===state.brushOpacityDragKey&&state[key]!=="Off"){
      var other=key==="brushSizeDragKey"?"brushOpacityDragKey":"brushSizeDragKey";
      state[other]="Off";$(other).value="Off";
    }
    scheduleSave();
  });
}
function setLightBarSide(){
  var left=$("lightBarLeft"),right=$("lightBarRight");
  function renderSide(){left.className=state.lightBarSide==="left"?"active":"";right.className=state.lightBarSide==="right"?"active":"";}
  left.addEventListener("click",function(){state.lightBarSide="left";renderSide();scheduleSave();});
  right.addEventListener("click",function(){state.lightBarSide="right";renderSide();scheduleSave();});
  renderSide();
}
function render(){
  setPair("fieldSize","fieldSizeN","fieldSize",120,620,true);
  setPair("lightBarWidthR","lightBarWidth","lightBarWidth",18,120,true);
  setLightBarSide();
  setNumber("gap","gap",2,60,true);setNumber("cornerRadius","cornerRadius",0,32,true);
  setNumber("markerSize","markerSize",8,30,true);setNumber("cursorOffset","cursorOffset",0,80,true);

  setPair("hueRange","hueRangeN","hueRange",5,180,true);
  setPair("chromaRange","chromaRangeN","chromaRange",0.5,30,false);
  setNumber("chromaMin","chromaMin",0,59.5,false);setNumber("chromaMax","chromaMax",0.5,60,false);

  setPair("lightnessRange","lightnessRangeN","lightnessRange",1,49.5,false);
  setNumber("lightnessMin","lightnessMin",0,99,true);setNumber("lightnessMax","lightnessMax",1,100,true);

  setToggle("refreshAfterPick","refreshAfterPick");
  setToggle("closeOnPhotoshopClick","closeOnPhotoshopClick");
  setToggle("enableHoldF11","enableHoldF11");

  setToggle("enableBrushDrag","enableBrushDrag");
  setSelect("brushSizeDragKey","brushSizeDragKey");
  setSelect("brushOpacityDragKey","brushOpacityDragKey");
  setPair("brushSizeDoublingPixels","brushSizeDoublingPixelsN","brushSizeDoublingPixels",40,600,true);
  setPair("brushOpacityFullRangePixels","brushOpacityFullRangePixelsN","brushOpacityFullRangePixels",80,1000,true);
  setNumber("brushDragDeadZone","brushDragDeadZone",0,12,true);
}
function hudExePath(){return path?path.join(process.env.APPDATA||"","LocalColorFields","NativeHUD","LocalColorFieldsNativeHUD.exe"):null;}
function spawnHud(args){
  if(!child||!path||!fs)return false;
  try{
    var exe=hudExePath();if(!exe||!fs.existsSync(exe))return false;
    var p=child.spawn(exe,args||[],{detached:true,stdio:"ignore",windowsHide:true});p.unref();return true;
  }catch(e){return false;}
}
function ensureResidentHud(){spawnHud(["--ensure-resident","--follow-photoshop"]);}
function openHud(){
  if(write())setStatus("Saved",false);
  if(!child||!path){setStatus("Node access unavailable",true);return;}
  var exe=hudExePath();
  if(!exe||!fs||!fs.existsSync(exe)){setStatus("Native HUD is not installed",true);return;}
  if(!spawnHud([]))setStatus("Could not open HUD",true);
}
function reset(){state={};for(var k in defaults)if(defaults.hasOwnProperty(k))state[k]=defaults[k];write();location.reload();}

load();render();
$("openHud").addEventListener("click",openHud);
$("reset").addEventListener("click",reset);
setStatus("Settings ready",false);
setTimeout(ensureResidentHud,180);
})();