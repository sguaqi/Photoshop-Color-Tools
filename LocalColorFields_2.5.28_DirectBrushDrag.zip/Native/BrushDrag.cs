using System;
using System.Drawing;
using System.Windows.Forms;

namespace LocalColorFieldsNativeHUD
{
    internal sealed partial class HudForm
    {
        private enum BrushDragMode { None, Size, Opacity }

        private BrushDragMode brushDragMode = BrushDragMode.None;
        private Point brushDragStartPoint = Point.Empty;
        private Point brushDragLastPoint = Point.Empty;
        private double brushDragStartValue = 0.0;
        private double brushDragLastSentValue = Double.NaN;
        private DateTime brushDragLastSendUtc = DateTime.MinValue;
        private bool brushSizeKeyDown = false;
        private bool brushOpacityKeyDown = false;
        private int brushDragActiveVk = 0;

        private bool IsBrushDragActive { get { return brushDragMode != BrushDragMode.None; } }

        private bool TryHandleBrushDragHotkey(uint vkCode, bool isDown, bool isUp)
        {
            int sizeVk = VirtualKeyFromName(settings.BrushSizeDragKey);
            int opacityVk = VirtualKeyFromName(settings.BrushOpacityDragKey);

            // The active gesture release is matched against the VK captured at key-down, not the
            // current settings. Secondary brush keys pressed during a drag are swallowed as well so
            // Photoshop never sees an unmatched key-up.
            if (isUp)
            {
                if (brushDragActiveVk != 0 && vkCode == (uint)brushDragActiveVk)
                {
                    brushSizeKeyDown = false;
                    brushOpacityKeyDown = false;
                    brushDragActiveVk = 0;
                    try { BeginInvoke((System.Windows.Forms.MethodInvoker)delegate { EndBrushDrag(); }); } catch { }
                    return true;
                }
                if (brushSizeKeyDown && sizeVk > 0 && vkCode == (uint)sizeVk)
                {
                    brushSizeKeyDown = false;
                    return true;
                }
                if (brushOpacityKeyDown && opacityVk > 0 && vkCode == (uint)opacityVk)
                {
                    brushOpacityKeyDown = false;
                    return true;
                }
                return false;
            }

            if (!isDown || !settings.EnableBrushDrag || !IsPhotoshopForegroundWindow()) return false;

            if (sizeVk > 0 && vkCode == (uint)sizeVk)
            {
                if (!brushSizeKeyDown)
                {
                    brushSizeKeyDown = true;
                    if (brushDragActiveVk == 0)
                    {
                        brushDragActiveVk = sizeVk;
                        try { BeginInvoke((System.Windows.Forms.MethodInvoker)delegate { BeginBrushDrag(BrushDragMode.Size); }); } catch { }
                    }
                }
                return true;
            }

            if (opacityVk > 0 && vkCode == (uint)opacityVk)
            {
                if (!brushOpacityKeyDown)
                {
                    brushOpacityKeyDown = true;
                    if (brushDragActiveVk == 0)
                    {
                        brushDragActiveVk = opacityVk;
                        try { BeginInvoke((System.Windows.Forms.MethodInvoker)delegate { BeginBrushDrag(BrushDragMode.Opacity); }); } catch { }
                    }
                }
                return true;
            }

            return false;
        }

        private void BeginBrushDrag(BrushDragMode mode)
        {
            if (!settings.EnableBrushDrag || mode == BrushDragMode.None) return;
            if (hudMode == HudMode.Hold) return;

            BrushState state;
            string error;
            if (!PhotoshopBridge.TryGetBrushState(out state, out error))
            {
                brushDragMode = BrushDragMode.None;
                return;
            }

            double start = mode == BrushDragMode.Size ? state.Size : state.Opacity;
            if (Double.IsNaN(start) || Double.IsInfinity(start) || start <= 0.0)
            {
                brushDragMode = BrushDragMode.None;
                return;
            }

            brushDragMode = mode;
            brushDragStartPoint = Cursor.Position;
            brushDragLastPoint = brushDragStartPoint;
            brushDragStartValue = start;
            brushDragLastSentValue = start;
            brushDragLastSendUtc = DateTime.MinValue;
        }

        private void EndBrushDrag()
        {
            brushDragMode = BrushDragMode.None;
            brushDragStartPoint = Point.Empty;
            brushDragLastPoint = Point.Empty;
            brushDragStartValue = 0.0;
            brushDragLastSentValue = Double.NaN;
            brushDragLastSendUtc = DateTime.MinValue;
        }

        private void ProcessBrushDrag()
        {
            if (!IsBrushDragActive) return;
            if (!settings.EnableBrushDrag)
            {
                EndBrushDrag();
                return;
            }

            Point p = Cursor.Position;
            if (p == brushDragLastPoint) return;
            brushDragLastPoint = p;

            int dx = p.X - brushDragStartPoint.X;
            int dead = Math.Max(0, settings.BrushDragDeadZone);
            if (Math.Abs(dx) <= dead) dx = 0;
            else dx = dx > 0 ? dx - dead : dx + dead;

            double target;
            if (brushDragMode == BrushDragMode.Size)
            {
                double travel = Math.Max(30.0, settings.BrushSizeDoublingPixels);
                target = brushDragStartValue * Math.Pow(2.0, dx / travel);
                target = Math.Max(1.0, Math.Min(5000.0, target));
                target = Math.Round(target, 1);
            }
            else
            {
                double travel = Math.Max(60.0, settings.BrushOpacityFullRangePixels);
                target = brushDragStartValue + dx * 100.0 / travel;
                target = Math.Max(1.0, Math.Min(100.0, target));
                target = Math.Round(target);
            }

            if (!Double.IsNaN(brushDragLastSentValue) && Math.Abs(target - brushDragLastSentValue) < 0.0001) return;

            // Keep only the latest value and cap native file writes to roughly 120 Hz. CEP also
            // coalesces commands while Photoshop is busy, so pointer input never queues behind scripts.
            DateTime now = DateTime.UtcNow;
            if (brushDragLastSendUtc != DateTime.MinValue && (now - brushDragLastSendUtc).TotalMilliseconds < 8.0) return;

            string error;
            bool ok;
            if (brushDragMode == BrushDragMode.Size)
                ok = PhotoshopBridge.TrySetBrushSize(target, out error);
            else
                ok = PhotoshopBridge.TrySetBrushOpacity(target, out error);
            if (ok)
            {
                brushDragLastSentValue = target;
                brushDragLastSendUtc = now;
            }
        }

        private static int VirtualKeyFromName(string name)
        {
            if (String.IsNullOrEmpty(name)) return 0;
            string n = name.Trim().ToUpperInvariant().Replace(" ", "").Replace("_", "");
            if (n == "OFF" || n == "NONE") return 0;
            if (n.Length >= 2 && n[0] == 'F')
            {
                int f;
                if (Int32.TryParse(n.Substring(1), out f) && f >= 1 && f <= 24) return 0x70 + (f - 1);
            }
            if (n == "PAUSE") return 0x13;
            if (n == "SCROLLLOCK" || n == "SCROLL") return 0x91;
            if (n == "INSERT" || n == "INS") return 0x2D;
            if (n == "HOME") return 0x24;
            if (n == "END") return 0x23;
            if (n == "PAGEUP" || n == "PGUP") return 0x21;
            if (n == "PAGEDOWN" || n == "PGDN") return 0x22;
            return 0;
        }
    }
}
