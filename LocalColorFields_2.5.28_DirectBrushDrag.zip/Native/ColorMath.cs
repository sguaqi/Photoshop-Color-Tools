using System;

namespace LocalColorFieldsNativeHUD
{
    internal static class ColorMath
    {

        public static double Clamp(double v, double lo, double hi) { return Math.Max(lo, Math.Min(hi, v)); }
        public static double WrapHue(double h) { h %= 360.0; if (h < 0) h += 360.0; return h; }

        private static double SrgbToLinear(double v)
        {
            v /= 255.0;
            return v <= 0.04045 ? v / 12.92 : Math.Pow((v + 0.055) / 1.055, 2.4);
        }

        private static double LinearToSrgb(double v)
        {
            v = v <= 0.0031308 ? 12.92 * v : 1.055 * Math.Pow(v, 1.0 / 2.4) - 0.055;
            return 255.0 * v;
        }

        private static double Cbrt(double v)
        {
            if (v < 0) return -Math.Pow(-v, 1.0 / 3.0);
            return Math.Pow(v, 1.0 / 3.0);
        }

        public static LchColor RgbToLch(RgbColor rgb)
        {
            double R = SrgbToLinear(rgb.R), G = SrgbToLinear(rgb.G), B = SrgbToLinear(rgb.B);
            double l = 0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B;
            double m = 0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B;
            double s = 0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B;
            double ll = Cbrt(l), mm = Cbrt(m), ss = Cbrt(s);
            double L = 0.2104542553 * ll + 0.7936177850 * mm - 0.0040720468 * ss;
            double a = 1.9779984951 * ll - 2.4285922050 * mm + 0.4505937099 * ss;
            double bb = 0.0259040371 * ll + 0.7827717662 * mm - 0.8086757660 * ss;
            double C = Math.Sqrt(a * a + bb * bb);
            double h = Math.Atan2(bb, a) * 180.0 / Math.PI;
            if (h < 0) h += 360.0;
            return new LchColor(L * 100.0, C * 100.0, h);
        }

        private static void OklchToRawRgb(double L100, double C100, double cosH, double sinH, out double r, out double g, out double b)
        {
            double L = L100 / 100.0, C = C100 / 100.0;
            double a = C * cosH, bb = C * sinH;
            double ll = L + 0.3963377774 * a + 0.2158037573 * bb;
            double mm = L - 0.1055613458 * a - 0.0638541728 * bb;
            double ss = L - 0.0894841775 * a - 1.2914855480 * bb;
            double l = ll * ll * ll, m = mm * mm * mm, ss3 = ss * ss * ss;
            r = LinearToSrgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * ss3);
            g = LinearToSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * ss3);
            b = LinearToSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * ss3);
        }

        private static bool InGamut(double r, double g, double b)
        {
            return !Double.IsNaN(r) && !Double.IsNaN(g) && !Double.IsNaN(b) &&
                   !Double.IsInfinity(r) && !Double.IsInfinity(g) && !Double.IsInfinity(b) &&
                   r >= 0 && r <= 255 && g >= 0 && g <= 255 && b >= 0 && b <= 255;
        }

        public static RgbColor LchToRgb(double L, double C, double h, int iterations)
        {
            double rad = WrapHue(h) * Math.PI / 180.0;
            return LchToRgbWithDirection(L, C, Math.Cos(rad), Math.Sin(rad), iterations);
        }

        public static RgbColor LchToRgbWithDirection(double L, double C, double cosH, double sinH, int iterations)
        {
            L = Clamp(L, 0, 100); C = Math.Max(0, C);
            double r, g, b;
            OklchToRawRgb(L, C, cosH, sinH, out r, out g, out b);
            if (InGamut(r, g, b)) return new RgbColor((int)Math.Round(r), (int)Math.Round(g), (int)Math.Round(b));
            double low = 0, high = C, best = 0;
            for (int i = 0; i < iterations; i++)
            {
                double mid = (low + high) * 0.5;
                OklchToRawRgb(L, mid, cosH, sinH, out r, out g, out b);
                if (InGamut(r, g, b)) { best = mid; low = mid; } else high = mid;
            }
            OklchToRawRgb(L, best, cosH, sinH, out r, out g, out b);
            return new RgbColor((int)Math.Round(Clamp(r, 0, 255)), (int)Math.Round(Clamp(g, 0, 255)), (int)Math.Round(Clamp(b, 0, 255)));
        }

    }
}
