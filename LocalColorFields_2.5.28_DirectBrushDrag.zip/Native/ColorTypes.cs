namespace LocalColorFieldsNativeHUD
{
internal struct RgbColor
    {
        public int R;
        public int G;
        public int B;
        public RgbColor(int r, int g, int b) { R = r; G = g; B = b; }
    }

internal struct BrushState
    {
        public double Size;
        public double Opacity;
        public BrushState(double size, double opacity) { Size = size; Opacity = opacity; }
    }

internal struct LchColor
    {
        public double L;
        public double C;
        public double H;
        public LchColor(double l, double c, double h) { L = l; C = c; H = h; }
    }
}
