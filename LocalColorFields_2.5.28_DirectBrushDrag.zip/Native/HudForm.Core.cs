using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace LocalColorFieldsNativeHUD
{
    internal sealed partial class HudForm : Form
    {

        private const int WM_TOGGLE_PERSISTENT = 0x8000 + 421;
        private const int WM_ENABLE_PHOTOSHOP_FOLLOW = 0x8000 + 422;
        private const int VK_LBUTTON = 0x01;
        private const int HOLD_KEY_VK = 0x7A; // F11
        private const int WS_EX_TOOLWINDOW = 0x00000080;
        private const int WS_EX_LAYERED = 0x00080000;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WS_EX_TRANSPARENT = 0x00000020;
        private const int GWL_EXSTYLE = -20;
        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOMOVE = 0x0002;
        private const uint SWP_NOZORDER = 0x0004;
        private const uint SWP_NOACTIVATE = 0x0010;
        private const uint SWP_FRAMECHANGED = 0x0020;
        private const int WM_NCHITTEST = 0x0084;
        private const int WM_SETCURSOR = 0x0020;
        private const int WM_MOUSEACTIVATE = 0x0021;
        private const int WM_MOUSEMOVE = 0x0200;
        private const int WM_LBUTTONUP = 0x0202;
        private const int MA_NOACTIVATE = 3;
        private const int WH_MOUSE_LL = 14;
        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_KEYUP = 0x0101;
        private const int WM_SYSKEYDOWN = 0x0104;
        private const int WM_SYSKEYUP = 0x0105;
        private const int HTCLIENT = 1;
        private const int HTTRANSPARENT = -1;
        private const int ULW_ALPHA = 0x00000002;
        private const byte AC_SRC_OVER = 0x00;
        private const byte AC_SRC_ALPHA = 0x01;
        internal const string HostWindowTitle = "LCF_NATIVE_HUD_HOST";
        internal const string BuildVersion = "2.5.28";

        [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int vKey);
        [DllImport("user32.dll")] private static extern IntPtr WindowFromPoint(NativePoint point);
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
        [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("user32.dll", SetLastError = true)] private static extern bool UpdateLayeredWindow(
            IntPtr hwnd, IntPtr hdcDst, ref NativePoint pptDst, ref NativeSize psize,
            IntPtr hdcSrc, ref NativePoint pptSrc, int crKey, ref BlendFunction pblend, int dwFlags);
        [DllImport("gdi32.dll")] private static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        [DllImport("gdi32.dll")] private static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll")] private static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);
        [DllImport("gdi32.dll")] private static extern bool DeleteObject(IntPtr hObject);
        [DllImport("user32.dll", SetLastError = true)] private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll", EntryPoint = "SetWindowsHookEx", SetLastError = true)] private static extern IntPtr SetWindowsKeyboardHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll", SetLastError = true)] private static extern bool UnhookWindowsHookEx(IntPtr hhk);
        [DllImport("user32.dll")] private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr GetModuleHandle(string lpModuleName);
        [DllImport("user32.dll", SetLastError = true)] private static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        [DllImport("user32.dll", SetLastError = true)] private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
        [DllImport("user32.dll", SetLastError = true)] private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        private HudSettings settings = new HudSettings();
        private LchColor baseLch = new LchColor(53.6, 0, 0);
        private Bitmap colorBitmap;
        private Bitmap lightBitmap;
        private Bitmap staticSurfaceBitmap;
        private Bitmap frameSurfaceBitmap;
        private Graphics frameSurfaceGraphics;

        private Rectangle colorRect;
        private Rectangle lightRect;
        private float colorCornerRadius;
        private float lightCornerRadius;

        // Sliding local windows. They follow the selected color while possible,
        // then stop at the user-defined min/max boundary. Hue always follows.
        private double chromaWindowCenter = 8.0;
        private double lightnessWindowCenter = 50.0;

        private Point colorMarker = Point.Empty;
        private Point lightMarker = Point.Empty;

        // Hold-mode home positions captured when F11 opens the picker.
        // When the cursor crosses between fields, the field it leaves returns here.
        private Point holdColorHomeMarker = Point.Empty;
        private Point holdLightHomeMarker = Point.Empty;
        private bool holdFieldKnown = false;
        private ActiveField holdField = ActiveField.Color;

        private bool dragging = false;
        private ActiveField activeField = ActiveField.Color;

        // Persistent mode can track drag globally; Hold mode only reads Cursor.Position.
        private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);
        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
        private readonly object passiveInputGate = new object();
        private LowLevelMouseProc passiveMouseProc;
        private IntPtr passiveMouseHook = IntPtr.Zero;
        private bool passiveTracking = false;
        private bool fallbackCapture = false;
        private bool passiveMovePending = false;
        private bool passiveUpPending = false;
        private Point passiveScreenPoint = Point.Empty;

        // Low-level F11 hook with GetAsyncKeyState fallback.
        private LowLevelKeyboardProc keyboardProc;
        private IntPtr keyboardHook = IntPtr.Zero;
        private bool holdKeyDown = false;

        // Hold surface is prebuilt while hidden for fast F11 response.
        private bool holdSurfacePrepared = false;
        private DateTime deferredPrewarmUtc = DateTime.MinValue;
        private bool hasLastSourceRgb = false;
        private RgbColor lastSourceRgb = new RgbColor(128, 128, 128);
        private int foregroundSyncSerial = 0;

        // Hold-hover selection state. No mouse/pen down is accepted in Hold mode.
        private bool holdHasCandidate = false;
        private RgbColor holdCandidate = new RgbColor(0, 0, 0);
        private Point holdLastScreenPoint = Point.Empty;
        private bool holdClickThroughApplied = false;

        private NotifyIcon tray;
        private bool lastPsErrorShown = false;

        // Photoshop lifecycle binding. When the HUD is launched by the CEP panel with
        // --follow-photoshop it stays resident only while Photoshop is alive.
        // This prevents orphan HUD processes after Photoshop exits or crashes.
        private bool followPhotoshopLifecycle;
        private bool photoshopHostSeen = false;
        private DateTime photoshopStartupDeadlineUtc = DateTime.MinValue;
        private DateTime photoshopMissingSinceUtc = DateTime.MinValue;
        private DateTime nextPhotoshopLifecycleCheckUtc = DateTime.MinValue;

        private System.Windows.Forms.Timer inputTimer;
        private bool holdWasDown = false;
        private bool leftWasDown = false;
        private DateTime shownAtUtc = DateTime.MinValue;
        private DateTime settingsWriteTimeUtc = DateTime.MinValue;
        private DateTime nextSettingsCheckUtc = DateTime.MinValue;

        private enum HudMode { Hidden, Persistent, Hold }
        private enum ActiveField { Color, Lightness }
        private HudMode hudMode = HudMode.Hidden;

        [StructLayout(LayoutKind.Sequential)]
        private struct NativePoint
        {
            public int X;
            public int Y;
            public NativePoint(int x, int y) { X = x; Y = y; }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct NativeSize
        {
            public int CX;
            public int CY;
            public NativeSize(int cx, int cy) { CX = cx; CY = cy; }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct HookPoint
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MsLlHookStruct
        {
            public HookPoint Point;
            public uint MouseData;
            public uint Flags;
            public uint Time;
            public UIntPtr ExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct KbdLlHookStruct
        {
            public uint VkCode;
            public uint ScanCode;
            public uint Flags;
            public uint Time;
            public UIntPtr ExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct BlendFunction
        {
            public byte BlendOp;
            public byte BlendFlags;
            public byte SourceConstantAlpha;
            public byte AlphaFormat;
        }

        private struct AxisWindow
        {
            public double Center;
            public double Half;
            public double High;
            public double Low;
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_NOACTIVATE;
                return cp;
            }
        }

        public HudForm(bool followPhotoshop)
        {
            settings = HudSettings.Load();
            settingsWriteTimeUtc = HudSettings.SettingsWriteTimeUtc();
            followPhotoshopLifecycle = followPhotoshop;
            if (followPhotoshopLifecycle)
            {
                photoshopHostSeen = IsPhotoshopProcessRunning();
                photoshopStartupDeadlineUtc = DateTime.UtcNow.AddSeconds(10);
                nextPhotoshopLifecycleCheckUtc = DateTime.UtcNow;
            }

            Text = HostWindowTitle;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            BackColor = Color.FromArgb(28, 28, 30);
            DoubleBuffered = true;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
            Cursor = Cursors.Cross;
            passiveMouseProc = PassiveMouseHookProc;
            keyboardProc = KeyboardHookProc;

            ContextMenuStrip menu = new ContextMenuStrip();
            ToolStripMenuItem versionItem = new ToolStripMenuItem("Version " + BuildVersion);
            versionItem.Enabled = false;
            menu.Items.Add(versionItem);
            menu.Items.Add(new ToolStripSeparator());
            ToolStripMenuItem showItem = new ToolStripMenuItem("Show HUD");
            showItem.Click += delegate { TogglePersistentHud(); };
            ToolStripMenuItem reloadItem = new ToolStripMenuItem("Reload settings");
            reloadItem.Click += delegate
            {
                settings = HudSettings.Load();
                settingsWriteTimeUtc = HudSettings.SettingsWriteTimeUtc();
                if (!settings.EnableBrushDrag && IsBrushDragActive) EndBrushDrag();
                if (Visible) ApplySettingsLive();
            };
            ToolStripMenuItem exitItem = new ToolStripMenuItem("Exit");
            exitItem.Click += delegate { Close(); };
            menu.Items.Add(showItem);
            menu.Items.Add(reloadItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(exitItem);

            tray = new NotifyIcon();
            tray.Icon = SystemIcons.Application;
            tray.Text = "Local Color Fields HUD " + BuildVersion;
            tray.Visible = true;
            tray.ContextMenuStrip = menu;
            tray.DoubleClick += delegate { TogglePersistentHud(); };

            try
            {
                string runtimeDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "LocalColorFields", "NativeHUD");
                Directory.CreateDirectory(runtimeDir);
                File.WriteAllText(Path.Combine(runtimeDir, "running_version.txt"), BuildVersion);
            }
            catch { }

            inputTimer = new System.Windows.Forms.Timer();
            inputTimer.Interval = 15;
            inputTimer.Tick += InputTimerTick;
            inputTimer.Start();

            MouseDown += HudMouseDown;
            MouseMove += HudMouseMove;
            MouseUp += HudMouseUp;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            InstallKeyboardHook();
        }

        private void InstallKeyboardHook()
        {
            if (keyboardHook != IntPtr.Zero || keyboardProc == null) return;
            try
            {
                IntPtr module = GetModuleHandle(null);
                keyboardHook = SetWindowsKeyboardHookEx(WH_KEYBOARD_LL, keyboardProc, module, 0);
            }
            catch { keyboardHook = IntPtr.Zero; }
        }

        private void RemoveKeyboardHook()
        {
            if (keyboardHook == IntPtr.Zero) return;
            try { UnhookWindowsHookEx(keyboardHook); } catch { }
            keyboardHook = IntPtr.Zero;
        }

        private bool IsPhotoshopForegroundWindow()
        {
            try
            {
                IntPtr hwnd = GetForegroundWindow();
                if (hwnd == IntPtr.Zero) return false;
                uint pid;
                GetWindowThreadProcessId(hwnd, out pid);
                if (pid == 0) return false;
                using (Process p = Process.GetProcessById((int)pid))
                    return p.ProcessName.StartsWith("Photoshop", StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        private static bool IsPhotoshopProcessRunning()
        {
            Process[] list = null;
            try
            {
                list = Process.GetProcessesByName("Photoshop");
                int sessionId = Process.GetCurrentProcess().SessionId;
                for (int i = 0; i < list.Length; i++)
                {
                    try
                    {
                        if (!list[i].HasExited && list[i].SessionId == sessionId) return true;
                    }
                    catch { }
                }
            }
            catch { }
            finally
            {
                if (list != null)
                {
                    for (int i = 0; i < list.Length; i++)
                    {
                        try { list[i].Dispose(); } catch { }
                    }
                }
            }
            return false;
        }

        private void CheckPhotoshopLifecycle()
        {
            if (!followPhotoshopLifecycle) return;

            DateTime now = DateTime.UtcNow;
            if (now < nextPhotoshopLifecycleCheckUtc) return;
            nextPhotoshopLifecycleCheckUtc = now.AddMilliseconds(400);

            bool running = IsPhotoshopProcessRunning();
            if (running)
            {
                photoshopHostSeen = true;
                photoshopMissingSinceUtc = DateTime.MinValue;
                return;
            }

            // During startup give Photoshop/CEP a generous grace period. Once the host has
            // been observed, only a short debounce is needed to avoid an orphan process.
            if (!photoshopHostSeen)
            {
                if (photoshopStartupDeadlineUtc != DateTime.MinValue && now < photoshopStartupDeadlineUtc) return;
                Close();
                return;
            }

            if (photoshopMissingSinceUtc == DateTime.MinValue)
            {
                photoshopMissingSinceUtc = now;
                return;
            }

            if ((now - photoshopMissingSinceUtc).TotalMilliseconds >= 900)
            {
                Close();
            }
        }

        private IntPtr KeyboardHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                try
                {
                    KbdLlHookStruct data = (KbdLlHookStruct)Marshal.PtrToStructure(lParam, typeof(KbdLlHookStruct));
                    int msg = wParam.ToInt32();
                    bool isDown = msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN;
                    bool isUp = msg == WM_KEYUP || msg == WM_SYSKEYUP;

                    // Direct brush-parameter drag has priority over ordinary Photoshop shortcuts.
                    // It is device-agnostic by design; the keypad should map its chosen physical keys
                    // to otherwise-unused virtual keys such as F9/F10.
                    if (TryHandleBrushDragHotkey(data.VkCode, isDown, isUp))
                        return new IntPtr(1);

                    if (settings.EnableHoldShortcut && data.VkCode == (uint)HOLD_KEY_VK)
                    {
                        // Once a hold gesture starts, always consume its matching key-up even if focus moves.
                        if ((isDown && IsPhotoshopForegroundWindow()) || (isUp && holdKeyDown))
                        {
                            if (isDown && !holdKeyDown)
                            {
                                holdKeyDown = true;
                                try { BeginInvoke((MethodInvoker)delegate { BeginHoldHoverFast(); }); } catch { }
                            }
                            else if (isUp && holdKeyDown)
                            {
                                holdKeyDown = false;
                                try { BeginInvoke((MethodInvoker)delegate { FinishHoldHoverSelection(); }); } catch { }
                            }

                            return new IntPtr(1);
                        }
                    }
                }
                catch { }
            }
            return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
        }

        protected override void WndProc(ref Message m)
        {
            // Hold mode is pointer-passive. When the layered HUD appears underneath the pen cursor,
            // WinForms would otherwise briefly apply this Form's Cross cursor before Photoshop
            // restores its brush/pen cursor. Swallow WM_SETCURSOR so the OS keeps the current
            // Photoshop cursor unchanged for the entire hold gesture.
            if (m.Msg == WM_SETCURSOR && hudMode == HudMode.Hold)
            {
                m.Result = new IntPtr(1);
                return;
            }

            if (m.Msg == WM_MOUSEACTIVATE)
            {
                m.Result = new IntPtr(MA_NOACTIVATE);
                return;
            }

            if (m.Msg == WM_TOGGLE_PERSISTENT)
            {
                TogglePersistentHud();
                return;
            }

            if (m.Msg == WM_ENABLE_PHOTOSHOP_FOLLOW)
            {
                EnablePhotoshopLifecycleFollow();
                return;
            }

            if (m.Msg == WM_NCHITTEST)
            {
                // Hold mode is the pressure-safe pen path. The HUD is display-only and must never
                // become the pointer target; Photoshop remains the owner of pen down/up messages.
                if (hudMode == HudMode.Hold)
                {
                    m.Result = new IntPtr(HTTRANSPARENT);
                    return;
                }

                long raw = m.LParam.ToInt64();
                int sx = unchecked((short)(raw & 0xFFFF));
                int sy = unchecked((short)((raw >> 16) & 0xFFFF));
                Point client = PointToClient(new Point(sx, sy));
                if (IsPointInColor(client) || IsPointInLightness(client))
                    m.Result = new IntPtr(HTCLIENT);
                else
                    m.Result = new IntPtr(HTTRANSPARENT);
                return;
            }

            base.WndProc(ref m);
        }

        public static int TogglePersistentMessageId { get { return WM_TOGGLE_PERSISTENT; } }
        public static int EnablePhotoshopFollowMessageId { get { return WM_ENABLE_PHOTOSHOP_FOLLOW; } }

        private void EnablePhotoshopLifecycleFollow()
        {
            followPhotoshopLifecycle = true;
            photoshopHostSeen = IsPhotoshopProcessRunning();
            photoshopStartupDeadlineUtc = DateTime.UtcNow.AddSeconds(10);
            photoshopMissingSinceUtc = DateTime.MinValue;
            nextPhotoshopLifecycleCheckUtc = DateTime.UtcNow;
        }
    }
}
