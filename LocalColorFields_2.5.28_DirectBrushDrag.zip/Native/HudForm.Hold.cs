using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LocalColorFieldsNativeHUD
{
    internal sealed partial class HudForm
    {
        private void InputTimerTick(object sender, EventArgs e)
        {
            CheckPhotoshopLifecycle();
            if (IsDisposed || Disposing) return;

            ProcessPassiveInput();
            ProcessBrushDrag();

            bool fallbackHoldDown = keyboardHook == IntPtr.Zero && settings.EnableHoldShortcut && (GetAsyncKeyState(HOLD_KEY_VK) & 0x8000) != 0;
            bool holdDownNow = keyboardHook != IntPtr.Zero ? holdKeyDown : fallbackHoldDown;
            if (inputTimer != null)
                inputTimer.Interval = (dragging && passiveTracking) || (hudMode == HudMode.Hold && holdDownNow) || IsBrushDragActive ? 5 : 15;

            if (hudMode == HudMode.Hidden && deferredPrewarmUtc != DateTime.MinValue && DateTime.UtcNow >= deferredPrewarmUtc)
            {
                deferredPrewarmUtc = DateTime.MinValue;
                PrepareHoldSurface(false);
            }

            if (DateTime.UtcNow >= nextSettingsCheckUtc)
            {
                nextSettingsCheckUtc = DateTime.UtcNow.AddMilliseconds(220);
                DateTime wt = HudSettings.SettingsWriteTimeUtc();
                if (wt != settingsWriteTimeUtc)
                {
                    settings = HudSettings.Load();
                    settingsWriteTimeUtc = wt;
                    if (!settings.EnableBrushDrag && IsBrushDragActive) EndBrushDrag();
                    if (Visible) ApplySettingsLive();
                    else
                    {
                        holdSurfacePrepared = false;
                        deferredPrewarmUtc = DateTime.UtcNow.AddMilliseconds(40);
                    }
                }
            }

            // Timer fallback only. Normally the low-level keyboard hook starts/finishes Hold mode instantly.
            if (keyboardHook == IntPtr.Zero)
            {
                if (fallbackHoldDown && !holdWasDown)
                {
                    holdKeyDown = true;
                    BeginHoldHoverFast();
                }
                else if (!fallbackHoldDown && holdWasDown && hudMode == HudMode.Hold)
                {
                    holdKeyDown = false;
                    FinishHoldHoverSelection();
                }
                holdWasDown = fallbackHoldDown;
            }

            if (holdDownNow && hudMode == HudMode.Hold && Visible)
                ProcessHoldHoverSelection();

            bool leftDown = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
            if (settings.CloseOnPhotoshopClick && leftDown && !leftWasDown && Visible && hudMode == HudMode.Persistent)
            {
                if ((DateTime.UtcNow - shownAtUtc).TotalMilliseconds > 120)
                {
                    Point screenPoint = Cursor.Position;
                    if (!IsPointOnHud(screenPoint) && IsPhotoshopAt(screenPoint))
                        HideHud();
                }
            }
            leftWasDown = leftDown;
        }

        private void ApplyHoldClickThrough(bool enabled)
        {
            if (!IsHandleCreated) return;
            if (holdClickThroughApplied == enabled) return;
            try
            {
                int ex = GetWindowLong(Handle, GWL_EXSTYLE);
                int desired = enabled ? (ex | WS_EX_TRANSPARENT) : (ex & ~WS_EX_TRANSPARENT);
                if (desired != ex)
                {
                    SetWindowLong(Handle, GWL_EXSTYLE, desired);
                    SetWindowPos(Handle, IntPtr.Zero, 0, 0, 0, 0,
                        SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
                }
                holdClickThroughApplied = enabled;
            }
            catch
            {
                // WM_NCHITTEST still returns HTTRANSPARENT in Hold mode as a second safety layer.
                holdClickThroughApplied = enabled;
            }
        }

        private void ResetHoldHoverSelection()
        {
            holdHasCandidate = false;
            holdLastScreenPoint = Point.Empty;
            holdFieldKnown = false;
            holdField = ActiveField.Color;
        }

        private void CaptureHoldMarkerHomes()
        {
            holdColorHomeMarker = colorMarker;
            holdLightHomeMarker = lightMarker;
        }

        private bool ResetInactiveMarkerFor(ActiveField enteredField)
        {
            // Hold mode has two independent visual markers. Entering one field always restores
            // the other marker to the position captured when F11 opened the picker.
            if (enteredField == ActiveField.Color)
            {
                if (holdLightHomeMarker == Point.Empty || lightMarker == holdLightHomeMarker) return false;
                lightMarker = holdLightHomeMarker;
                return true;
            }

            if (holdColorHomeMarker == Point.Empty || colorMarker == holdColorHomeMarker) return false;
            colorMarker = holdColorHomeMarker;
            return true;
        }

        private void ProcessHoldHoverSelection()
        {
            if (hudMode != HudMode.Hold || !Visible) return;

            Point screenPoint = Cursor.Position;
            if (screenPoint == holdLastScreenPoint) return;
            holdLastScreenPoint = screenPoint;

            Point client = PointToClient(screenPoint);
            ActiveField nextField;
            Point marker;
            RgbColor candidate;

            if (IsPointInColor(client))
            {
                nextField = ActiveField.Color;
                marker = ClampPointToRoundedRect(client, colorRect, colorCornerRadius);
                candidate = ColorFromField(marker);
            }
            else if (IsPointInLightness(client))
            {
                nextField = ActiveField.Lightness;
                marker = ClampPointToRoundedRect(client, lightRect, lightCornerRadius);
                candidate = ColorFromLightness(marker);
            }
            else
            {
                // Leaving the HUD does not destroy the last valid pick. Releasing the hold key still commits it.
                return;
            }

            // Hold mode owns its own field state. Persistent HUD mouse interaction cannot
            // interfere with the handoff decision. When we enter the other field, restore
            // the field we are no longer controlling to its F11 Home marker.
            bool fieldChanged = holdFieldKnown && holdField != nextField;
            bool inactiveMarkerReset = false;
            if (fieldChanged)
                inactiveMarkerReset = ResetInactiveMarkerFor(nextField);

            holdField = nextField;
            holdFieldKnown = true;
            activeField = nextField;
            bool markerChanged = SetActiveMarker(marker);
            holdCandidate = candidate;
            holdHasCandidate = true;

            if (fieldChanged || inactiveMarkerReset || markerChanged) UpdateLayeredSurface();
        }

        private void FinishHoldHoverSelection()
        {
            if (hudMode != HudMode.Hold) return;

            bool shouldCommit = holdHasCandidate;
            RgbColor picked = holdCandidate;

            // Hide first. This restores the normal window style before Photoshop receives the color update,
            // and guarantees there is no HUD pointer target left for the user's first drawing stroke.
            HideHud();
            if (!shouldCommit) return;

            string error;
            if (PhotoshopBridge.TrySetForeground(picked, out error))
            {
                baseLch = ColorMath.RgbToLch(picked);
                lastSourceRgb = picked;
                hasLastSourceRgb = true;
                holdSurfacePrepared = false;

                // Rebuild while hidden instead of on the next key-down. A short defer keeps the
                // immediate post-pick drawing stroke free from our render work.
                deferredPrewarmUtc = DateTime.UtcNow.AddMilliseconds(90);
            }
            else
            {
                try { tray.ShowBalloonTip(2200, "Local Color Fields HUD", "Could not set Photoshop foreground color.\n" + error, ToolTipIcon.Warning); } catch { }
            }
        }

        private bool IsPointOnHud(Point screenPoint)
        {
            if (!Visible) return false;
            Point client = PointToClient(screenPoint);
            if (!ClientRectangle.Contains(client)) return false;
            return IsPointInColor(client) || IsPointInLightness(client);
        }

        private static bool IsPhotoshopAt(Point screenPoint)
        {
            try
            {
                IntPtr hwnd = WindowFromPoint(new NativePoint(screenPoint.X, screenPoint.Y));
                if (hwnd == IntPtr.Zero) return false;
                uint pid;
                GetWindowThreadProcessId(hwnd, out pid);
                if (pid == 0) return false;
                using (System.Diagnostics.Process p = System.Diagnostics.Process.GetProcessById((int)pid))
                    return p.ProcessName.StartsWith("Photoshop", StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        public void TogglePersistentHud()
        {
            if (Visible && hudMode == HudMode.Persistent) HideHud();
            else ShowHud(HudMode.Persistent);
        }

        public void ShowHud()
        {
            ShowHud(HudMode.Persistent);
        }

        public void PrewarmHoldSurface()
        {
            if (IsDisposed) return;
            PrepareHoldSurface(true);
        }

        private static bool SameRgb(RgbColor a, RgbColor b)
        {
            return a.R == b.R && a.G == b.G && a.B == b.B;
        }

        private void PrepareHoldSurface(bool readPhotoshop)
        {
            if (IsDisposed || hudMode != HudMode.Hidden) return;

            DateTime wt = HudSettings.SettingsWriteTimeUtc();
            if (wt != settingsWriteTimeUtc)
            {
                settings = HudSettings.Load();
                settingsWriteTimeUtc = wt;
            }

            if (readPhotoshop)
            {
                RgbColor rgb;
                string error;
                if (PhotoshopBridge.TryGetForeground(out rgb, out error))
                {
                    baseLch = ColorMath.RgbToLch(rgb);
                    lastSourceRgb = rgb;
                    hasLastSourceRgb = true;
                    lastPsErrorShown = false;
                }
            }

            SyncWindowCentersToCurrentColor();
            ConfigureGeometry();
            RebuildBitmaps();
            ResetMarkersToCurrentColor();
            activeField = ActiveField.Color;
            holdSurfacePrepared = true;

            // Prime the hold-only click-through style while hidden as well, so hotkey-down does not
            // need a SetWindowLong/FRAMECHANGED round trip before the first visible frame.
            ApplyHoldClickThrough(true);

            // Upload the alpha surface while hidden. The next hold-key down only moves + shows it.
            UpdateLayeredSurface();
        }

        private void BeginHoldHoverFast()
        {
            if (hudMode != HudMode.Hidden || IsDisposed) return;

            // First-ever launch or a settings/color change can miss the idle prewarm. Keep a safe fallback.
            if (!holdSurfacePrepared)
                PrepareHoldSurface(true);

            CaptureHoldMarkerHomes();

            Point p = Cursor.Position;
            Rectangle wa = Screen.FromPoint(p).WorkingArea;
            int x = p.X - colorMarker.X;
            int y = p.Y - colorMarker.Y;

            if (x + Width > wa.Right) x = wa.Right - Width;
            if (y + Height > wa.Bottom) y = wa.Bottom - Height;
            if (x < wa.Left) x = wa.Left;
            if (y < wa.Top) y = wa.Top;
            Location = new Point(x, y);

            hudMode = HudMode.Hold;
            ResetHoldHoverSelection();
            ApplyHoldClickThrough(true);
            shownAtUtc = DateTime.UtcNow;

            if (!Visible) Show();
            else
            {
                TopMost = false;
                TopMost = true;
            }

            // The first frame is already visible. Verify Photoshop's current color on a background
            // Background read from the CEP-maintained color cache keeps the first hover movement non-blocking.
            QueueForegroundSync();
        }

        private void QueueForegroundSync()
        {
            int serial = Interlocked.Increment(ref foregroundSyncSerial);
            bool hadExpected = hasLastSourceRgb;
            RgbColor expected = lastSourceRgb;

            Thread worker = new Thread(delegate()
            {
                RgbColor rgb;
                string error;
                if (!PhotoshopBridge.TryGetForeground(out rgb, out error)) return;
                try
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        ApplyForegroundSyncResult(serial, hadExpected, expected, rgb);
                    });
                }
                catch { }
            });
            worker.IsBackground = true;
            try { worker.SetApartmentState(ApartmentState.STA); } catch { }
            worker.Start();
        }

        private void ApplyForegroundSyncResult(int serial, bool hadExpected, RgbColor expected, RgbColor rgb)
        {
            if (IsDisposed || serial != foregroundSyncSerial) return;

            // A successful picker commit after this read was queued wins over the stale read result.
            if (hadExpected && hasLastSourceRgb && !SameRgb(lastSourceRgb, expected)) return;
            if (hasLastSourceRgb && SameRgb(lastSourceRgb, rgb)) return;

            baseLch = ColorMath.RgbToLch(rgb);
            lastSourceRgb = rgb;
            hasLastSourceRgb = true;
            holdSurfacePrepared = false;

            if (hudMode == HudMode.Hold && Visible && holdKeyDown)
            {
                SyncWindowCentersToCurrentColor();
                ConfigureGeometry();
                RebuildBitmaps();
                ResetMarkersToCurrentColor();
                CaptureHoldMarkerHomes();
                activeField = ActiveField.Color;
                holdSurfacePrepared = true;

                Point p = Cursor.Position;
                Rectangle wa = Screen.FromPoint(p).WorkingArea;
                int x = p.X - colorMarker.X;
                int y = p.Y - colorMarker.Y;
                if (x + Width > wa.Right) x = wa.Right - Width;
                if (y + Height > wa.Bottom) y = wa.Bottom - Height;
                if (x < wa.Left) x = wa.Left;
                if (y < wa.Top) y = wa.Top;
                Location = new Point(x, y);
                UpdateLayeredSurface();
            }
            else if (hudMode == HudMode.Hidden)
            {
                deferredPrewarmUtc = DateTime.UtcNow.AddMilliseconds(90);
            }
        }

        private void ShowHud(HudMode mode)
        {
            if (mode == HudMode.Hold)
            {
                BeginHoldHoverFast();
                return;
            }

            settings = HudSettings.Load();
            settingsWriteTimeUtc = HudSettings.SettingsWriteTimeUtc();
            RgbColor rgb;
            string error;
            if (PhotoshopBridge.TryGetForeground(out rgb, out error))
            {
                baseLch = ColorMath.RgbToLch(rgb);
                lastSourceRgb = rgb;
                hasLastSourceRgb = true;
                lastPsErrorShown = false;
            }
            else if (!lastPsErrorShown)
            {
                lastPsErrorShown = true;
                try { tray.ShowBalloonTip(2200, "Local Color Fields HUD", "Could not read Photoshop foreground color. Make sure Photoshop is running.\n" + error, ToolTipIcon.Warning); } catch { }
            }

            SyncWindowCentersToCurrentColor();
            ConfigureGeometry();
            RebuildBitmaps();
            ResetMarkersToCurrentColor();
            activeField = ActiveField.Color;
            holdSurfacePrepared = true;

            Point p = Cursor.Position;
            Rectangle wa = Screen.FromPoint(p).WorkingArea;
            int offset = settings.CursorOffset;
            int x = p.X + offset;
            int y = p.Y + offset;
            if (x + Width > wa.Right) x = p.X - Width - offset;
            if (y + Height > wa.Bottom) y = p.Y - Height - offset;
            if (x + Width > wa.Right) x = wa.Right - Width;
            if (y + Height > wa.Bottom) y = wa.Bottom - Height;
            if (x < wa.Left) x = wa.Left;
            if (y < wa.Top) y = wa.Top;
            Location = new Point(x, y);

            hudMode = mode;
            ResetHoldHoverSelection();
            ApplyHoldClickThrough(false);
            shownAtUtc = DateTime.UtcNow;
            if (!Visible)
            {
                UpdateLayeredSurface();
                Show();
            }
            else
            {
                TopMost = false;
                TopMost = true;
                UpdateLayeredSurface();
            }
        }

        private void ConfigureGeometry()
        {
            int shadowPad = 7;
            int contentPad = shadowPad + 2;
            int field = Math.Max(120, settings.FieldSize);
            int bar = Math.Max(18, Math.Min(settings.LightBarWidth, Math.Max(18, field / 2)));
            int gap = Math.Max(2, settings.Gap);
            bool barLeft = String.Equals(settings.LightBarSide, "left", StringComparison.OrdinalIgnoreCase);

            Size = new Size(contentPad * 2 + field + gap + bar, contentPad * 2 + field);
            if (barLeft)
            {
                lightRect = new Rectangle(contentPad, contentPad, bar, field);
                colorRect = new Rectangle(lightRect.Right + gap, contentPad, field, field);
            }
            else
            {
                colorRect = new Rectangle(contentPad, contentPad, field, field);
                lightRect = new Rectangle(colorRect.Right + gap, contentPad, bar, field);
            }

            colorCornerRadius = Math.Max(0f, field * (float)(settings.CornerRadiusPercent / 100.0));
            lightCornerRadius = Math.Max(3f, Math.Min(bar * 0.48f, colorCornerRadius));

            // Do not use Form.Region here. Region is a 1-bit window mask and causes visible stair-stepping.
            // The entire HUD is now composited as a per-pixel-alpha layered window.
            if (Region != null)
            {
                Region.Dispose();
                Region = null;
            }
        }

        private void ApplySettingsLive()
        {
            if (!Visible) return;
            Point oldCenterScreen = new Point(Left + Width / 2, Top + Height / 2);
            SyncWindowCentersToCurrentColor();
            ConfigureGeometry();
            RebuildBitmaps();
            ResetMarkersToCurrentColor();
            if (hudMode == HudMode.Hold) CaptureHoldMarkerHomes();
            holdSurfacePrepared = true;
            Left = oldCenterScreen.X - Width / 2;
            Top = oldCenterScreen.Y - Height / 2;
            Rectangle wa = Screen.FromPoint(oldCenterScreen).WorkingArea;
            if (Right > wa.Right) Left -= Right - wa.Right;
            if (Bottom > wa.Bottom) Top -= Bottom - wa.Bottom;
            if (Left < wa.Left) Left = wa.Left;
            if (Top < wa.Top) Top = wa.Top;
            UpdateLayeredSurface();
        }

        public void HideHud()
        {
            dragging = false;
            StopPassiveDragTracking();
            if (fallbackCapture || Capture) Capture = false;
            fallbackCapture = false;

            // Keep Hold mode set until after the window is actually hidden. This prevents a final
            // WinForms cursor handoff during Hide() from flashing the Cross cursor on release.
            if (Visible) Hide();
            hudMode = HudMode.Hidden;
            ApplyHoldClickThrough(false);
            ResetHoldHoverSelection();
        }
    }
}
