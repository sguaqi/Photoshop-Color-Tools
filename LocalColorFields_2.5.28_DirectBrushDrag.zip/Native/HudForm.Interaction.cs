using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace LocalColorFieldsNativeHUD
{
    internal sealed partial class HudForm
    {
        private bool StartPassiveDragTracking()
        {
            StopPassiveDragTracking();
            try
            {
                passiveMouseHook = SetWindowsHookEx(WH_MOUSE_LL, passiveMouseProc, GetModuleHandle(null), 0);
                passiveTracking = passiveMouseHook != IntPtr.Zero;
                return passiveTracking;
            }
            catch
            {
                passiveMouseHook = IntPtr.Zero;
                passiveTracking = false;
                return false;
            }
        }

        private void StopPassiveDragTracking()
        {
            IntPtr hook = passiveMouseHook;
            passiveMouseHook = IntPtr.Zero;
            passiveTracking = false;
            if (hook != IntPtr.Zero)
            {
                try { UnhookWindowsHookEx(hook); } catch { }
            }
            lock (passiveInputGate)
            {
                passiveMovePending = false;
                passiveUpPending = false;
                passiveScreenPoint = Point.Empty;
            }
        }

        private IntPtr PassiveMouseHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            IntPtr hookSnapshot = passiveMouseHook;
            if (nCode >= 0 && hookSnapshot != IntPtr.Zero)
            {
                int msg = unchecked((int)wParam.ToInt64());
                if (msg == WM_MOUSEMOVE || msg == WM_LBUTTONUP)
                {
                    try
                    {
                        MsLlHookStruct info = (MsLlHookStruct)Marshal.PtrToStructure(lParam, typeof(MsLlHookStruct));
                        lock (passiveInputGate)
                        {
                            passiveScreenPoint = new Point(info.Point.X, info.Point.Y);
                            if (msg == WM_MOUSEMOVE) passiveMovePending = true;
                            else passiveUpPending = true;
                        }
                    }
                    catch { }
                }
            }
            return CallNextHookEx(hookSnapshot, nCode, wParam, lParam);
        }

        private void ProcessPassiveInput()
        {
            if (!dragging || !passiveTracking) return;
            bool move, up;
            Point screenPoint;
            lock (passiveInputGate)
            {
                move = passiveMovePending;
                up = passiveUpPending;
                screenPoint = passiveScreenPoint;
                passiveMovePending = false;
                if (up) passiveUpPending = false;
            }
            if (screenPoint == Point.Empty) return;
            Point client = PointToClient(screenPoint);
            Point p = ClampPointToActive(client);
            bool changed = SetActiveMarker(p);
            if (up)
            {
                FinishDrag(p);
                return;
            }
            if (move && changed) UpdateLayeredSurface();
        }

        private void HudMouseDown(object sender, MouseEventArgs e)
        {
            if (hudMode == HudMode.Hold) return;
            if (e.Button == MouseButtons.Right) { HideHud(); return; }
            if (e.Button != MouseButtons.Left) return;

            if (IsPointInColor(e.Location)) activeField = ActiveField.Color;
            else if (IsPointInLightness(e.Location)) activeField = ActiveField.Lightness;
            else return;

            dragging = true;
            fallbackCapture = !StartPassiveDragTracking();
            if (fallbackCapture) Capture = true;
            SetActiveMarker(ClampPointToActive(e.Location));
            UpdateLayeredSurface();
        }

        private void HudMouseMove(object sender, MouseEventArgs e)
        {
            if (hudMode == HudMode.Hold) return;
            if (!dragging || passiveTracking) return;
            if (SetActiveMarker(ClampPointToActive(e.Location))) UpdateLayeredSurface();
        }

        private void HudMouseUp(object sender, MouseEventArgs e)
        {
            if (hudMode == HudMode.Hold) return;
            if (!dragging || e.Button != MouseButtons.Left) return;
            FinishDrag(ClampPointToActive(e.Location));
        }

        private void FinishDrag(Point p)
        {
            if (!dragging) return;
            SetActiveMarker(p);
            RgbColor picked = activeField == ActiveField.Color ? ColorFromField(p) : ColorFromLightness(p);
            dragging = false;
            StopPassiveDragTracking();
            if (fallbackCapture || Capture) Capture = false;
            fallbackCapture = false;

            string error;
            if (PhotoshopBridge.TrySetForeground(picked, out error))
            {
                if (settings.RefreshAfterPick) RefreshFieldsFromPickedColor(picked);
                else UpdateLayeredSurface();
            }
            else
            {
                try { tray.ShowBalloonTip(2200, "Local Color Fields HUD", "Could not set Photoshop foreground color.\n" + error, ToolTipIcon.Warning); } catch { }
            }
        }

        private bool IsPointInColor(Point p)
        {
            return IsPointInRoundedRect(p, colorRect, colorCornerRadius);
        }

        private bool IsPointInLightness(Point p)
        {
            return IsPointInRoundedRect(p, lightRect, lightCornerRadius);
        }

        private static bool IsPointInRoundedRect(Point p, Rectangle rect, float radius)
        {
            if (!rect.Contains(p)) return false;
            double r = Math.Max(0.0, Math.Min(radius, Math.Min(rect.Width, rect.Height) * 0.5));
            if (r <= 0.5) return true;

            double left = rect.Left, top = rect.Top, right = rect.Right - 1, bottom = rect.Bottom - 1;
            if (p.X >= left + r && p.X <= right - r) return true;
            if (p.Y >= top + r && p.Y <= bottom - r) return true;

            double cx = p.X < left + r ? left + r : right - r;
            double cy = p.Y < top + r ? top + r : bottom - r;
            double dx = p.X - cx, dy = p.Y - cy;
            return dx * dx + dy * dy <= r * r + 0.25;
        }

        private Point ClampPointToActive(Point p)
        {
            return activeField == ActiveField.Color ? ClampPointToRoundedRect(p, colorRect, colorCornerRadius) : ClampPointToRoundedRect(p, lightRect, lightCornerRadius);
        }

        private Point ClampPointToRoundedRect(Point p, Rectangle rect, float radius)
        {
            int x = Math.Max(rect.Left, Math.Min(rect.Right - 1, p.X));
            int y = Math.Max(rect.Top, Math.Min(rect.Bottom - 1, p.Y));
            Point q = new Point(x, y);
            if (IsPointInRoundedRect(q, rect, radius)) return q;

            double r = Math.Max(0.0, Math.Min(radius, Math.Min(rect.Width, rect.Height) * 0.5));
            if (r <= 0.5) return q;
            double left = rect.Left, top = rect.Top, right = rect.Right - 1, bottom = rect.Bottom - 1;
            double cx = q.X < left + r ? left + r : right - r;
            double cy = q.Y < top + r ? top + r : bottom - r;
            double dx = q.X - cx, dy = q.Y - cy;
            double len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 0.000001) return new Point((int)Math.Round(cx), (int)Math.Round(cy));
            double scale = Math.Max(0.0, (r - 0.75) / len);
            return new Point((int)Math.Round(cx + dx * scale), (int)Math.Round(cy + dy * scale));
        }

        private bool SetActiveMarker(Point p)
        {
            if (activeField == ActiveField.Color)
            {
                if (colorMarker == p) return false;
                colorMarker = p;
                return true;
            }
            if (lightMarker == p) return false;
            lightMarker = p;
            return true;
        }

        private void RefreshFieldsFromPickedColor(RgbColor picked)
        {
            baseLch = ColorMath.RgbToLch(picked);

            // Independent protected refresh:
            // each local window follows the current component until a hard min/max is reached.
            // At that boundary this component's window stops moving, while Hue still recenters every refresh.
            chromaWindowCenter = FitWindowCenter(baseLch.C, settings.ChromaRange, settings.ChromaMin, settings.ChromaMax);
            lightnessWindowCenter = FitWindowCenter(baseLch.L, settings.LightnessRange, settings.LightnessMin, settings.LightnessMax);

            RebuildBitmaps();
            ResetMarkersToCurrentColor();
            holdSurfacePrepared = true;
            UpdateLayeredSurface();
        }

        private void ResetMarkersToCurrentColor()
        {
            AxisWindow cw = GetChromaWindow();
            double cDen = cw.High - cw.Low;
            double cT = Math.Abs(cDen) < 0.000001 ? 0.5 : (cw.High - baseLch.C) / cDen;
            cT = ColorMath.Clamp(cT, 0.0, 1.0);
            colorMarker = new Point(
                colorRect.Left + colorRect.Width / 2,
                colorRect.Top + (int)Math.Round(cT * (colorRect.Height - 1)));

            AxisWindow lw = GetLightnessWindow();
            double lDen = lw.High - lw.Low;
            double lT = Math.Abs(lDen) < 0.000001 ? 0.5 : (lw.High - baseLch.L) / lDen;
            lT = ColorMath.Clamp(lT, 0.0, 1.0);
            lightMarker = new Point(
                lightRect.Left + lightRect.Width / 2,
                lightRect.Top + (int)Math.Round(lT * (lightRect.Height - 1)));
        }

        private RgbColor ColorFromField(Point p)
        {
            double tx = colorRect.Width <= 1 ? 0.5 : (double)(p.X - colorRect.Left) / (colorRect.Width - 1);
            double ty = colorRect.Height <= 1 ? 0.5 : (double)(p.Y - colorRect.Top) / (colorRect.Height - 1);
            double h = baseLch.H + (tx - 0.5) * (settings.HueRange * 2.0);
            AxisWindow cw = GetChromaWindow();
            double C = cw.High + (cw.Low - cw.High) * ty;
            return ColorMath.LchToRgb(baseLch.L, C, h, 16);
        }

        private RgbColor ColorFromLightness(Point p)
        {
            double ty = lightRect.Height <= 1 ? 0.5 : (double)(p.Y - lightRect.Top) / (lightRect.Height - 1);
            AxisWindow lw = GetLightnessWindow();
            double L = lw.High + (lw.Low - lw.High) * ty;
            return ColorMath.LchToRgb(L, baseLch.C, baseLch.H, 16);
        }

        private void DisposeBitmaps()
        {
            DisposeSurfaceCache();
            if (colorBitmap != null) { colorBitmap.Dispose(); colorBitmap = null; }
            if (lightBitmap != null) { lightBitmap.Dispose(); lightBitmap = null; }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                RemoveKeyboardHook();
                StopPassiveDragTracking();
                EndBrushDrag();
                DisposeBitmaps();
                if (inputTimer != null) { inputTimer.Stop(); inputTimer.Dispose(); inputTimer = null; }
                if (tray != null) { tray.Visible = false; tray.Dispose(); tray = null; }
            }
            base.Dispose(disposing);
        }
    }
}
