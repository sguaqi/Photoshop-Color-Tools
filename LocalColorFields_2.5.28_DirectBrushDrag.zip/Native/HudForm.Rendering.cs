using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace LocalColorFieldsNativeHUD
{
    internal sealed partial class HudForm
    {
        private void RebuildBitmaps()
        {
            DisposeBitmaps();
            colorBitmap = RenderColorField(colorRect.Width, colorRect.Height);
            lightBitmap = RenderLightnessBar(lightRect.Width, lightRect.Height);
            RebuildStaticSurface();
        }

        private Bitmap RenderColorField(int displayW, int displayH)
        {
            Size p = PreviewSize(displayW, displayH, 65000);
            int[] pixels = new int[p.Width * p.Height];
            double[] cosH = new double[p.Width];
            double[] sinH = new double[p.Width];
            for (int x = 0; x < p.Width; x++)
            {
                double tx = p.Width <= 1 ? 0.5 : (double)x / (p.Width - 1);
                double h = ColorMath.WrapHue(baseLch.H + (tx - 0.5) * (settings.HueRange * 2.0));
                double rad = h * Math.PI / 180.0;
                cosH[x] = Math.Cos(rad);
                sinH[x] = Math.Sin(rad);
            }

            AxisWindow cw = GetChromaWindow();
            int k = 0;
            for (int y = 0; y < p.Height; y++)
            {
                double ty = p.Height <= 1 ? 0.5 : (double)y / (p.Height - 1);
                double C = cw.High + (cw.Low - cw.High) * ty;
                for (int x = 0; x < p.Width; x++)
                {
                    RgbColor c = ColorMath.LchToRgbWithDirection(baseLch.L, C, cosH[x], sinH[x], 7);
                    pixels[k++] = unchecked((int)0xFF000000) | (c.R << 16) | (c.G << 8) | c.B;
                }
            }
            return BitmapFromArgb(p.Width, p.Height, pixels);
        }

        private Bitmap RenderLightnessBar(int displayW, int displayH)
        {
            Size p = PreviewSize(displayW, displayH, 18000);
            int[] pixels = new int[p.Width * p.Height];
            AxisWindow lw = GetLightnessWindow();
            double rad = ColorMath.WrapHue(baseLch.H) * Math.PI / 180.0;
            double cosH = Math.Cos(rad), sinH = Math.Sin(rad);
            int k = 0;
            for (int y = 0; y < p.Height; y++)
            {
                double ty = p.Height <= 1 ? 0.5 : (double)y / (p.Height - 1);
                double L = lw.High + (lw.Low - lw.High) * ty;
                RgbColor row = ColorMath.LchToRgbWithDirection(L, baseLch.C, cosH, sinH, 8);
                int argb = unchecked((int)0xFF000000) | (row.R << 16) | (row.G << 8) | row.B;
                for (int x = 0; x < p.Width; x++) pixels[k++] = argb;
            }
            return BitmapFromArgb(p.Width, p.Height, pixels);
        }

        private static Size PreviewSize(int w, int h, int maxPixels)
        {
            double area = (double)Math.Max(1, w) * Math.Max(1, h);
            double s = area > maxPixels ? Math.Sqrt(maxPixels / area) : 1.0;
            return new Size(Math.Max(2, (int)Math.Round(w * s)), Math.Max(2, (int)Math.Round(h * s)));
        }

        private static Bitmap BitmapFromArgb(int w, int h, int[] pixels)
        {
            Bitmap bmp = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            Rectangle rect = new Rectangle(0, 0, w, h);
            BitmapData data = bmp.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
            try { Marshal.Copy(pixels, 0, data.Scan0, pixels.Length); }
            finally { bmp.UnlockBits(data); }
            return bmp;
        }

        private static double FitWindowCenter(double current, double halfRequested, double min, double max)
        {
            if (min > max) { double t = min; min = max; max = t; }
            double span = Math.Max(0.000001, max - min);
            double half = Math.Min(Math.Max(0, halfRequested), span * 0.5);
            if (half * 2.0 >= span - 0.000001) return (min + max) * 0.5;
            return ColorMath.Clamp(current, min + half, max - half);
        }

        private static AxisWindow BuildWindow(double center, double halfRequested, double min, double max)
        {
            if (min > max) { double t = min; min = max; max = t; }
            double span = Math.Max(0.000001, max - min);
            double half = Math.Min(Math.Max(0, halfRequested), span * 0.5);
            center = FitWindowCenter(center, half, min, max);
            AxisWindow w = new AxisWindow();
            w.Center = center;
            w.Half = half;
            w.High = Math.Min(max, center + half);
            w.Low = Math.Max(min, center - half);
            return w;
        }

        private void SyncWindowCentersToCurrentColor()
        {
            chromaWindowCenter = FitWindowCenter(baseLch.C, settings.ChromaRange, settings.ChromaMin, settings.ChromaMax);
            lightnessWindowCenter = FitWindowCenter(baseLch.L, settings.LightnessRange, settings.LightnessMin, settings.LightnessMax);
        }

        private AxisWindow GetChromaWindow()
        {
            return BuildWindow(chromaWindowCenter, settings.ChromaRange, settings.ChromaMin, settings.ChromaMax);
        }

        private AxisWindow GetLightnessWindow()
        {
            return BuildWindow(lightnessWindowCenter, settings.LightnessRange, settings.LightnessMin, settings.LightnessMax);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            // A layered window is painted through UpdateLayeredWindow, not through the normal WM_PAINT path.
            // Keeping this empty avoids a second, non-alpha paint pass.
        }

        private void ConfigureGraphicsQuality(Graphics g, bool staticPass)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.CompositingMode = CompositingMode.SourceOver;
            g.CompositingQuality = staticPass ? CompositingQuality.HighQuality : CompositingQuality.HighSpeed;
            g.InterpolationMode = staticPass ? InterpolationMode.HighQualityBicubic : InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = staticPass ? PixelOffsetMode.HighQuality : PixelOffsetMode.HighSpeed;
        }

        private void RenderHudBackground(Graphics g)
        {
            g.Clear(Color.Transparent);
            ConfigureGraphicsQuality(g, true);
            DrawControlShadow(g, colorRect, colorCornerRadius, 0.8f, 1.4f);
            DrawControlShadow(g, lightRect, lightCornerRadius, 0.8f, 1.4f);
            DrawColorField(g);
            DrawLightnessBar(g);
        }

        private void DisposeSurfaceCache()
        {
            if (frameSurfaceGraphics != null) { frameSurfaceGraphics.Dispose(); frameSurfaceGraphics = null; }
            if (frameSurfaceBitmap != null) { frameSurfaceBitmap.Dispose(); frameSurfaceBitmap = null; }
            if (staticSurfaceBitmap != null) { staticSurfaceBitmap.Dispose(); staticSurfaceBitmap = null; }
        }

        private void RebuildStaticSurface()
        {
            DisposeSurfaceCache();
            if (Width <= 0 || Height <= 0) return;
            staticSurfaceBitmap = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(staticSurfaceBitmap)) RenderHudBackground(g);
            frameSurfaceBitmap = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
            frameSurfaceGraphics = Graphics.FromImage(frameSurfaceBitmap);
            ConfigureGraphicsQuality(frameSurfaceGraphics, false);
        }

        private void ComposeFrameSurface()
        {
            if (staticSurfaceBitmap == null || frameSurfaceBitmap == null || frameSurfaceGraphics == null ||
                frameSurfaceBitmap.Width != Width || frameSurfaceBitmap.Height != Height)
                RebuildStaticSurface();
            if (staticSurfaceBitmap == null || frameSurfaceGraphics == null) return;

            frameSurfaceGraphics.CompositingMode = CompositingMode.SourceCopy;
            frameSurfaceGraphics.DrawImageUnscaled(staticSurfaceBitmap, 0, 0);
            frameSurfaceGraphics.CompositingMode = CompositingMode.SourceOver;
            DrawMarker(frameSurfaceGraphics, colorMarker);
            DrawMarker(frameSurfaceGraphics, lightMarker);
        }

        private void UpdateLayeredSurface()
        {
            if (Width <= 0 || Height <= 0 || IsDisposed) return;
            ComposeFrameSurface();
            if (frameSurfaceBitmap == null) return;

            IntPtr screenDc = IntPtr.Zero;
            IntPtr memDc = IntPtr.Zero;
            IntPtr hBitmap = IntPtr.Zero;
            IntPtr oldBitmap = IntPtr.Zero;
            try
            {
                screenDc = GetDC(IntPtr.Zero);
                memDc = CreateCompatibleDC(screenDc);
                hBitmap = frameSurfaceBitmap.GetHbitmap(Color.FromArgb(0));
                oldBitmap = SelectObject(memDc, hBitmap);

                NativePoint dst = new NativePoint(Left, Top);
                NativeSize size = new NativeSize(Width, Height);
                NativePoint src = new NativePoint(0, 0);
                BlendFunction blend = new BlendFunction();
                blend.BlendOp = AC_SRC_OVER;
                blend.BlendFlags = 0;
                blend.SourceConstantAlpha = 255;
                blend.AlphaFormat = AC_SRC_ALPHA;

                UpdateLayeredWindow(Handle, screenDc, ref dst, ref size, memDc, ref src, 0, ref blend, ULW_ALPHA);
            }
            finally
            {
                if (oldBitmap != IntPtr.Zero && memDc != IntPtr.Zero) SelectObject(memDc, oldBitmap);
                if (hBitmap != IntPtr.Zero) DeleteObject(hBitmap);
                if (memDc != IntPtr.Zero) DeleteDC(memDc);
                if (screenDc != IntPtr.Zero) ReleaseDC(IntPtr.Zero, screenDc);
            }
        }

        private void DrawColorField(Graphics g)
        {
            using (GraphicsPath path = RoundedRectPath(colorRect, colorCornerRadius))
            {
                GraphicsState state = g.Save();
                g.SetClip(path);
                if (colorBitmap != null) g.DrawImage(colorBitmap, colorRect);
                g.Restore(state);
                DrawControlOutline(g, path);
            }
        }

        private void DrawLightnessBar(Graphics g)
        {
            using (GraphicsPath path = RoundedRectPath(lightRect, lightCornerRadius))
            {
                GraphicsState state = g.Save();
                g.SetClip(path);
                if (lightBitmap != null) g.DrawImage(lightBitmap, lightRect);
                g.Restore(state);
                DrawControlOutline(g, path);
            }
        }

        private static void DrawControlShadow(Graphics g, Rectangle rect, float radius, float dx, float dy)
        {
            using (GraphicsPath shadowPath = RoundedRectPath(rect, radius))
            using (Matrix m = new Matrix())
            {
                m.Translate(dx, dy);
                shadowPath.Transform(m);
                using (Pen p1 = new Pen(Color.FromArgb(30, 0, 0, 0), 7.0f))
                using (Pen p2 = new Pen(Color.FromArgb(26, 0, 0, 0), 4.2f))
                using (Pen p3 = new Pen(Color.FromArgb(20, 0, 0, 0), 2.2f))
                {
                    p1.LineJoin = LineJoin.Round;
                    p2.LineJoin = LineJoin.Round;
                    p3.LineJoin = LineJoin.Round;
                    g.DrawPath(p1, shadowPath);
                    g.DrawPath(p2, shadowPath);
                    g.DrawPath(p3, shadowPath);
                }
            }
        }

        private static void DrawControlOutline(Graphics g, GraphicsPath path)
        {
            // Dark contour for separation, then a faint inside highlight to keep the edge crisp.
            using (Pen outer = new Pen(Color.FromArgb(235, 6, 6, 8), 1.8f))
            using (Pen inner = new Pen(Color.FromArgb(54, 255, 255, 255), 0.8f))
            {
                outer.LineJoin = LineJoin.Round;
                inner.LineJoin = LineJoin.Round;
                g.DrawPath(outer, path);
                g.DrawPath(inner, path);
            }
        }

        private static GraphicsPath RoundedRectPath(Rectangle rect, float radius)
        {
            GraphicsPath path = new GraphicsPath();
            if (radius <= 0.5f)
            {
                path.AddRectangle(rect);
                path.CloseFigure();
                return path;
            }
            float r = Math.Min(radius, Math.Min(rect.Width, rect.Height) * 0.5f);
            float d = r * 2f;
            RectangleF rf = new RectangleF(rect.X, rect.Y, rect.Width, rect.Height);
            path.AddArc(rf.Left, rf.Top, d, d, 180, 90);
            path.AddArc(rf.Right - d, rf.Top, d, d, 270, 90);
            path.AddArc(rf.Right - d, rf.Bottom - d, d, d, 0, 90);
            path.AddArc(rf.Left, rf.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private void DrawMarker(Graphics g, Point p)
        {
            if (p == Point.Empty) return;

            // Minimal marker: one clean white hollow circle. No fill, center dot, shadow or black outline.
            float diameter = Math.Max(8f, settings.MarkerSize);
            float stroke = Math.Max(1.25f, Math.Min(2.0f, diameter * 0.11f));
            float radius = diameter * 0.5f;
            float inset = stroke * 0.5f + 0.25f;
            RectangleF rect = new RectangleF(
                p.X - radius + inset,
                p.Y - radius + inset,
                diameter - inset * 2f,
                diameter - inset * 2f);

            SmoothingMode oldSmoothing = g.SmoothingMode;
            PixelOffsetMode oldPixelOffset = g.PixelOffsetMode;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            using (Pen ring = new Pen(Color.FromArgb(255, 255, 255, 255), stroke))
            {
                ring.Alignment = PenAlignment.Center;
                g.DrawEllipse(ring, rect);
            }
            g.PixelOffsetMode = oldPixelOffset;
            g.SmoothingMode = oldSmoothing;
        }
    }
}
