using System;
using System.IO;
using System.Text.RegularExpressions;

namespace LocalColorFieldsNativeHUD
{
    internal sealed class HudSettings
    {

        // Current keys are preferred; legacy keys are read only for migration.
        public int FieldSize = 260;
        public int LightBarWidth = 34;
        public string LightBarSide = "right";
        public int Gap = 10;
        public double CornerRadiusPercent = 8.0;
        public int MarkerSize = 12;
        public int CursorOffset = 18;

        public double HueRange = 45.0;
        public double ChromaRange = 8.0;
        public double ChromaMin = 0.0;
        public double ChromaMax = 35.0;

        public double LightnessRange = 20.0;
        public double LightnessMin = 5.0;
        public double LightnessMax = 95.0;

        public bool RefreshAfterPick = true;
        public bool CloseOnPhotoshopClick = true;
        public bool EnableHoldShortcut = true;

        public bool EnableBrushDrag = true;
        public string BrushSizeDragKey = "F9";
        public string BrushOpacityDragKey = "F10";
        public double BrushSizeDoublingPixels = 140.0;
        public double BrushOpacityFullRangePixels = 320.0;
        public int BrushDragDeadZone = 2;

        public static HudSettings Load()
        {
            HudSettings s = new HudSettings();
            try
            {
                string path = SettingsPath;
                if (!File.Exists(path)) return s;
                string json = File.ReadAllText(path);

                int legacyInner = ClampInt(ReadNumber(json, "innerSize", ReadNumber(json, "multiHeight", s.FieldSize)), 80, 600);
                int legacyRing = ClampInt(ReadNumber(json, "ringThickness", 50), 12, 180);

                s.FieldSize = ClampInt(ReadNumber(json, "fieldSize", legacyInner), 120, 620);
                s.LightBarWidth = ClampInt(ReadNumber(json, "lightBarWidth", Math.Max(24, (int)Math.Round(legacyRing * 0.68))), 18, 120);
                string side = ReadString(json, "lightBarSide", s.LightBarSide);
                s.LightBarSide = String.Equals(side, "left", StringComparison.OrdinalIgnoreCase) ? "left" : "right";
                s.Gap = ClampInt(ReadNumber(json, "gap", s.Gap), 2, 60);
                s.CornerRadiusPercent = Clamp(ReadNumberDouble(json, "cornerRadius", s.CornerRadiusPercent), 0, 32);
                s.MarkerSize = ClampInt(ReadNumber(json, "markerSize", s.MarkerSize), 8, 30);
                s.CursorOffset = ClampInt(ReadNumber(json, "cursorOffset", s.CursorOffset), 0, 80);

                s.HueRange = Clamp(ReadNumberDouble(json, "hueRange", ReadNumberDouble(json, "multiHueRange", s.HueRange)), 5, 180);
                s.ChromaRange = Clamp(ReadNumberDouble(json, "chromaRange", s.ChromaRange), 0.5, 30);
                s.ChromaMin = Clamp(ReadNumberDouble(json, "chromaMin", s.ChromaMin), 0, 59.5);
                s.ChromaMax = Clamp(ReadNumberDouble(json, "chromaMax", s.ChromaMax), 0.5, 60);
                if (s.ChromaMin >= s.ChromaMax) s.ChromaMin = Math.Max(0, s.ChromaMax - 0.5);

                s.LightnessRange = Clamp(ReadNumberDouble(json, "lightnessRange", ReadNumberDouble(json, "hlLRange", s.LightnessRange)), 1, 49.5);
                s.LightnessMin = Clamp(ReadNumberDouble(json, "lightnessMin", ReadNumberDouble(json, "hlBlack", s.LightnessMin)), 0, 99);
                s.LightnessMax = Clamp(ReadNumberDouble(json, "lightnessMax", ReadNumberDouble(json, "hlWhite", s.LightnessMax)), 1, 100);
                if (s.LightnessMin >= s.LightnessMax) s.LightnessMin = Math.Max(0, s.LightnessMax - 1);

                s.RefreshAfterPick = ReadBool(json, "refreshAfterPick", s.RefreshAfterPick);
                s.CloseOnPhotoshopClick = ReadBool(json, "closeOnPhotoshopClick", s.CloseOnPhotoshopClick);
                s.EnableHoldShortcut = ReadBool(json, "enableHoldF11", ReadBool(json, "enableHoldF13", s.EnableHoldShortcut));

                s.EnableBrushDrag = ReadBool(json, "enableBrushDrag", s.EnableBrushDrag);
                s.BrushSizeDragKey = NormalizeBrushKey(ReadString(json, "brushSizeDragKey", s.BrushSizeDragKey), s.BrushSizeDragKey);
                s.BrushOpacityDragKey = NormalizeBrushKey(ReadString(json, "brushOpacityDragKey", s.BrushOpacityDragKey), s.BrushOpacityDragKey);
                if (!String.Equals(s.BrushSizeDragKey, "Off", StringComparison.OrdinalIgnoreCase) &&
                    String.Equals(s.BrushSizeDragKey, s.BrushOpacityDragKey, StringComparison.OrdinalIgnoreCase))
                    s.BrushOpacityDragKey = "F10";
                s.BrushSizeDoublingPixels = Clamp(ReadNumberDouble(json, "brushSizeDoublingPixels", s.BrushSizeDoublingPixels), 40, 600);
                s.BrushOpacityFullRangePixels = Clamp(ReadNumberDouble(json, "brushOpacityFullRangePixels", s.BrushOpacityFullRangePixels), 80, 1000);
                s.BrushDragDeadZone = ClampInt(ReadNumber(json, "brushDragDeadZone", s.BrushDragDeadZone), 0, 12);
            }
            catch { }
            return s;
        }

        private static int ReadNumber(string json, string key, int fallback)
        {
            double d = ReadNumberDouble(json, key, fallback);
            if (Double.IsNaN(d) || Double.IsInfinity(d)) return fallback;
            return (int)Math.Round(d);
        }

        private static double ReadNumberDouble(string json, string key, double fallback)
        {
            Match m = Regex.Match(json, "\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)", RegexOptions.IgnoreCase);
            if (!m.Success) return fallback;
            double v;
            if (!Double.TryParse(m.Groups[1].Value, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v)) return fallback;
            return v;
        }

        private static bool ReadBool(string json, string key, bool fallback)
        {
            Match m = Regex.Match(json, "\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*(true|false)", RegexOptions.IgnoreCase);
            if (!m.Success) return fallback;
            return String.Equals(m.Groups[1].Value, "true", StringComparison.OrdinalIgnoreCase);
        }

        private static string ReadString(string json, string key, string fallback)
        {
            Match m = Regex.Match(json, "\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"", RegexOptions.IgnoreCase);
            if (!m.Success) return fallback;
            return m.Groups[1].Value;
        }

        private static string NormalizeBrushKey(string value, string fallback)
        {
            if (String.IsNullOrEmpty(value)) return fallback;
            string n = value.Trim().ToUpperInvariant().Replace(" ", "").Replace("_", "");
            if (n == "OFF" || n == "NONE") return "Off";
            if (n.Length >= 2 && n[0] == 'F')
            {
                int f;
                if (Int32.TryParse(n.Substring(1), out f) && f >= 1 && f <= 24 && f != 11) return "F" + f;
            }
            if (n == "PAUSE") return "Pause";
            if (n == "SCROLLLOCK" || n == "SCROLL") return "ScrollLock";
            if (n == "INSERT" || n == "INS") return "Insert";
            if (n == "HOME") return "Home";
            if (n == "END") return "End";
            if (n == "PAGEUP" || n == "PGUP") return "PageUp";
            if (n == "PAGEDOWN" || n == "PGDN") return "PageDown";
            return fallback;
        }

        public static string SettingsPath
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "LocalColorFields", "settings.json");
            }
        }

        public static DateTime SettingsWriteTimeUtc()
        {
            try { return File.Exists(SettingsPath) ? File.GetLastWriteTimeUtc(SettingsPath) : DateTime.MinValue; }
            catch { return DateTime.MinValue; }
        }

        private static int ClampInt(int v, int lo, int hi) { return Math.Max(lo, Math.Min(hi, v)); }
        private static double Clamp(double v, double lo, double hi) { return Math.Max(lo, Math.Min(hi, v)); }
    
    }
}
