using System;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;

namespace LocalColorFieldsNativeHUD
{
    internal static class PhotoshopBridge
    {
        // Native reads/writes only local JSON. Photoshop scripting stays inside CEP.
        private static int commandSerial = Environment.TickCount & 0x3fffffff;
        private static RgbColor lastCached = new RgbColor(128, 128, 128);
        private static bool hasCached = false;
        private static BrushState lastBrushCached = new BrushState(50.0, 100.0);
        private static bool hasBrushCached = false;

        private static string BridgeDirectory
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "LocalColorFields", "CepBridge");
            }
        }

        private static string StatePath { get { return Path.Combine(BridgeDirectory, "foreground_state.json"); } }
        private static string CommandPath { get { return Path.Combine(BridgeDirectory, "foreground_command.json"); } }
        private static string BrushStatePath { get { return Path.Combine(BridgeDirectory, "brush_state.json"); } }
        private static string BrushCommandPath { get { return Path.Combine(BridgeDirectory, "brush_command.json"); } }

        public static bool TryGetForeground(out RgbColor rgb, out string error)
        {
            error = null;
            for (int attempt = 0; attempt < 2; attempt++)
            {
                try
                {
                    if (File.Exists(StatePath))
                    {
                        string json = File.ReadAllText(StatePath);
                        int r, g, b;
                        if (TryReadInt(json, "r", out r) && TryReadInt(json, "g", out g) && TryReadInt(json, "b", out b))
                        {
                            rgb = new RgbColor(ClampByte(r), ClampByte(g), ClampByte(b));
                            lastCached = rgb;
                            hasCached = true;
                            return true;
                        }
                    }
                }
                catch { }
                if (attempt == 0) Thread.Sleep(1);
            }

            if (hasCached)
            {
                rgb = lastCached;
                return true;
            }

            rgb = new RgbColor(128, 128, 128);
            error = "CEP foreground-color bridge is not ready yet.";
            return false;
        }

        public static bool TrySetForeground(RgbColor rgb, out string error)
        {
            error = null;
            try
            {
                Directory.CreateDirectory(BridgeDirectory);
                int serial = Interlocked.Increment(ref commandSerial);
                string json = "{\"serial\":" + serial
                    + ",\"r\":" + ClampByte(rgb.R)
                    + ",\"g\":" + ClampByte(rgb.G)
                    + ",\"b\":" + ClampByte(rgb.B)
                    + "}";
                File.WriteAllText(CommandPath, json);
                lastCached = rgb;
                hasCached = true;
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public static bool TryGetBrushState(out BrushState state, out string error)
        {
            error = null;
            for (int attempt = 0; attempt < 2; attempt++)
            {
                try
                {
                    if (File.Exists(BrushStatePath))
                    {
                        string json = File.ReadAllText(BrushStatePath);
                        double size, opacity;
                        if (TryReadDouble(json, "size", out size) && TryReadDouble(json, "opacity", out opacity)
                            && size > 0.0 && opacity > 0.0)
                        {
                            state = new BrushState(size, opacity);
                            lastBrushCached = state;
                            hasBrushCached = true;
                            return true;
                        }
                    }
                }
                catch { }
                if (attempt == 0) Thread.Sleep(1);
            }

            if (hasBrushCached)
            {
                state = lastBrushCached;
                return true;
            }

            state = new BrushState(0.0, 0.0);
            error = "CEP brush-state bridge is not ready yet.";
            return false;
        }

        public static bool TrySetBrushSize(double value, out string error)
        {
            bool ok = TrySetBrushValue("size", Math.Max(1.0, Math.Min(5000.0, value)), out error);
            if (ok)
            {
                lastBrushCached.Size = value;
                hasBrushCached = lastBrushCached.Opacity > 0.0;
            }
            return ok;
        }

        public static bool TrySetBrushOpacity(double value, out string error)
        {
            bool ok = TrySetBrushValue("opacity", Math.Max(1.0, Math.Min(100.0, value)), out error);
            if (ok)
            {
                lastBrushCached.Opacity = value;
                hasBrushCached = lastBrushCached.Size > 0.0;
            }
            return ok;
        }

        private static bool TrySetBrushValue(string kind, double value, out string error)
        {
            error = null;
            try
            {
                Directory.CreateDirectory(BridgeDirectory);
                int serial = Interlocked.Increment(ref commandSerial);
                string json = "{\"serial\":" + serial
                    + ",\"kind\":\"" + kind + "\""
                    + ",\"value\":" + value.ToString("0.###", CultureInfo.InvariantCulture)
                    + "}";
                File.WriteAllText(BrushCommandPath, json);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        private static bool TryReadInt(string json, string key, out int value)
        {
            value = 0;
            try
            {
                Match m = Regex.Match(json, "\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*(-?\\d+)", RegexOptions.IgnoreCase);
                return m.Success && Int32.TryParse(m.Groups[1].Value, out value);
            }
            catch { return false; }
        }

        private static bool TryReadDouble(string json, string key, out double value)
        {
            value = 0.0;
            try
            {
                Match m = Regex.Match(json, "\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)", RegexOptions.IgnoreCase);
                return m.Success && Double.TryParse(m.Groups[1].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
            }
            catch { return false; }
        }

        private static int ClampByte(int v) { return Math.Max(0, Math.Min(255, v)); }
    }
}
