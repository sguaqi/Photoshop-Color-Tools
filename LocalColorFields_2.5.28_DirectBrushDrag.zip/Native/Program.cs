using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace LocalColorFieldsNativeHUD
{
internal sealed class HudApplicationContext : ApplicationContext
    {
        private readonly HudForm form;

        public HudApplicationContext(HudForm hud, bool showAtStart)
        {
            form = hud;
            MainForm = form;
            form.FormClosed += delegate { ExitThread(); };
            IntPtr unused = form.Handle; // create the hidden native window so hotkey/IPC can work
            if (showAtStart) form.BeginInvoke((MethodInvoker)delegate { form.ShowHud(); });
            else form.BeginInvoke((MethodInvoker)delegate { form.PrewarmHoldSurface(); });
        }
    }

internal static class Program
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")] private static extern bool PostMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")] private static extern bool SetProcessDPIAware();

        [STAThread]
        private static void Main(string[] args)
        {
            try { SetProcessDPIAware(); } catch { }

            bool showAtStart = true;
            bool ensureResident = false;
            bool followPhotoshop = false;

            for (int i = 0; i < args.Length; i++)
            {
                if (String.Equals(args[i], "--resident", StringComparison.OrdinalIgnoreCase))
                    showAtStart = false;
                else if (String.Equals(args[i], "--ensure-resident", StringComparison.OrdinalIgnoreCase))
                {
                    showAtStart = false;
                    ensureResident = true;
                }
                else if (String.Equals(args[i], "--follow-photoshop", StringComparison.OrdinalIgnoreCase))
                    followPhotoshop = true;
            }

            bool createdNew;
            using (Mutex mutex = new Mutex(true, "LocalColorFieldsNativeHUD_SingleInstance", out createdNew))
            {
                if (!createdNew)
                {
                    IntPtr hwnd = IntPtr.Zero;
                    for (int i = 0; i < 20 && hwnd == IntPtr.Zero; i++)
                    {
                        hwnd = FindWindow(null, HudForm.HostWindowTitle);
                        if (hwnd == IntPtr.Zero) Thread.Sleep(25);
                    }

                    // CEP startup/reload uses --ensure-resident. It must never toggle an already
                    // running HUD. If that existing instance was started manually, upgrade it in-place
                    // to Photoshop-follow mode so it will still close with the host.
                    if (ensureResident)
                    {
                        if (followPhotoshop && hwnd != IntPtr.Zero)
                            PostMessage(hwnd, HudForm.EnablePhotoshopFollowMessageId, IntPtr.Zero, IntPtr.Zero);
                        return;
                    }

                    if (hwnd != IntPtr.Zero)
                        PostMessage(hwnd, HudForm.TogglePersistentMessageId, IntPtr.Zero, IntPtr.Zero);
                    return;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                HudForm form = new HudForm(followPhotoshop);
                HudApplicationContext context = new HudApplicationContext(form, showAtStart);
                Application.Run(context);
            }
        }
    }
}
