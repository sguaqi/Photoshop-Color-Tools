Local Color Fields 2.5.28

Direct Brush Drag release based on the verified 2.5.27 HUD.

What stays unchanged
- F11 pressure-safe color HUD behavior remains on the 2.5.27 path.
- Hue + Chroma field, Lightness bar, marker handoff, CEP foreground-color bridge and Photoshop lifecycle behavior are retained.
- Photoshop remains the pen input target; no Alt + right-click HUD is used for the new brush controls.

New: Direct Brush Drag
- Two configurable hold keys: Brush Size and Brush Opacity.
- Hold the chosen key and move the pen/mouse horizontally.
- Each key-down captures the current pointer position and current Photoshop value as a fresh local zero point.
- Size: left shrinks, right grows. Mapping is proportional/exponential so travel feels similar at small and large sizes.
- Opacity: left lowers, right raises, clamped to 1-100%.
- No cursor warp, no Photoshop HUD, no simulated right mouse button, and no AutoHotkey dependency.
- Native pointer sampling and Photoshop parameter writes are decoupled; only the newest target value is kept while Photoshop is busy.

Default test keys
- Size: F9
- Opacity: F10
These are only defaults. Change both in Window > Extensions > Local Color Fields > Direct brush drag.
Map any two physical AK029 keys to the selected virtual keys in the keyboard driver. F11 is reserved for the color HUD and is intentionally unavailable here.

Tuning
- Size sensitivity = horizontal pixels needed to double/halve the current brush size. Smaller = faster. Default 140 px.
- Opacity sensitivity = horizontal pixels corresponding to a full 100% opacity change. Smaller = faster. Default 320 px.
- Center dead zone suppresses tiny pen-hover jitter around the press position. Default 2 px.

Photoshop bridge
- CEP now maintains brush_state.json alongside foreground_state.json.
- Native writes only the latest brush_command.json target.
- CEP prioritizes brush commands over foreground-color commands and idle state polling.
- Size uses Photoshop Action Manager masterDiameter so sampled/custom brush tips are not intentionally replaced.
- Opacity writes the Paint Brush tool opacity directly.

Install
1. Close Photoshop.
2. Run INSTALL_ALL_2.5.28.bat.
3. Restart Photoshop.
4. Open Window > Extensions > Local Color Fields and choose the two Direct brush drag keys.
5. In the AK029 driver, map the desired physical keys to those two virtual keys.

First test
- Select Photoshop Brush Tool (B).
- Put the pen over the canvas without pressing the pen tip.
- Hold Size key and move left/right. Release and draw immediately.
- Hold Opacity key and move left/right.

If a brush drag does nothing immediately after Photoshop startup, wait a fraction of a second for the CEP bridge to publish the first brush state, then test again.
