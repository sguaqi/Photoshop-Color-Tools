@echo off
taskkill /IM LocalColorFieldsNativeHUD.exe /F >nul 2>&1
