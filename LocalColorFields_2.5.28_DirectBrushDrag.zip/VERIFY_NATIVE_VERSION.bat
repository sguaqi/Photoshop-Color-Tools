@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "DEST=%APPDATA%\LocalColorFields\NativeHUD"
echo ============================================================
echo Local Color Fields - Native version check
echo ============================================================
echo Expected package version: 2.5.28
echo.
if exist "%DEST%\installed_version.txt" (
  set /p INSTALLED=<"%DEST%\installed_version.txt"
  echo Installed EXE version marker: %INSTALLED%
) else (
  echo Installed EXE version marker: NOT FOUND
)
if exist "%DEST%\running_version.txt" (
  set /p RUNNING=<"%DEST%\running_version.txt"
  echo Last running Native version: %RUNNING%
) else (
  echo Last running Native version: NOT FOUND
)
echo.
tasklist /FI "IMAGENAME eq LocalColorFieldsNativeHUD.exe"
echo.
echo You can also right-click the Local Color Fields tray icon; the first menu item shows the running version.
pause
