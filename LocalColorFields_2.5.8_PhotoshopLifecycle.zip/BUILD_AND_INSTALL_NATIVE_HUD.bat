﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul

echo ============================================================
echo Local Color Fields Native HUD 2.5.8
echo Local Hue+Chroma Field + Independent Lightness Bar
echo ============================================================
echo.
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo ERROR: .NET Framework C# compiler was not found.
  echo Expected csc.exe under C:\Windows\Microsoft.NET\Framework...
  pause
  exit /b 1
)

set "ROOT=%~dp0"
set "SRC=%ROOT%LocalColorFieldsNativeHUD.cs"
set "BUILD=%ROOT%build"
set "OUT=%BUILD%\LocalColorFieldsNativeHUD.exe"
set "DEST=%APPDATA%\LocalColorFields\NativeHUD"
set "PSDIR=D:\PhotoShopCC2018\Adobe Photoshop CC 2018\Presets\Scripts"
set "PSSCRIPT=%PSDIR%\Local Color Fields Quick.jsx"
set "BACKUP=%APPDATA%\LocalColorFields\backup"

if not exist "%BUILD%" mkdir "%BUILD%"

echo Compiling native HUD...
"%CSC%" /nologo /target:winexe /optimize+ /platform:anycpu /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:Microsoft.CSharp.dll /out:"%OUT%" "%SRC%"
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  pause
  exit /b 1
)

echo Build OK.
if not exist "%DEST%" mkdir "%DEST%"

echo Stopping previous HUD process...
taskkill /IM LocalColorFieldsNativeHUD.exe /F >nul 2>&1
timeout /t 1 /nobreak >nul

copy /Y "%OUT%" "%DEST%\LocalColorFieldsNativeHUD.exe" >nul
if errorlevel 1 (
  echo ERROR: Could not copy EXE to %DEST%
  pause
  exit /b 1
)

if not exist "%BACKUP%" mkdir "%BACKUP%"
if exist "%PSSCRIPT%" copy /Y "%PSSCRIPT%" "%BACKUP%\Local Color Fields Quick_PreNative250_Backup.jsx" >nul

if not exist "%PSDIR%" (
  echo.
  echo WARNING: Photoshop Scripts folder was not found:
  echo %PSDIR%
  echo HUD installed, but Photoshop shortcut script was not copied.
  goto launch
)

copy /Y "%ROOT%Local Color Fields Quick.jsx" "%PSSCRIPT%" >nul
if errorlevel 1 (
  echo.
  echo WARNING: Could not update Photoshop shortcut script.
  echo Run this BAT as administrator and try again.
) else (
  echo Photoshop shortcut bridge installed.
)

:launch
echo.
tasklist /FI "IMAGENAME eq Photoshop.exe" 2>nul | find /I "Photoshop.exe" >nul
if not errorlevel 1 (
  echo Photoshop is running. Starting lifecycle-bound resident HUD...
  start "" "%DEST%\LocalColorFieldsNativeHUD.exe" --ensure-resident --follow-photoshop
) else (
  echo Photoshop is not running. HUD will start automatically with Photoshop.
)

echo.
echo Installed native HUD:
echo   %DEST%\LocalColorFieldsNativeHUD.exe
echo.
echo 2.5.8 keeps the 2.5.7 low-latency hover picker and adds Photoshop lifecycle binding.
echo The resident HUD now starts with Photoshop through CEP and exits automatically after Photoshop closes.
echo The HUD is pre-rendered while hidden and CapsLock uses a keyboard hook instead of timer polling.
echo Hold CapsLock, hover the pen without touching down, then release CapsLock to confirm.
echo The hold HUD is fully click-through so Photoshop remains the pen input target.
echo.
pause
