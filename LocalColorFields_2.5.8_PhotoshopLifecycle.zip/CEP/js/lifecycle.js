(function(){
"use strict";
var fs=null,path=null,child=null;
try{fs=require("fs");path=require("path");child=require("child_process");}catch(e){}

function ensureHud(){
  if(!fs||!path||!child)return;
  try{
    var exe=path.join(process.env.APPDATA||"","LocalColorFields","NativeHUD","LocalColorFieldsNativeHUD.exe");
    if(!fs.existsSync(exe))return;
    var p=child.spawn(exe,["--ensure-resident","--follow-photoshop"],{detached:true,stdio:"ignore",windowsHide:true});
    p.unref();
  }catch(e){}
}

// Photoshop fires applicationActivate on startup. A few short retries cover slow disk / CEP startup
// without creating duplicates because --ensure-resident is idempotent.
setTimeout(ensureHud,80);
setTimeout(ensureHud,700);
setTimeout(ensureHud,2200);
})();
