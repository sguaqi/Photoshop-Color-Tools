(function(){
"use strict";
var $=function(id){return document.getElementById(id);};
var fs=null,path=null,child=null,saveTimer=0,statusTimer=0;
try{fs=require("fs");path=require("path");child=require("child_process");}catch(e){}

var defaults={
  fieldSize:260,lightBarWidth:34,lightBarSide:"right",gap:10,cornerRadius:8,markerSize:12,cursorOffset:18,
  hueRange:45,chromaRange:8,chromaMin:0,chromaMax:35,
  lightnessRange:20,lightnessMin:5,lightnessMax:95,
  refreshAfterPick:true,closeOnPhotoshopClick:true,enableHoldF13:true
};
var state={};
function cloneDefaults(){var o={},k;for(k in defaults)if(defaults.hasOwnProperty(k))o[k]=defaults[k];return o;}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function boolValue(v,fallback){return typeof v==="boolean"?v:fallback;}
function num(v,fallback){v=Number(v);return isFinite(v)?v:fallback;}
function str(v,fallback){return typeof v==="string"&&v?v:fallback;}
function settingsPath(){if(!path)return null;var base=process.env.APPDATA||"";return path.join(base,"LocalColorFields","settings.json");}
function load(){
  state=cloneDefaults();
  try{var p=settingsPath();if(p&&fs&&fs.existsSync(p)){var raw=JSON.parse(fs.readFileSync(p,"utf8")),k;for(k in raw)if(raw.hasOwnProperty(k))state[k]=raw[k];}}catch(e){}

  state.fieldSize=clamp(num(state.fieldSize,num(state.innerSize,num(state.multiHeight,260))),120,620);
  state.lightBarWidth=clamp(num(state.lightBarWidth,34),18,120);
  state.lightBarSide=/^left$/i.test(str(state.lightBarSide,"right"))?"left":"right";
  state.gap=clamp(num(state.gap,10),2,60);
  state.cornerRadius=clamp(num(state.cornerRadius,8),0,32);
  state.markerSize=clamp(num(state.markerSize,12),8,30);
  state.cursorOffset=clamp(num(state.cursorOffset,18),0,80);

  state.hueRange=clamp(num(state.hueRange,num(state.multiHueRange,45)),5,180);
  state.chromaRange=clamp(num(state.chromaRange,8),0.5,30);
  state.chromaMin=clamp(num(state.chromaMin,0),0,59.5);
  state.chromaMax=clamp(num(state.chromaMax,35),0.5,60);
  if(state.chromaMin>=state.chromaMax)state.chromaMin=Math.max(0,state.chromaMax-0.5);

  state.lightnessRange=clamp(num(state.lightnessRange,num(state.hlLRange,20)),1,49.5);
  state.lightnessMin=clamp(num(state.lightnessMin,num(state.hlBlack,5)),0,99);
  state.lightnessMax=clamp(num(state.lightnessMax,num(state.hlWhite,95)),1,100);
  if(state.lightnessMin>=state.lightnessMax)state.lightnessMin=Math.max(0,state.lightnessMax-1);

  state.refreshAfterPick=boolValue(state.refreshAfterPick,true);
  state.closeOnPhotoshopClick=boolValue(state.closeOnPhotoshopClick,true);
  state.enableHoldF13=boolValue(state.enableHoldF13,true);
}
function addCompatibilityKeys(){
  state.innerSize=state.fieldSize;state.multiHeight=state.fieldSize;state.multiHueRange=state.hueRange;
  state.hlLRange=state.lightnessRange;state.hlBlack=state.lightnessMin;state.hlWhite=state.lightnessMax;
}
function write(){
  if(!fs||!path)return false;
  try{
    addCompatibilityKeys();
    var p=settingsPath(),dir=path.dirname(p);
    if(!fs.existsSync(dir))fs.mkdirSync(dir);
    fs.writeFileSync(p,JSON.stringify(state,null,2),"utf8");
    return true;
  }catch(e){setStatus("Save failed",true);return false;}
}
function setStatus(text,error){var box=$("saveState"),label=$("saveText");label.textContent=text;box.className="saveState "+(error?"error":"saved");clearTimeout(statusTimer);statusTimer=setTimeout(function(){box.className="saveState";},1300);}
function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(function(){if(write())setStatus("Saved · HUD updates automatically",false);},90);}
function setPair(rangeId,numId,key,min,max,round){var r=$(rangeId),n=$(numId);function apply(v){v=clamp(num(v,state[key]),min,max);if(round)v=Math.round(v);state[key]=v;r.value=v;n.value=v;scheduleSave();}r.addEventListener("input",function(){apply(this.value);});n.addEventListener("input",function(){apply(this.value);});n.addEventListener("change",function(){apply(this.value);});r.value=state[key];n.value=state[key];}
function normalizeBounds(changed){
  if(changed==="chromaMin"&&state.chromaMin>=state.chromaMax)state.chromaMin=Math.max(0,state.chromaMax-0.5);
  if(changed==="chromaMax"&&state.chromaMax<=state.chromaMin)state.chromaMax=Math.min(60,state.chromaMin+0.5);
  if(changed==="lightnessMin"&&state.lightnessMin>=state.lightnessMax)state.lightnessMin=Math.max(0,state.lightnessMax-1);
  if(changed==="lightnessMax"&&state.lightnessMax<=state.lightnessMin)state.lightnessMax=Math.min(100,state.lightnessMin+1);
}
function setNumber(id,key,min,max,round){var el=$(id);function apply(){var v=clamp(num(el.value,state[key]),min,max);if(round)v=Math.round(v);state[key]=v;normalizeBounds(key);el.value=state[key];if(key.indexOf("chroma")===0){$("chromaMin").value=state.chromaMin;$("chromaMax").value=state.chromaMax;}if(key.indexOf("lightness")===0){$("lightnessMin").value=state.lightnessMin;$("lightnessMax").value=state.lightnessMax;}scheduleSave();}el.value=state[key];el.addEventListener("input",apply);el.addEventListener("change",apply);}
function setToggle(id,key){var el=$(id);el.checked=!!state[key];el.addEventListener("change",function(){state[key]=!!el.checked;scheduleSave();});}
function setLightBarSide(){
  var left=$("lightBarLeft"),right=$("lightBarRight");
  function render(){left.className=state.lightBarSide==="left"?"active":"";right.className=state.lightBarSide==="right"?"active":"";}
  left.addEventListener("click",function(){state.lightBarSide="left";render();scheduleSave();});
  right.addEventListener("click",function(){state.lightBarSide="right";render();scheduleSave();});
  render();
}
function render(){
  setPair("fieldSize","fieldSizeN","fieldSize",120,620,true);
  setPair("lightBarWidthR","lightBarWidth","lightBarWidth",18,120,true);
  setLightBarSide();
  setNumber("gap","gap",2,60,true);setNumber("cornerRadius","cornerRadius",0,32,true);setNumber("markerSize","markerSize",8,30,true);setNumber("cursorOffset","cursorOffset",0,80,true);

  setPair("hueRange","hueRangeN","hueRange",5,180,true);
  setPair("chromaRange","chromaRangeN","chromaRange",0.5,30,false);
  setNumber("chromaMin","chromaMin",0,59.5,false);setNumber("chromaMax","chromaMax",0.5,60,false);

  setPair("lightnessRange","lightnessRangeN","lightnessRange",1,49.5,false);
  setNumber("lightnessMin","lightnessMin",0,99,true);setNumber("lightnessMax","lightnessMax",1,100,true);

  setToggle("refreshAfterPick","refreshAfterPick");setToggle("closeOnPhotoshopClick","closeOnPhotoshopClick");setToggle("enableHoldF13","enableHoldF13");
}
function hudExePath(){if(!path)return null;return path.join(process.env.APPDATA||"","LocalColorFields","NativeHUD","LocalColorFieldsNativeHUD.exe");}
function spawnHud(args){if(!child||!path||!fs)return false;try{var exe=hudExePath();if(!exe||!fs.existsSync(exe))return false;var p=child.spawn(exe,args||[],{detached:true,stdio:"ignore",windowsHide:true});p.unref();return true;}catch(e){return false;}}
function ensureResidentHud(){spawnHud(["--ensure-resident","--follow-photoshop"]);}
function openHud(){if(write())setStatus("Saved",false);if(!child||!path){setStatus("Node access unavailable",true);return;}var exe=hudExePath();if(!exe||!fs||!fs.existsSync(exe)){setStatus("Native HUD is not installed",true);return;}if(!spawnHud([]))setStatus("Could not open HUD",true);}
function reset(){state=cloneDefaults();write();location.reload();}
load();render();$("openHud").addEventListener("click",openHud);$("reset").addEventListener("click",reset);setStatus("Settings ready",false);
// CEP starts with Photoshop. Ensure one hidden resident HUD without toggling an existing instance.
setTimeout(ensureResidentHud,180);
})();
