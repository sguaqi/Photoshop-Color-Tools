﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul

echo ============================================================
echo Local Color Fields 2.5.8 - Full Install
echo Local Hue+Chroma Field + Lightness Bar + Layered Alpha
echo ============================================================
echo.
echo 1. Install the settings-only CEP panel
call "%~dp0INSTALL_CEP_SETTINGS.bat"
if errorlevel 1 exit /b 1

echo.
echo 2. Build and install the native HUD
call "%~dp0BUILD_AND_INSTALL_NATIVE_HUD.bat"
if errorlevel 1 exit /b 1

echo.
echo Full installation complete.
echo Restart Photoshop once so the updated CEP panel is refreshed.
pause
