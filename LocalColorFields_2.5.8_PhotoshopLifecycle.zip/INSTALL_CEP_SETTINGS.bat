﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul

set "SRC=%~dp0CEP"
set "DST=%APPDATA%\Adobe\CEP\extensions\LocalColorFields"

echo ============================================================
echo Local Color Fields 2.5.8 - HUD Settings CEP
echo ============================================================
echo.
echo Please CLOSE Photoshop before installing the CEP panel.
echo.

if not exist "%SRC%\CSXS\manifest.xml" (
  echo ERROR: CEP source folder is missing.
  pause
  exit /b 1
)

mkdir "%APPDATA%\Adobe\CEP\extensions" 2>nul
if exist "%DST%" rmdir /S /Q "%DST%"
mkdir "%DST%"
xcopy "%SRC%\*" "%DST%\" /E /I /Y >nul
if errorlevel 1 (
  echo ERROR: CEP copy failed.
  pause
  exit /b 1
)

reg add "HKCU\Software\Adobe\CSXS.8" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

echo Installed:
echo   %DST%
echo.
echo Photoshop after restart:
echo   Window ^> Extensions ^> Local Color Fields
echo.
echo This panel is settings-only. It controls the local Hue+Chroma field and Lightness bar.
echo The old color canvases / Quick CEP window are not part of the extension bundle.
echo.
pause
