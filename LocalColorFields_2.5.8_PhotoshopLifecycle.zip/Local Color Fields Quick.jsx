#target photoshop
(function () {
    try {
        var appData = $.getenv("APPDATA");
        if (!appData) throw new Error("APPDATA is empty");
        var exe = new File(appData + "/LocalColorFields/NativeHUD/LocalColorFieldsNativeHUD.exe");
        if (!exe.exists) throw new Error("Native HUD is not installed:\n" + exe.fsName);
        var cmd = new File(exe.fsName);
        cmd.execute();
    } catch (e) {
        alert("Could not open Local Color Fields Native HUD.\n" + e.toString());
    }
})();
