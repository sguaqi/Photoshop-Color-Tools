﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace LocalColorFieldsNativeHUD
{
    internal struct RgbColor
    {
        public int R;
        public int G;
        public int B;
        public RgbColor(int r, int g, int b) { R = r; G = g; B = b; }
    }

    internal struct LchColor
    {
        public double L;
        public double C;
        public double H;
        public LchColor(double l, double c, double h) { L = l; C = c; H = h; }
    }

    internal sealed class HudSettings
    {
        // 2.5.8: retains the low-latency pressure-safe picker and adds Photoshop-bound resident lifecycle management.
        // Pressure-safe hover-pick hold mode + performance build; legacy settings remain compatible.
        // Legacy keys are still accepted as fallbacks so existing installs migrate cleanly.
        public int FieldSize = 260;
        public int LightBarWidth = 34;
        public string LightBarSide = "right";
        public int Gap = 10;
        public double CornerRadiusPercent = 8.0;
        public int MarkerSize = 12;
        public int CursorOffset = 18;

        public double HueRange = 45.0;
        public double ChromaRange = 8.0;
        public double ChromaMin = 0.0;
        public double ChromaMax = 35.0;

        public double LightnessRange = 20.0;
        public double LightnessMin = 5.0;
        public double LightnessMax = 95.0;

        public bool RefreshAfterPick = true;
        public bool CloseOnPhotoshopClick = true;
        public bool EnableHoldF13 = true;

        public static HudSettings Load()
        {
            HudSettings s = new HudSettings();
            try
            {
                string path = SettingsPath;
                if (!File.Exists(path)) return s;
                string json = File.ReadAllText(path);

                int legacyInner = ClampInt(ReadNumber(json, "innerSize", ReadNumber(json, "multiHeight", s.FieldSize)), 80, 600);
                int legacyRing = ClampInt(ReadNumber(json, "ringThickness", 50), 12, 180);

                s.FieldSize = ClampInt(ReadNumber(json, "fieldSize", legacyInner), 120, 620);
                s.LightBarWidth = ClampInt(ReadNumber(json, "lightBarWidth", Math.Max(24, (int)Math.Round(legacyRing * 0.68))), 18, 120);
                string side = ReadString(json, "lightBarSide", s.LightBarSide);
                s.LightBarSide = String.Equals(side, "left", StringComparison.OrdinalIgnoreCase) ? "left" : "right";
                s.Gap = ClampInt(ReadNumber(json, "gap", s.Gap), 2, 60);
                s.CornerRadiusPercent = Clamp(ReadNumberDouble(json, "cornerRadius", s.CornerRadiusPercent), 0, 32);
                s.MarkerSize = ClampInt(ReadNumber(json, "markerSize", s.MarkerSize), 8, 30);
                s.CursorOffset = ClampInt(ReadNumber(json, "cursorOffset", s.CursorOffset), 0, 80);

                s.HueRange = Clamp(ReadNumberDouble(json, "hueRange", ReadNumberDouble(json, "multiHueRange", s.HueRange)), 5, 180);
                s.ChromaRange = Clamp(ReadNumberDouble(json, "chromaRange", s.ChromaRange), 0.5, 30);
                s.ChromaMin = Clamp(ReadNumberDouble(json, "chromaMin", s.ChromaMin), 0, 59.5);
                s.ChromaMax = Clamp(ReadNumberDouble(json, "chromaMax", s.ChromaMax), 0.5, 60);
                if (s.ChromaMin >= s.ChromaMax) s.ChromaMin = Math.Max(0, s.ChromaMax - 0.5);

                s.LightnessRange = Clamp(ReadNumberDouble(json, "lightnessRange", ReadNumberDouble(json, "hlLRange", s.LightnessRange)), 1, 49.5);
                s.LightnessMin = Clamp(ReadNumberDouble(json, "lightnessMin", ReadNumberDouble(json, "hlBlack", s.LightnessMin)), 0, 99);
                s.LightnessMax = Clamp(ReadNumberDouble(json, "lightnessMax", ReadNumberDouble(json, "hlWhite", s.LightnessMax)), 1, 100);
                if (s.LightnessMin >= s.LightnessMax) s.LightnessMin = Math.Max(0, s.LightnessMax - 1);

                s.RefreshAfterPick = ReadBool(json, "refreshAfterPick", s.RefreshAfterPick);
                s.CloseOnPhotoshopClick = ReadBool(json, "closeOnPhotoshopClick", s.CloseOnPhotoshopClick);
                s.EnableHoldF13 = ReadBool(json, "enableHoldF13", s.EnableHoldF13);
            }
            catch { }
            return s;
        }

        private static int ReadNumber(string json, string key, int fallback)
        {
            double d = ReadNumberDouble(json, key, fallback);
            if (Double.IsNaN(d) || Double.IsInfinity(d)) return fallback;
            return (int)Math.Round(d);
        }

        private static double ReadNumberDouble(string json, string key, double fallback)
        {
            Match m = Regex.Match(json, "\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)", RegexOptions.IgnoreCase);
            if (!m.Success) return fallback;
            double v;
            if (!Double.TryParse(m.Groups[1].Value, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v)) return fallback;
            return v;
        }

        private static bool ReadBool(string json, string key, bool fallback)
        {
            Match m = Regex.Match(json, "\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*(true|false)", RegexOptions.IgnoreCase);
            if (!m.Success) return fallback;
            return String.Equals(m.Groups[1].Value, "true", StringComparison.OrdinalIgnoreCase);
        }

        private static string ReadString(string json, string key, string fallback)
        {
            Match m = Regex.Match(json, "\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"", RegexOptions.IgnoreCase);
            if (!m.Success) return fallback;
            return m.Groups[1].Value;
        }

        public static string SettingsPath
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "LocalColorFields", "settings.json");
            }
        }

        public static DateTime SettingsWriteTimeUtc()
        {
            try { return File.Exists(SettingsPath) ? File.GetLastWriteTimeUtc(SettingsPath) : DateTime.MinValue; }
            catch { return DateTime.MinValue; }
        }

        private static int ClampInt(int v, int lo, int hi) { return Math.Max(lo, Math.Min(hi, v)); }
        private static double Clamp(double v, double lo, double hi) { return Math.Max(lo, Math.Min(hi, v)); }
    }


    internal static class ColorMath
    {
        public static double Clamp(double v, double lo, double hi) { return Math.Max(lo, Math.Min(hi, v)); }
        public static double WrapHue(double h) { h %= 360.0; if (h < 0) h += 360.0; return h; }

        private static double SrgbToLinear(double v)
        {
            v /= 255.0;
            return v <= 0.04045 ? v / 12.92 : Math.Pow((v + 0.055) / 1.055, 2.4);
        }

        private static double LinearToSrgb(double v)
        {
            v = v <= 0.0031308 ? 12.92 * v : 1.055 * Math.Pow(v, 1.0 / 2.4) - 0.055;
            return 255.0 * v;
        }

        private static double Cbrt(double v)
        {
            if (v < 0) return -Math.Pow(-v, 1.0 / 3.0);
            return Math.Pow(v, 1.0 / 3.0);
        }

        public static LchColor RgbToLch(RgbColor rgb)
        {
            double R = SrgbToLinear(rgb.R), G = SrgbToLinear(rgb.G), B = SrgbToLinear(rgb.B);
            double l = 0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B;
            double m = 0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B;
            double s = 0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B;
            double ll = Cbrt(l), mm = Cbrt(m), ss = Cbrt(s);
            double L = 0.2104542553 * ll + 0.7936177850 * mm - 0.0040720468 * ss;
            double a = 1.9779984951 * ll - 2.4285922050 * mm + 0.4505937099 * ss;
            double bb = 0.0259040371 * ll + 0.7827717662 * mm - 0.8086757660 * ss;
            double C = Math.Sqrt(a * a + bb * bb);
            double h = Math.Atan2(bb, a) * 180.0 / Math.PI;
            if (h < 0) h += 360.0;
            return new LchColor(L * 100.0, C * 100.0, h);
        }

        private static void OklchToRawRgb(double L100, double C100, double cosH, double sinH, out double r, out double g, out double b)
        {
            double L = L100 / 100.0, C = C100 / 100.0;
            double a = C * cosH, bb = C * sinH;
            double ll = L + 0.3963377774 * a + 0.2158037573 * bb;
            double mm = L - 0.1055613458 * a - 0.0638541728 * bb;
            double ss = L - 0.0894841775 * a - 1.2914855480 * bb;
            double l = ll * ll * ll, m = mm * mm * mm, ss3 = ss * ss * ss;
            r = LinearToSrgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * ss3);
            g = LinearToSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * ss3);
            b = LinearToSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * ss3);
        }

        private static bool InGamut(double r, double g, double b)
        {
            return !Double.IsNaN(r) && !Double.IsNaN(g) && !Double.IsNaN(b) &&
                   !Double.IsInfinity(r) && !Double.IsInfinity(g) && !Double.IsInfinity(b) &&
                   r >= 0 && r <= 255 && g >= 0 && g <= 255 && b >= 0 && b <= 255;
        }

        public static RgbColor LchToRgb(double L, double C, double h, int iterations)
        {
            double rad = WrapHue(h) * Math.PI / 180.0;
            return LchToRgbWithDirection(L, C, Math.Cos(rad), Math.Sin(rad), iterations);
        }

        public static RgbColor LchToRgbWithDirection(double L, double C, double cosH, double sinH, int iterations)
        {
            L = Clamp(L, 0, 100); C = Math.Max(0, C);
            double r, g, b;
            OklchToRawRgb(L, C, cosH, sinH, out r, out g, out b);
            if (InGamut(r, g, b)) return new RgbColor((int)Math.Round(r), (int)Math.Round(g), (int)Math.Round(b));
            double low = 0, high = C, best = 0;
            for (int i = 0; i < iterations; i++)
            {
                double mid = (low + high) * 0.5;
                OklchToRawRgb(L, mid, cosH, sinH, out r, out g, out b);
                if (InGamut(r, g, b)) { best = mid; low = mid; } else high = mid;
            }
            OklchToRawRgb(L, best, cosH, sinH, out r, out g, out b);
            return new RgbColor((int)Math.Round(Clamp(r, 0, 255)), (int)Math.Round(Clamp(g, 0, 255)), (int)Math.Round(Clamp(b, 0, 255)));
        }

        public static double MultiScale(double ty)
        {
            if (ty <= 0.5) return 1.0 + 0.85 * ((0.5 - ty) / 0.5);
            return 1.0 - 0.82 * ((ty - 0.5) / 0.5);
        }
    }

    internal static class PhotoshopBridge
    {
        public static bool TryGetForeground(out RgbColor rgb, out string error)
        {
            rgb = new RgbColor(128, 128, 128);
            error = null;
            object app = null;
            try
            {
                app = Marshal.GetActiveObject("Photoshop.Application");
                dynamic ps = app;
                string script = "try {var c=app.foregroundColor.rgb;Math.round(c.red)+','+Math.round(c.green)+','+Math.round(c.blue);} catch(e) {'ERR:'+e.toString();}";
                object result = ps.DoJavaScript(script);
                string text = Convert.ToString(result);
                if (!String.IsNullOrEmpty(text) && !text.StartsWith("ERR:", StringComparison.OrdinalIgnoreCase))
                {
                    string[] p = text.Split(',');
                    int r, g, b;
                    if (p.Length == 3 && Int32.TryParse(p[0], out r) && Int32.TryParse(p[1], out g) && Int32.TryParse(p[2], out b))
                    {
                        rgb = new RgbColor(r, g, b);
                        return true;
                    }
                }
                error = "Photoshop returned: " + text;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                try
                {
                    if (app != null)
                    {
                        dynamic ps = app;
                        dynamic fg = ps.ForegroundColor;
                        dynamic c = fg.RGB;
                        rgb = new RgbColor((int)Math.Round(Convert.ToDouble(c.Red)), (int)Math.Round(Convert.ToDouble(c.Green)), (int)Math.Round(Convert.ToDouble(c.Blue)));
                        return true;
                    }
                }
                catch { }
            }
            finally
            {
                try { if (app != null && Marshal.IsComObject(app)) Marshal.FinalReleaseComObject(app); } catch { }
            }
            return false;
        }

        public static bool TrySetForeground(RgbColor rgb, out string error)
        {
            error = null;
            object app = null;
            try
            {
                app = Marshal.GetActiveObject("Photoshop.Application");
                dynamic ps = app;
                string script = "try {var c=new SolidColor();c.rgb.red=" + rgb.R + ";c.rgb.green=" + rgb.G + ";c.rgb.blue=" + rgb.B + ";app.foregroundColor=c;'OK';} catch(e) {'ERR:'+e.toString();}";
                object result = ps.DoJavaScript(script);
                string text = Convert.ToString(result);
                if (String.Equals(text, "OK", StringComparison.OrdinalIgnoreCase)) return true;
                error = "Photoshop returned: " + text;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                try
                {
                    if (app != null)
                    {
                        dynamic ps = app;
                        dynamic fg = ps.ForegroundColor;
                        dynamic c = fg.RGB;
                        c.Red = rgb.R; c.Green = rgb.G; c.Blue = rgb.B;
                        ps.ForegroundColor = fg;
                        return true;
                    }
                }
                catch { }
            }
            finally
            {
                try { if (app != null && Marshal.IsComObject(app)) Marshal.FinalReleaseComObject(app); } catch { }
            }
            return false;
        }
    }

    internal sealed class HudForm : Form
    {
        private const int WM_TOGGLE_PERSISTENT = 0x8000 + 421;
        private const int WM_ENABLE_PHOTOSHOP_FOLLOW = 0x8000 + 422;
        private const int VK_LBUTTON = 0x01;
        private const int WS_EX_TOOLWINDOW = 0x00000080;
        private const int WS_EX_LAYERED = 0x00080000;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WS_EX_TRANSPARENT = 0x00000020;
        private const int GWL_EXSTYLE = -20;
        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOMOVE = 0x0002;
        private const uint SWP_NOZORDER = 0x0004;
        private const uint SWP_NOACTIVATE = 0x0010;
        private const uint SWP_FRAMECHANGED = 0x0020;
        private const int WM_NCHITTEST = 0x0084;
        private const int WM_MOUSEACTIVATE = 0x0021;
        private const int WM_MOUSEMOVE = 0x0200;
        private const int WM_LBUTTONUP = 0x0202;
        private const int MA_NOACTIVATE = 3;
        private const int WH_MOUSE_LL = 14;
        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_KEYUP = 0x0101;
        private const int WM_SYSKEYDOWN = 0x0104;
        private const int WM_SYSKEYUP = 0x0105;
        private const int VK_CAPITAL = 0x14;
        private const int HTCLIENT = 1;
        private const int HTTRANSPARENT = -1;
        private const int ULW_ALPHA = 0x00000002;
        private const byte AC_SRC_OVER = 0x00;
        private const byte AC_SRC_ALPHA = 0x01;
        internal const string HostWindowTitle = "LCF_NATIVE_HUD_HOST";

        [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int vKey);
        [DllImport("user32.dll")] private static extern IntPtr WindowFromPoint(NativePoint point);
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
        [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("user32.dll", SetLastError = true)] private static extern bool UpdateLayeredWindow(
            IntPtr hwnd, IntPtr hdcDst, ref NativePoint pptDst, ref NativeSize psize,
            IntPtr hdcSrc, ref NativePoint pptSrc, int crKey, ref BlendFunction pblend, int dwFlags);
        [DllImport("gdi32.dll")] private static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        [DllImport("gdi32.dll")] private static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll")] private static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);
        [DllImport("gdi32.dll")] private static extern bool DeleteObject(IntPtr hObject);
        [DllImport("user32.dll", SetLastError = true)] private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll", EntryPoint = "SetWindowsHookEx", SetLastError = true)] private static extern IntPtr SetWindowsKeyboardHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll", SetLastError = true)] private static extern bool UnhookWindowsHookEx(IntPtr hhk);
        [DllImport("user32.dll")] private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr GetModuleHandle(string lpModuleName);
        [DllImport("user32.dll", SetLastError = true)] private static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        [DllImport("user32.dll", SetLastError = true)] private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
        [DllImport("user32.dll", SetLastError = true)] private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        private HudSettings settings = new HudSettings();
        private LchColor baseLch = new LchColor(53.6, 0, 0);
        private Bitmap colorBitmap;
        private Bitmap lightBitmap;
        private Bitmap staticSurfaceBitmap;
        private Bitmap frameSurfaceBitmap;
        private Graphics frameSurfaceGraphics;

        private Rectangle colorRect;
        private Rectangle lightRect;
        private float colorCornerRadius;
        private float lightCornerRadius;

        // Sliding local windows. They follow the selected color while possible,
        // then stop at the user-defined min/max boundary. Hue always follows.
        private double chromaWindowCenter = 8.0;
        private double lightnessWindowCenter = 50.0;

        private Point colorMarker = Point.Empty;
        private Point lightMarker = Point.Empty;
        private bool dragging = false;
        private ActiveField activeField = ActiveField.Color;

        // 2.5.3 legacy persistent-mode handoff: mouse drag avoids capture when the passive hook is available.
        // Pressure-safe pen path no longer uses a drag at all: Hold mode is fully click-through
        // and reads only Cursor.Position while the pen is hovering.
        private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);
        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
        private readonly object passiveInputGate = new object();
        private LowLevelMouseProc passiveMouseProc;
        private IntPtr passiveMouseHook = IntPtr.Zero;
        private bool passiveTracking = false;
        private bool fallbackCapture = false;
        private bool passiveMovePending = false;
        private bool passiveUpPending = false;
        private Point passiveScreenPoint = Point.Empty;

        // Low-latency hold-key path. A keyboard hook removes the 0-15 ms polling delay.
        // If Windows refuses the hook, the old GetAsyncKeyState timer remains as a fallback.
        private LowLevelKeyboardProc keyboardProc;
        private IntPtr keyboardHook = IntPtr.Zero;
        private bool holdKeyDown = false;

        // Hold surface is prepared while hidden. Hotkey-down should only reposition + show it.
        private bool holdSurfacePrepared = false;
        private DateTime deferredPrewarmUtc = DateTime.MinValue;
        private bool hasLastSourceRgb = false;
        private RgbColor lastSourceRgb = new RgbColor(128, 128, 128);
        private int foregroundSyncSerial = 0;

        // Hold-hover selection state. No mouse/pen down is accepted in Hold mode.
        private bool holdHasCandidate = false;
        private RgbColor holdCandidate = new RgbColor(0, 0, 0);
        private Point holdLastScreenPoint = Point.Empty;
        private bool holdClickThroughApplied = false;

        private NotifyIcon tray;
        private bool lastPsErrorShown = false;

        // Photoshop lifecycle binding. When the HUD is launched by the CEP panel with
        // --follow-photoshop it stays resident only while Photoshop is alive.
        // This prevents orphan HUD processes after Photoshop exits or crashes.
        private bool followPhotoshopLifecycle;
        private bool photoshopHostSeen = false;
        private DateTime photoshopStartupDeadlineUtc = DateTime.MinValue;
        private DateTime photoshopMissingSinceUtc = DateTime.MinValue;
        private DateTime nextPhotoshopLifecycleCheckUtc = DateTime.MinValue;

        private System.Windows.Forms.Timer inputTimer;
        private bool f13WasDown = false;
        private bool leftWasDown = false;
        private DateTime shownAtUtc = DateTime.MinValue;
        private DateTime settingsWriteTimeUtc = DateTime.MinValue;
        private DateTime nextSettingsCheckUtc = DateTime.MinValue;

        private enum HudMode { Hidden, Persistent, Hold }
        private enum ActiveField { Color, Lightness }
        private HudMode hudMode = HudMode.Hidden;

        [StructLayout(LayoutKind.Sequential)]
        private struct NativePoint
        {
            public int X;
            public int Y;
            public NativePoint(int x, int y) { X = x; Y = y; }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct NativeSize
        {
            public int CX;
            public int CY;
            public NativeSize(int cx, int cy) { CX = cx; CY = cy; }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct HookPoint
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MsLlHookStruct
        {
            public HookPoint Point;
            public uint MouseData;
            public uint Flags;
            public uint Time;
            public UIntPtr ExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct KbdLlHookStruct
        {
            public uint VkCode;
            public uint ScanCode;
            public uint Flags;
            public uint Time;
            public UIntPtr ExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct BlendFunction
        {
            public byte BlendOp;
            public byte BlendFlags;
            public byte SourceConstantAlpha;
            public byte AlphaFormat;
        }

        private struct AxisWindow
        {
            public double Center;
            public double Half;
            public double High;
            public double Low;
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_NOACTIVATE;
                return cp;
            }
        }

        public HudForm(bool followPhotoshop)
        {
            followPhotoshopLifecycle = followPhotoshop;
            if (followPhotoshopLifecycle)
            {
                photoshopHostSeen = IsPhotoshopProcessRunning();
                photoshopStartupDeadlineUtc = DateTime.UtcNow.AddSeconds(10);
                nextPhotoshopLifecycleCheckUtc = DateTime.UtcNow;
            }

            Text = HostWindowTitle;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            BackColor = Color.FromArgb(28, 28, 30);
            DoubleBuffered = true;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
            Cursor = Cursors.Cross;
            passiveMouseProc = PassiveMouseHookProc;
            keyboardProc = KeyboardHookProc;

            ContextMenuStrip menu = new ContextMenuStrip();
            ToolStripMenuItem showItem = new ToolStripMenuItem("Show HUD");
            showItem.Click += delegate { TogglePersistentHud(); };
            ToolStripMenuItem reloadItem = new ToolStripMenuItem("Reload settings");
            reloadItem.Click += delegate
            {
                settings = HudSettings.Load();
                settingsWriteTimeUtc = HudSettings.SettingsWriteTimeUtc();
                if (Visible) ApplySettingsLive();
            };
            ToolStripMenuItem exitItem = new ToolStripMenuItem("Exit");
            exitItem.Click += delegate { Close(); };
            menu.Items.Add(showItem);
            menu.Items.Add(reloadItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(exitItem);

            tray = new NotifyIcon();
            tray.Icon = SystemIcons.Application;
            tray.Text = "Local Color Fields Native HUD";
            tray.Visible = true;
            tray.ContextMenuStrip = menu;
            tray.DoubleClick += delegate { TogglePersistentHud(); };

            inputTimer = new System.Windows.Forms.Timer();
            inputTimer.Interval = 15;
            inputTimer.Tick += InputTimerTick;
            inputTimer.Start();

            MouseDown += HudMouseDown;
            MouseMove += HudMouseMove;
            MouseUp += HudMouseUp;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            InstallKeyboardHook();
        }

        private void InstallKeyboardHook()
        {
            if (keyboardHook != IntPtr.Zero || keyboardProc == null) return;
            try
            {
                IntPtr module = GetModuleHandle(null);
                keyboardHook = SetWindowsKeyboardHookEx(WH_KEYBOARD_LL, keyboardProc, module, 0);
            }
            catch { keyboardHook = IntPtr.Zero; }
        }

        private void RemoveKeyboardHook()
        {
            if (keyboardHook == IntPtr.Zero) return;
            try { UnhookWindowsHookEx(keyboardHook); } catch { }
            keyboardHook = IntPtr.Zero;
        }

        private bool IsPhotoshopForegroundWindow()
        {
            try
            {
                IntPtr hwnd = GetForegroundWindow();
                if (hwnd == IntPtr.Zero) return false;
                uint pid;
                GetWindowThreadProcessId(hwnd, out pid);
                if (pid == 0) return false;
                using (Process p = Process.GetProcessById((int)pid))
                    return p.ProcessName.StartsWith("Photoshop", StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        private static bool IsPhotoshopProcessRunning()
        {
            Process[] list = null;
            try
            {
                list = Process.GetProcessesByName("Photoshop");
                int sessionId = Process.GetCurrentProcess().SessionId;
                for (int i = 0; i < list.Length; i++)
                {
                    try
                    {
                        if (!list[i].HasExited && list[i].SessionId == sessionId) return true;
                    }
                    catch { }
                }
            }
            catch { }
            finally
            {
                if (list != null)
                {
                    for (int i = 0; i < list.Length; i++)
                    {
                        try { list[i].Dispose(); } catch { }
                    }
                }
            }
            return false;
        }

        private void CheckPhotoshopLifecycle()
        {
            if (!followPhotoshopLifecycle) return;

            DateTime now = DateTime.UtcNow;
            if (now < nextPhotoshopLifecycleCheckUtc) return;
            nextPhotoshopLifecycleCheckUtc = now.AddMilliseconds(400);

            bool running = IsPhotoshopProcessRunning();
            if (running)
            {
                photoshopHostSeen = true;
                photoshopMissingSinceUtc = DateTime.MinValue;
                return;
            }

            // During startup give Photoshop/CEP a generous grace period. Once the host has
            // been observed, only a short debounce is needed to avoid an orphan process.
            if (!photoshopHostSeen)
            {
                if (photoshopStartupDeadlineUtc != DateTime.MinValue && now < photoshopStartupDeadlineUtc) return;
                Close();
                return;
            }

            if (photoshopMissingSinceUtc == DateTime.MinValue)
            {
                photoshopMissingSinceUtc = now;
                return;
            }

            if ((now - photoshopMissingSinceUtc).TotalMilliseconds >= 900)
            {
                Close();
            }
        }

        private IntPtr KeyboardHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && settings.EnableHoldF13)
            {
                try
                {
                    KbdLlHookStruct data = (KbdLlHookStruct)Marshal.PtrToStructure(lParam, typeof(KbdLlHookStruct));
                    if (data.VkCode == VK_CAPITAL)
                    {
                        int msg = wParam.ToInt32();
                        bool isDown = msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN;
                        bool isUp = msg == WM_KEYUP || msg == WM_SYSKEYUP;

                        // Once a hold gesture starts, always consume its matching key-up even if focus moves.
                        if ((isDown && IsPhotoshopForegroundWindow()) || (isUp && holdKeyDown))
                        {
                            if (isDown && !holdKeyDown)
                            {
                                holdKeyDown = true;
                                try { BeginInvoke((MethodInvoker)delegate { BeginHoldHoverFast(); }); } catch { }
                            }
                            else if (isUp && holdKeyDown)
                            {
                                holdKeyDown = false;
                                try { BeginInvoke((MethodInvoker)delegate { FinishHoldHoverSelection(); }); } catch { }
                            }

                            // CapsLock is only a temporary test trigger. Swallow it while Photoshop is using
                            // the picker so it does not also toggle Photoshop's precise-cursor mode.
                            return new IntPtr(1);
                        }
                    }
                }
                catch { }
            }
            return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_MOUSEACTIVATE)
            {
                m.Result = new IntPtr(MA_NOACTIVATE);
                return;
            }

            if (m.Msg == WM_TOGGLE_PERSISTENT)
            {
                TogglePersistentHud();
                return;
            }

            if (m.Msg == WM_ENABLE_PHOTOSHOP_FOLLOW)
            {
                EnablePhotoshopLifecycleFollow();
                return;
            }

            if (m.Msg == WM_NCHITTEST)
            {
                // Hold mode is the pressure-safe pen path. The HUD is display-only and must never
                // become the pointer target; Photoshop remains the owner of pen down/up messages.
                if (hudMode == HudMode.Hold)
                {
                    m.Result = new IntPtr(HTTRANSPARENT);
                    return;
                }

                long raw = m.LParam.ToInt64();
                int sx = unchecked((short)(raw & 0xFFFF));
                int sy = unchecked((short)((raw >> 16) & 0xFFFF));
                Point client = PointToClient(new Point(sx, sy));
                if (IsPointInColor(client) || IsPointInLightness(client))
                    m.Result = new IntPtr(HTCLIENT);
                else
                    m.Result = new IntPtr(HTTRANSPARENT);
                return;
            }

            base.WndProc(ref m);
        }

        public static int TogglePersistentMessageId { get { return WM_TOGGLE_PERSISTENT; } }
        public static int EnablePhotoshopFollowMessageId { get { return WM_ENABLE_PHOTOSHOP_FOLLOW; } }

        private void EnablePhotoshopLifecycleFollow()
        {
            followPhotoshopLifecycle = true;
            photoshopHostSeen = IsPhotoshopProcessRunning();
            photoshopStartupDeadlineUtc = DateTime.UtcNow.AddSeconds(10);
            photoshopMissingSinceUtc = DateTime.MinValue;
            nextPhotoshopLifecycleCheckUtc = DateTime.UtcNow;
        }

        private void InputTimerTick(object sender, EventArgs e)
        {
            CheckPhotoshopLifecycle();
            if (IsDisposed || Disposing) return;

            ProcessPassiveInput();

            bool fallbackHoldDown = keyboardHook == IntPtr.Zero && settings.EnableHoldF13 && (GetAsyncKeyState(VK_CAPITAL) & 0x8000) != 0;
            bool holdDownNow = keyboardHook != IntPtr.Zero ? holdKeyDown : fallbackHoldDown;
            if (inputTimer != null)
                inputTimer.Interval = (dragging && passiveTracking) || (hudMode == HudMode.Hold && holdDownNow) ? 5 : 15;

            if (hudMode == HudMode.Hidden && deferredPrewarmUtc != DateTime.MinValue && DateTime.UtcNow >= deferredPrewarmUtc)
            {
                deferredPrewarmUtc = DateTime.MinValue;
                PrepareHoldSurface(false);
            }

            if (DateTime.UtcNow >= nextSettingsCheckUtc)
            {
                nextSettingsCheckUtc = DateTime.UtcNow.AddMilliseconds(220);
                DateTime wt = HudSettings.SettingsWriteTimeUtc();
                if (wt != settingsWriteTimeUtc)
                {
                    settings = HudSettings.Load();
                    settingsWriteTimeUtc = wt;
                    if (Visible) ApplySettingsLive();
                    else
                    {
                        holdSurfacePrepared = false;
                        deferredPrewarmUtc = DateTime.UtcNow.AddMilliseconds(40);
                    }
                }
            }

            // Timer fallback only. Normally the low-level keyboard hook starts/finishes Hold mode instantly.
            if (keyboardHook == IntPtr.Zero)
            {
                if (fallbackHoldDown && !f13WasDown)
                {
                    holdKeyDown = true;
                    BeginHoldHoverFast();
                }
                else if (!fallbackHoldDown && f13WasDown && hudMode == HudMode.Hold)
                {
                    holdKeyDown = false;
                    FinishHoldHoverSelection();
                }
                f13WasDown = fallbackHoldDown;
            }

            if (holdDownNow && hudMode == HudMode.Hold && Visible)
                ProcessHoldHoverSelection();

            bool leftDown = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
            if (settings.CloseOnPhotoshopClick && leftDown && !leftWasDown && Visible && hudMode == HudMode.Persistent)
            {
                if ((DateTime.UtcNow - shownAtUtc).TotalMilliseconds > 120)
                {
                    Point screenPoint = Cursor.Position;
                    if (!IsPointOnHud(screenPoint) && IsPhotoshopAt(screenPoint))
                        HideHud();
                }
            }
            leftWasDown = leftDown;
        }

        private void ApplyHoldClickThrough(bool enabled)
        {
            if (!IsHandleCreated) return;
            if (holdClickThroughApplied == enabled) return;
            try
            {
                int ex = GetWindowLong(Handle, GWL_EXSTYLE);
                int desired = enabled ? (ex | WS_EX_TRANSPARENT) : (ex & ~WS_EX_TRANSPARENT);
                if (desired != ex)
                {
                    SetWindowLong(Handle, GWL_EXSTYLE, desired);
                    SetWindowPos(Handle, IntPtr.Zero, 0, 0, 0, 0,
                        SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
                }
                holdClickThroughApplied = enabled;
            }
            catch
            {
                // WM_NCHITTEST still returns HTTRANSPARENT in Hold mode as a second safety layer.
                holdClickThroughApplied = enabled;
            }
        }

        private void ResetHoldHoverSelection()
        {
            holdHasCandidate = false;
            holdLastScreenPoint = Point.Empty;
        }

        private void ProcessHoldHoverSelection()
        {
            if (hudMode != HudMode.Hold || !Visible) return;

            Point screenPoint = Cursor.Position;
            if (screenPoint == holdLastScreenPoint) return;
            holdLastScreenPoint = screenPoint;

            Point client = PointToClient(screenPoint);
            ActiveField nextField;
            Point marker;
            RgbColor candidate;

            if (IsPointInColor(client))
            {
                nextField = ActiveField.Color;
                marker = ClampPointToRoundedRect(client, colorRect, colorCornerRadius);
                candidate = ColorFromField(marker);
            }
            else if (IsPointInLightness(client))
            {
                nextField = ActiveField.Lightness;
                marker = ClampPointToRoundedRect(client, lightRect, lightCornerRadius);
                candidate = ColorFromLightness(marker);
            }
            else
            {
                // Leaving the HUD does not destroy the last valid pick. Releasing the hold key still commits it.
                return;
            }

            bool fieldChanged = activeField != nextField;
            activeField = nextField;
            bool markerChanged = SetActiveMarker(marker);
            holdCandidate = candidate;
            holdHasCandidate = true;

            if (fieldChanged || markerChanged) UpdateLayeredSurface();
        }

        private void FinishHoldHoverSelection()
        {
            if (hudMode != HudMode.Hold) return;

            bool shouldCommit = holdHasCandidate;
            RgbColor picked = holdCandidate;

            // Hide first. This restores the normal window style before Photoshop receives the color update,
            // and guarantees there is no HUD pointer target left for the user's first drawing stroke.
            HideHud();
            if (!shouldCommit) return;

            string error;
            if (PhotoshopBridge.TrySetForeground(picked, out error))
            {
                baseLch = ColorMath.RgbToLch(picked);
                lastSourceRgb = picked;
                hasLastSourceRgb = true;
                holdSurfacePrepared = false;

                // Rebuild while hidden instead of on the next key-down. A short defer keeps the
                // immediate post-pick drawing stroke free from our render work.
                deferredPrewarmUtc = DateTime.UtcNow.AddMilliseconds(90);
            }
            else
            {
                try { tray.ShowBalloonTip(2200, "Local Color Fields HUD", "Could not set Photoshop foreground color.\n" + error, ToolTipIcon.Warning); } catch { }
            }
        }

        private bool IsPointOnHud(Point screenPoint)
        {
            if (!Visible) return false;
            Point client = PointToClient(screenPoint);
            if (!ClientRectangle.Contains(client)) return false;
            return IsPointInColor(client) || IsPointInLightness(client);
        }

        private static bool IsPhotoshopAt(Point screenPoint)
        {
            try
            {
                IntPtr hwnd = WindowFromPoint(new NativePoint(screenPoint.X, screenPoint.Y));
                if (hwnd == IntPtr.Zero) return false;
                uint pid;
                GetWindowThreadProcessId(hwnd, out pid);
                if (pid == 0) return false;
                using (Process p = Process.GetProcessById((int)pid))
                    return p.ProcessName.StartsWith("Photoshop", StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        public void TogglePersistentHud()
        {
            if (Visible && hudMode == HudMode.Persistent) HideHud();
            else ShowHud(HudMode.Persistent);
        }

        public void ShowHud()
        {
            ShowHud(HudMode.Persistent);
        }

        public void PrewarmHoldSurface()
        {
            if (IsDisposed) return;
            PrepareHoldSurface(true);
        }

        private static bool SameRgb(RgbColor a, RgbColor b)
        {
            return a.R == b.R && a.G == b.G && a.B == b.B;
        }

        private void PrepareHoldSurface(bool readPhotoshop)
        {
            if (IsDisposed || hudMode != HudMode.Hidden) return;

            DateTime wt = HudSettings.SettingsWriteTimeUtc();
            if (wt != settingsWriteTimeUtc)
            {
                settings = HudSettings.Load();
                settingsWriteTimeUtc = wt;
            }

            if (readPhotoshop)
            {
                RgbColor rgb;
                string error;
                if (PhotoshopBridge.TryGetForeground(out rgb, out error))
                {
                    baseLch = ColorMath.RgbToLch(rgb);
                    lastSourceRgb = rgb;
                    hasLastSourceRgb = true;
                    lastPsErrorShown = false;
                }
            }

            SyncWindowCentersToCurrentColor();
            ConfigureGeometry();
            RebuildBitmaps();
            ResetMarkersToCurrentColor();
            activeField = ActiveField.Color;
            holdSurfacePrepared = true;

            // Prime the hold-only click-through style while hidden as well, so hotkey-down does not
            // need a SetWindowLong/FRAMECHANGED round trip before the first visible frame.
            ApplyHoldClickThrough(true);

            // Upload the alpha surface while hidden. The next hold-key down only moves + shows it.
            UpdateLayeredSurface();
        }

        private void BeginHoldHoverFast()
        {
            if (hudMode != HudMode.Hidden || IsDisposed) return;

            // First-ever launch or a settings/color change can miss the idle prewarm. Keep a safe fallback.
            if (!holdSurfacePrepared)
                PrepareHoldSurface(true);

            Point p = Cursor.Position;
            Rectangle wa = Screen.FromPoint(p).WorkingArea;
            int x = p.X - colorMarker.X;
            int y = p.Y - colorMarker.Y;

            if (x + Width > wa.Right) x = wa.Right - Width;
            if (y + Height > wa.Bottom) y = wa.Bottom - Height;
            if (x < wa.Left) x = wa.Left;
            if (y < wa.Top) y = wa.Top;
            Location = new Point(x, y);

            hudMode = HudMode.Hold;
            ResetHoldHoverSelection();
            ApplyHoldClickThrough(true);
            shownAtUtc = DateTime.UtcNow;

            if (!Visible) Show();
            else
            {
                TopMost = false;
                TopMost = true;
            }

            // The first frame is already visible. Verify Photoshop's current color on a background
            // STA thread so a COM/DoJavaScript round trip cannot freeze the first hover movement.
            QueueForegroundSync();
        }

        private void QueueForegroundSync()
        {
            int serial = Interlocked.Increment(ref foregroundSyncSerial);
            bool hadExpected = hasLastSourceRgb;
            RgbColor expected = lastSourceRgb;

            Thread worker = new Thread(delegate()
            {
                RgbColor rgb;
                string error;
                if (!PhotoshopBridge.TryGetForeground(out rgb, out error)) return;
                try
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        ApplyForegroundSyncResult(serial, hadExpected, expected, rgb);
                    });
                }
                catch { }
            });
            worker.IsBackground = true;
            try { worker.SetApartmentState(ApartmentState.STA); } catch { }
            worker.Start();
        }

        private void ApplyForegroundSyncResult(int serial, bool hadExpected, RgbColor expected, RgbColor rgb)
        {
            if (IsDisposed || serial != foregroundSyncSerial) return;

            // A successful picker commit after this read was queued wins over the stale read result.
            if (hadExpected && hasLastSourceRgb && !SameRgb(lastSourceRgb, expected)) return;
            if (hasLastSourceRgb && SameRgb(lastSourceRgb, rgb)) return;

            baseLch = ColorMath.RgbToLch(rgb);
            lastSourceRgb = rgb;
            hasLastSourceRgb = true;
            holdSurfacePrepared = false;

            if (hudMode == HudMode.Hold && Visible && holdKeyDown)
            {
                SyncWindowCentersToCurrentColor();
                ConfigureGeometry();
                RebuildBitmaps();
                ResetMarkersToCurrentColor();
                activeField = ActiveField.Color;
                holdSurfacePrepared = true;

                Point p = Cursor.Position;
                Rectangle wa = Screen.FromPoint(p).WorkingArea;
                int x = p.X - colorMarker.X;
                int y = p.Y - colorMarker.Y;
                if (x + Width > wa.Right) x = wa.Right - Width;
                if (y + Height > wa.Bottom) y = wa.Bottom - Height;
                if (x < wa.Left) x = wa.Left;
                if (y < wa.Top) y = wa.Top;
                Location = new Point(x, y);
                UpdateLayeredSurface();
            }
            else if (hudMode == HudMode.Hidden)
            {
                deferredPrewarmUtc = DateTime.UtcNow.AddMilliseconds(90);
            }
        }

        private void ShowHud(HudMode mode)
        {
            if (mode == HudMode.Hold)
            {
                BeginHoldHoverFast();
                return;
            }

            settings = HudSettings.Load();
            settingsWriteTimeUtc = HudSettings.SettingsWriteTimeUtc();
            RgbColor rgb;
            string error;
            if (PhotoshopBridge.TryGetForeground(out rgb, out error))
            {
                baseLch = ColorMath.RgbToLch(rgb);
                lastSourceRgb = rgb;
                hasLastSourceRgb = true;
                lastPsErrorShown = false;
            }
            else if (!lastPsErrorShown)
            {
                lastPsErrorShown = true;
                try { tray.ShowBalloonTip(2200, "Local Color Fields HUD", "Could not read Photoshop foreground color. Make sure Photoshop is running.\n" + error, ToolTipIcon.Warning); } catch { }
            }

            SyncWindowCentersToCurrentColor();
            ConfigureGeometry();
            RebuildBitmaps();
            ResetMarkersToCurrentColor();
            activeField = ActiveField.Color;
            holdSurfacePrepared = true;

            Point p = Cursor.Position;
            Rectangle wa = Screen.FromPoint(p).WorkingArea;
            int offset = settings.CursorOffset;
            int x = p.X + offset;
            int y = p.Y + offset;
            if (x + Width > wa.Right) x = p.X - Width - offset;
            if (y + Height > wa.Bottom) y = p.Y - Height - offset;
            if (x + Width > wa.Right) x = wa.Right - Width;
            if (y + Height > wa.Bottom) y = wa.Bottom - Height;
            if (x < wa.Left) x = wa.Left;
            if (y < wa.Top) y = wa.Top;
            Location = new Point(x, y);

            hudMode = mode;
            ResetHoldHoverSelection();
            ApplyHoldClickThrough(false);
            shownAtUtc = DateTime.UtcNow;
            if (!Visible)
            {
                UpdateLayeredSurface();
                Show();
            }
            else
            {
                TopMost = false;
                TopMost = true;
                UpdateLayeredSurface();
            }
        }

        private void ConfigureGeometry()
        {
            int shadowPad = 7;
            int contentPad = shadowPad + 2;
            int field = Math.Max(120, settings.FieldSize);
            int bar = Math.Max(18, Math.Min(settings.LightBarWidth, Math.Max(18, field / 2)));
            int gap = Math.Max(2, settings.Gap);
            bool barLeft = String.Equals(settings.LightBarSide, "left", StringComparison.OrdinalIgnoreCase);

            Size = new Size(contentPad * 2 + field + gap + bar, contentPad * 2 + field);
            if (barLeft)
            {
                lightRect = new Rectangle(contentPad, contentPad, bar, field);
                colorRect = new Rectangle(lightRect.Right + gap, contentPad, field, field);
            }
            else
            {
                colorRect = new Rectangle(contentPad, contentPad, field, field);
                lightRect = new Rectangle(colorRect.Right + gap, contentPad, bar, field);
            }

            colorCornerRadius = Math.Max(0f, field * (float)(settings.CornerRadiusPercent / 100.0));
            lightCornerRadius = Math.Max(3f, Math.Min(bar * 0.48f, colorCornerRadius));

            // Do not use Form.Region here. Region is a 1-bit window mask and causes visible stair-stepping.
            // The entire HUD is now composited as a per-pixel-alpha layered window.
            if (Region != null)
            {
                Region.Dispose();
                Region = null;
            }
        }

        private void ApplySettingsLive()
        {
            if (!Visible) return;
            Point oldCenterScreen = new Point(Left + Width / 2, Top + Height / 2);
            SyncWindowCentersToCurrentColor();
            ConfigureGeometry();
            RebuildBitmaps();
            ResetMarkersToCurrentColor();
            holdSurfacePrepared = true;
            Left = oldCenterScreen.X - Width / 2;
            Top = oldCenterScreen.Y - Height / 2;
            Rectangle wa = Screen.FromPoint(oldCenterScreen).WorkingArea;
            if (Right > wa.Right) Left -= Right - wa.Right;
            if (Bottom > wa.Bottom) Top -= Bottom - wa.Bottom;
            if (Left < wa.Left) Left = wa.Left;
            if (Top < wa.Top) Top = wa.Top;
            UpdateLayeredSurface();
        }

        public void HideHud()
        {
            dragging = false;
            StopPassiveDragTracking();
            if (fallbackCapture || Capture) Capture = false;
            fallbackCapture = false;
            hudMode = HudMode.Hidden;
            if (Visible) Hide();
            ApplyHoldClickThrough(false);
            ResetHoldHoverSelection();
        }

        private void RebuildBitmaps()
        {
            DisposeBitmaps();
            colorBitmap = RenderColorField(colorRect.Width, colorRect.Height);
            lightBitmap = RenderLightnessBar(lightRect.Width, lightRect.Height);
            RebuildStaticSurface();
        }

        private Bitmap RenderColorField(int displayW, int displayH)
        {
            Size p = PreviewSize(displayW, displayH, 65000);
            int[] pixels = new int[p.Width * p.Height];
            double[] cosH = new double[p.Width];
            double[] sinH = new double[p.Width];
            for (int x = 0; x < p.Width; x++)
            {
                double tx = p.Width <= 1 ? 0.5 : (double)x / (p.Width - 1);
                double h = ColorMath.WrapHue(baseLch.H + (tx - 0.5) * (settings.HueRange * 2.0));
                double rad = h * Math.PI / 180.0;
                cosH[x] = Math.Cos(rad);
                sinH[x] = Math.Sin(rad);
            }

            AxisWindow cw = GetChromaWindow();
            int k = 0;
            for (int y = 0; y < p.Height; y++)
            {
                double ty = p.Height <= 1 ? 0.5 : (double)y / (p.Height - 1);
                double C = cw.High + (cw.Low - cw.High) * ty;
                for (int x = 0; x < p.Width; x++)
                {
                    RgbColor c = ColorMath.LchToRgbWithDirection(baseLch.L, C, cosH[x], sinH[x], 7);
                    pixels[k++] = unchecked((int)0xFF000000) | (c.R << 16) | (c.G << 8) | c.B;
                }
            }
            return BitmapFromArgb(p.Width, p.Height, pixels);
        }

        private Bitmap RenderLightnessBar(int displayW, int displayH)
        {
            Size p = PreviewSize(displayW, displayH, 18000);
            int[] pixels = new int[p.Width * p.Height];
            AxisWindow lw = GetLightnessWindow();
            double rad = ColorMath.WrapHue(baseLch.H) * Math.PI / 180.0;
            double cosH = Math.Cos(rad), sinH = Math.Sin(rad);
            int k = 0;
            for (int y = 0; y < p.Height; y++)
            {
                double ty = p.Height <= 1 ? 0.5 : (double)y / (p.Height - 1);
                double L = lw.High + (lw.Low - lw.High) * ty;
                RgbColor row = ColorMath.LchToRgbWithDirection(L, baseLch.C, cosH, sinH, 8);
                int argb = unchecked((int)0xFF000000) | (row.R << 16) | (row.G << 8) | row.B;
                for (int x = 0; x < p.Width; x++) pixels[k++] = argb;
            }
            return BitmapFromArgb(p.Width, p.Height, pixels);
        }

        private static Size PreviewSize(int w, int h, int maxPixels)
        {
            double area = (double)Math.Max(1, w) * Math.Max(1, h);
            double s = area > maxPixels ? Math.Sqrt(maxPixels / area) : 1.0;
            return new Size(Math.Max(2, (int)Math.Round(w * s)), Math.Max(2, (int)Math.Round(h * s)));
        }

        private static Bitmap BitmapFromArgb(int w, int h, int[] pixels)
        {
            Bitmap bmp = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            Rectangle rect = new Rectangle(0, 0, w, h);
            BitmapData data = bmp.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
            try { Marshal.Copy(pixels, 0, data.Scan0, pixels.Length); }
            finally { bmp.UnlockBits(data); }
            return bmp;
        }

        private static double FitWindowCenter(double current, double halfRequested, double min, double max)
        {
            if (min > max) { double t = min; min = max; max = t; }
            double span = Math.Max(0.000001, max - min);
            double half = Math.Min(Math.Max(0, halfRequested), span * 0.5);
            if (half * 2.0 >= span - 0.000001) return (min + max) * 0.5;
            return ColorMath.Clamp(current, min + half, max - half);
        }

        private static AxisWindow BuildWindow(double center, double halfRequested, double min, double max)
        {
            if (min > max) { double t = min; min = max; max = t; }
            double span = Math.Max(0.000001, max - min);
            double half = Math.Min(Math.Max(0, halfRequested), span * 0.5);
            center = FitWindowCenter(center, half, min, max);
            AxisWindow w = new AxisWindow();
            w.Center = center;
            w.Half = half;
            w.High = Math.Min(max, center + half);
            w.Low = Math.Max(min, center - half);
            return w;
        }

        private void SyncWindowCentersToCurrentColor()
        {
            chromaWindowCenter = FitWindowCenter(baseLch.C, settings.ChromaRange, settings.ChromaMin, settings.ChromaMax);
            lightnessWindowCenter = FitWindowCenter(baseLch.L, settings.LightnessRange, settings.LightnessMin, settings.LightnessMax);
        }

        private AxisWindow GetChromaWindow()
        {
            return BuildWindow(chromaWindowCenter, settings.ChromaRange, settings.ChromaMin, settings.ChromaMax);
        }

        private AxisWindow GetLightnessWindow()
        {
            return BuildWindow(lightnessWindowCenter, settings.LightnessRange, settings.LightnessMin, settings.LightnessMax);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            // A layered window is painted through UpdateLayeredWindow, not through the normal WM_PAINT path.
            // Keeping this empty avoids a second, non-alpha paint pass.
        }

        private void ConfigureGraphicsQuality(Graphics g, bool staticPass)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.CompositingMode = CompositingMode.SourceOver;
            g.CompositingQuality = staticPass ? CompositingQuality.HighQuality : CompositingQuality.HighSpeed;
            g.InterpolationMode = staticPass ? InterpolationMode.HighQualityBicubic : InterpolationMode.NearestNeighbor;
            g.PixelOffsetMode = staticPass ? PixelOffsetMode.HighQuality : PixelOffsetMode.HighSpeed;
        }

        private void RenderHudBackground(Graphics g)
        {
            g.Clear(Color.Transparent);
            ConfigureGraphicsQuality(g, true);
            DrawControlShadow(g, colorRect, colorCornerRadius, 0.8f, 1.4f);
            DrawControlShadow(g, lightRect, lightCornerRadius, 0.8f, 1.4f);
            DrawColorField(g);
            DrawLightnessBar(g);
        }

        private void DisposeSurfaceCache()
        {
            if (frameSurfaceGraphics != null) { frameSurfaceGraphics.Dispose(); frameSurfaceGraphics = null; }
            if (frameSurfaceBitmap != null) { frameSurfaceBitmap.Dispose(); frameSurfaceBitmap = null; }
            if (staticSurfaceBitmap != null) { staticSurfaceBitmap.Dispose(); staticSurfaceBitmap = null; }
        }

        private void RebuildStaticSurface()
        {
            DisposeSurfaceCache();
            if (Width <= 0 || Height <= 0) return;
            staticSurfaceBitmap = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(staticSurfaceBitmap)) RenderHudBackground(g);
            frameSurfaceBitmap = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
            frameSurfaceGraphics = Graphics.FromImage(frameSurfaceBitmap);
            ConfigureGraphicsQuality(frameSurfaceGraphics, false);
        }

        private void ComposeFrameSurface()
        {
            if (staticSurfaceBitmap == null || frameSurfaceBitmap == null || frameSurfaceGraphics == null ||
                frameSurfaceBitmap.Width != Width || frameSurfaceBitmap.Height != Height)
                RebuildStaticSurface();
            if (staticSurfaceBitmap == null || frameSurfaceGraphics == null) return;

            frameSurfaceGraphics.CompositingMode = CompositingMode.SourceCopy;
            frameSurfaceGraphics.DrawImageUnscaled(staticSurfaceBitmap, 0, 0);
            frameSurfaceGraphics.CompositingMode = CompositingMode.SourceOver;
            DrawMarker(frameSurfaceGraphics, colorMarker, ActiveField.Color == activeField && dragging);
            DrawMarker(frameSurfaceGraphics, lightMarker, ActiveField.Lightness == activeField && dragging);
        }

        private void UpdateLayeredSurface()
        {
            if (Width <= 0 || Height <= 0 || IsDisposed) return;
            ComposeFrameSurface();
            if (frameSurfaceBitmap == null) return;

            IntPtr screenDc = IntPtr.Zero;
            IntPtr memDc = IntPtr.Zero;
            IntPtr hBitmap = IntPtr.Zero;
            IntPtr oldBitmap = IntPtr.Zero;
            try
            {
                screenDc = GetDC(IntPtr.Zero);
                memDc = CreateCompatibleDC(screenDc);
                hBitmap = frameSurfaceBitmap.GetHbitmap(Color.FromArgb(0));
                oldBitmap = SelectObject(memDc, hBitmap);

                NativePoint dst = new NativePoint(Left, Top);
                NativeSize size = new NativeSize(Width, Height);
                NativePoint src = new NativePoint(0, 0);
                BlendFunction blend = new BlendFunction();
                blend.BlendOp = AC_SRC_OVER;
                blend.BlendFlags = 0;
                blend.SourceConstantAlpha = 255;
                blend.AlphaFormat = AC_SRC_ALPHA;

                UpdateLayeredWindow(Handle, screenDc, ref dst, ref size, memDc, ref src, 0, ref blend, ULW_ALPHA);
            }
            finally
            {
                if (oldBitmap != IntPtr.Zero && memDc != IntPtr.Zero) SelectObject(memDc, oldBitmap);
                if (hBitmap != IntPtr.Zero) DeleteObject(hBitmap);
                if (memDc != IntPtr.Zero) DeleteDC(memDc);
                if (screenDc != IntPtr.Zero) ReleaseDC(IntPtr.Zero, screenDc);
            }
        }

        private void DrawColorField(Graphics g)
        {
            using (GraphicsPath path = RoundedRectPath(colorRect, colorCornerRadius))
            {
                GraphicsState state = g.Save();
                g.SetClip(path);
                if (colorBitmap != null) g.DrawImage(colorBitmap, colorRect);
                g.Restore(state);
                DrawControlOutline(g, path);
            }
        }

        private void DrawLightnessBar(Graphics g)
        {
            using (GraphicsPath path = RoundedRectPath(lightRect, lightCornerRadius))
            {
                GraphicsState state = g.Save();
                g.SetClip(path);
                if (lightBitmap != null) g.DrawImage(lightBitmap, lightRect);
                g.Restore(state);
                DrawControlOutline(g, path);
            }
        }

        private static void DrawControlShadow(Graphics g, Rectangle rect, float radius, float dx, float dy)
        {
            using (GraphicsPath shadowPath = RoundedRectPath(rect, radius))
            using (Matrix m = new Matrix())
            {
                m.Translate(dx, dy);
                shadowPath.Transform(m);
                using (Pen p1 = new Pen(Color.FromArgb(30, 0, 0, 0), 7.0f))
                using (Pen p2 = new Pen(Color.FromArgb(26, 0, 0, 0), 4.2f))
                using (Pen p3 = new Pen(Color.FromArgb(20, 0, 0, 0), 2.2f))
                {
                    p1.LineJoin = LineJoin.Round;
                    p2.LineJoin = LineJoin.Round;
                    p3.LineJoin = LineJoin.Round;
                    g.DrawPath(p1, shadowPath);
                    g.DrawPath(p2, shadowPath);
                    g.DrawPath(p3, shadowPath);
                }
            }
        }

        private static void DrawControlOutline(Graphics g, GraphicsPath path)
        {
            // Dark contour for separation, then a faint inside highlight to keep the edge crisp.
            using (Pen outer = new Pen(Color.FromArgb(235, 6, 6, 8), 1.8f))
            using (Pen inner = new Pen(Color.FromArgb(54, 255, 255, 255), 0.8f))
            {
                outer.LineJoin = LineJoin.Round;
                inner.LineJoin = LineJoin.Round;
                g.DrawPath(outer, path);
                g.DrawPath(inner, path);
            }
        }

        private static GraphicsPath RoundedRectPath(Rectangle rect, float radius)
        {
            GraphicsPath path = new GraphicsPath();
            if (radius <= 0.5f)
            {
                path.AddRectangle(rect);
                path.CloseFigure();
                return path;
            }
            float r = Math.Min(radius, Math.Min(rect.Width, rect.Height) * 0.5f);
            float d = r * 2f;
            RectangleF rf = new RectangleF(rect.X, rect.Y, rect.Width, rect.Height);
            path.AddArc(rf.Left, rf.Top, d, d, 180, 90);
            path.AddArc(rf.Right - d, rf.Top, d, d, 270, 90);
            path.AddArc(rf.Right - d, rf.Bottom - d, d, d, 0, 90);
            path.AddArc(rf.Left, rf.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private void DrawMarker(Graphics g, Point p, bool active)
        {
            if (p == Point.Empty) return;
            float r = Math.Max(4f, settings.MarkerSize * 0.5f);
            RectangleF shadowRect = new RectangleF(p.X - r - 1.2f, p.Y - r - 1.2f, (r + 1.2f) * 2f, (r + 1.2f) * 2f);
            RectangleF outerRect = new RectangleF(p.X - r, p.Y - r, r * 2f, r * 2f);
            using (Pen shadow = new Pen(Color.FromArgb(205, 0, 0, 0), active ? 4.0f : 3.0f)) g.DrawEllipse(shadow, shadowRect);
            using (Pen white = new Pen(Color.FromArgb(250, 250, 250, 250), active ? 2.2f : 1.6f)) g.DrawEllipse(white, outerRect);
            float innerR = Math.Max(2f, r - 3.2f);
            using (Pen dark = new Pen(Color.FromArgb(210, 24, 24, 26), 1.0f))
                g.DrawEllipse(dark, new RectangleF(p.X - innerR, p.Y - innerR, innerR * 2f, innerR * 2f));
        }

        private bool StartPassiveDragTracking()
        {
            StopPassiveDragTracking();
            try
            {
                passiveMouseHook = SetWindowsHookEx(WH_MOUSE_LL, passiveMouseProc, GetModuleHandle(null), 0);
                passiveTracking = passiveMouseHook != IntPtr.Zero;
                return passiveTracking;
            }
            catch
            {
                passiveMouseHook = IntPtr.Zero;
                passiveTracking = false;
                return false;
            }
        }

        private void StopPassiveDragTracking()
        {
            IntPtr hook = passiveMouseHook;
            passiveMouseHook = IntPtr.Zero;
            passiveTracking = false;
            if (hook != IntPtr.Zero)
            {
                try { UnhookWindowsHookEx(hook); } catch { }
            }
            lock (passiveInputGate)
            {
                passiveMovePending = false;
                passiveUpPending = false;
                passiveScreenPoint = Point.Empty;
            }
        }

        private IntPtr PassiveMouseHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            IntPtr hookSnapshot = passiveMouseHook;
            if (nCode >= 0 && hookSnapshot != IntPtr.Zero)
            {
                int msg = unchecked((int)wParam.ToInt64());
                if (msg == WM_MOUSEMOVE || msg == WM_LBUTTONUP)
                {
                    try
                    {
                        MsLlHookStruct info = (MsLlHookStruct)Marshal.PtrToStructure(lParam, typeof(MsLlHookStruct));
                        lock (passiveInputGate)
                        {
                            passiveScreenPoint = new Point(info.Point.X, info.Point.Y);
                            if (msg == WM_MOUSEMOVE) passiveMovePending = true;
                            else passiveUpPending = true;
                        }
                    }
                    catch { }
                }
            }
            return CallNextHookEx(hookSnapshot, nCode, wParam, lParam);
        }

        private void ProcessPassiveInput()
        {
            if (!dragging || !passiveTracking) return;
            bool move, up;
            Point screenPoint;
            lock (passiveInputGate)
            {
                move = passiveMovePending;
                up = passiveUpPending;
                screenPoint = passiveScreenPoint;
                passiveMovePending = false;
                if (up) passiveUpPending = false;
            }
            if (screenPoint == Point.Empty) return;
            Point client = PointToClient(screenPoint);
            Point p = ClampPointToActive(client);
            bool changed = SetActiveMarker(p);
            if (up)
            {
                FinishDrag(p);
                return;
            }
            if (move && changed) UpdateLayeredSurface();
        }

        private void HudMouseDown(object sender, MouseEventArgs e)
        {
            if (hudMode == HudMode.Hold) return;
            if (e.Button == MouseButtons.Right) { HideHud(); return; }
            if (e.Button != MouseButtons.Left) return;

            if (IsPointInColor(e.Location)) activeField = ActiveField.Color;
            else if (IsPointInLightness(e.Location)) activeField = ActiveField.Lightness;
            else return;

            dragging = true;
            fallbackCapture = !StartPassiveDragTracking();
            if (fallbackCapture) Capture = true;
            SetActiveMarker(ClampPointToActive(e.Location));
            UpdateLayeredSurface();
        }

        private void HudMouseMove(object sender, MouseEventArgs e)
        {
            if (hudMode == HudMode.Hold) return;
            if (!dragging || passiveTracking) return;
            if (SetActiveMarker(ClampPointToActive(e.Location))) UpdateLayeredSurface();
        }

        private void HudMouseUp(object sender, MouseEventArgs e)
        {
            if (hudMode == HudMode.Hold) return;
            if (!dragging || e.Button != MouseButtons.Left) return;
            FinishDrag(ClampPointToActive(e.Location));
        }

        private void FinishDrag(Point p)
        {
            if (!dragging) return;
            SetActiveMarker(p);
            RgbColor picked = activeField == ActiveField.Color ? ColorFromField(p) : ColorFromLightness(p);
            dragging = false;
            StopPassiveDragTracking();
            if (fallbackCapture || Capture) Capture = false;
            fallbackCapture = false;

            string error;
            if (PhotoshopBridge.TrySetForeground(picked, out error))
            {
                if (settings.RefreshAfterPick) RefreshFieldsFromPickedColor(picked);
                else UpdateLayeredSurface();
            }
            else
            {
                try { tray.ShowBalloonTip(2200, "Local Color Fields HUD", "Could not set Photoshop foreground color.\n" + error, ToolTipIcon.Warning); } catch { }
            }
        }

        private bool IsPointInColor(Point p)
        {
            return IsPointInRoundedRect(p, colorRect, colorCornerRadius);
        }

        private bool IsPointInLightness(Point p)
        {
            return IsPointInRoundedRect(p, lightRect, lightCornerRadius);
        }

        private static bool IsPointInRoundedRect(Point p, Rectangle rect, float radius)
        {
            if (!rect.Contains(p)) return false;
            double r = Math.Max(0.0, Math.Min(radius, Math.Min(rect.Width, rect.Height) * 0.5));
            if (r <= 0.5) return true;

            double left = rect.Left, top = rect.Top, right = rect.Right - 1, bottom = rect.Bottom - 1;
            if (p.X >= left + r && p.X <= right - r) return true;
            if (p.Y >= top + r && p.Y <= bottom - r) return true;

            double cx = p.X < left + r ? left + r : right - r;
            double cy = p.Y < top + r ? top + r : bottom - r;
            double dx = p.X - cx, dy = p.Y - cy;
            return dx * dx + dy * dy <= r * r + 0.25;
        }

        private Point ClampPointToActive(Point p)
        {
            return activeField == ActiveField.Color ? ClampPointToRoundedRect(p, colorRect, colorCornerRadius) : ClampPointToRoundedRect(p, lightRect, lightCornerRadius);
        }

        private Point ClampPointToRoundedRect(Point p, Rectangle rect, float radius)
        {
            int x = Math.Max(rect.Left, Math.Min(rect.Right - 1, p.X));
            int y = Math.Max(rect.Top, Math.Min(rect.Bottom - 1, p.Y));
            Point q = new Point(x, y);
            if (IsPointInRoundedRect(q, rect, radius)) return q;

            double r = Math.Max(0.0, Math.Min(radius, Math.Min(rect.Width, rect.Height) * 0.5));
            if (r <= 0.5) return q;
            double left = rect.Left, top = rect.Top, right = rect.Right - 1, bottom = rect.Bottom - 1;
            double cx = q.X < left + r ? left + r : right - r;
            double cy = q.Y < top + r ? top + r : bottom - r;
            double dx = q.X - cx, dy = q.Y - cy;
            double len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 0.000001) return new Point((int)Math.Round(cx), (int)Math.Round(cy));
            double scale = Math.Max(0.0, (r - 0.75) / len);
            return new Point((int)Math.Round(cx + dx * scale), (int)Math.Round(cy + dy * scale));
        }

        private bool SetActiveMarker(Point p)
        {
            if (activeField == ActiveField.Color)
            {
                if (colorMarker == p) return false;
                colorMarker = p;
                return true;
            }
            if (lightMarker == p) return false;
            lightMarker = p;
            return true;
        }

        private void RefreshFieldsFromPickedColor(RgbColor picked)
        {
            baseLch = ColorMath.RgbToLch(picked);

            // Independent protected refresh:
            // each local window follows the current component until a hard min/max is reached.
            // At that boundary this component's window stops moving, while Hue still recenters every refresh.
            chromaWindowCenter = FitWindowCenter(baseLch.C, settings.ChromaRange, settings.ChromaMin, settings.ChromaMax);
            lightnessWindowCenter = FitWindowCenter(baseLch.L, settings.LightnessRange, settings.LightnessMin, settings.LightnessMax);

            RebuildBitmaps();
            ResetMarkersToCurrentColor();
            holdSurfacePrepared = true;
            UpdateLayeredSurface();
        }

        private void ResetMarkersToCurrentColor()
        {
            AxisWindow cw = GetChromaWindow();
            double cDen = cw.High - cw.Low;
            double cT = Math.Abs(cDen) < 0.000001 ? 0.5 : (cw.High - baseLch.C) / cDen;
            cT = ColorMath.Clamp(cT, 0.0, 1.0);
            colorMarker = new Point(
                colorRect.Left + colorRect.Width / 2,
                colorRect.Top + (int)Math.Round(cT * (colorRect.Height - 1)));

            AxisWindow lw = GetLightnessWindow();
            double lDen = lw.High - lw.Low;
            double lT = Math.Abs(lDen) < 0.000001 ? 0.5 : (lw.High - baseLch.L) / lDen;
            lT = ColorMath.Clamp(lT, 0.0, 1.0);
            lightMarker = new Point(
                lightRect.Left + lightRect.Width / 2,
                lightRect.Top + (int)Math.Round(lT * (lightRect.Height - 1)));
        }

        private RgbColor ColorFromField(Point p)
        {
            double tx = colorRect.Width <= 1 ? 0.5 : (double)(p.X - colorRect.Left) / (colorRect.Width - 1);
            double ty = colorRect.Height <= 1 ? 0.5 : (double)(p.Y - colorRect.Top) / (colorRect.Height - 1);
            double h = baseLch.H + (tx - 0.5) * (settings.HueRange * 2.0);
            AxisWindow cw = GetChromaWindow();
            double C = cw.High + (cw.Low - cw.High) * ty;
            return ColorMath.LchToRgb(baseLch.L, C, h, 16);
        }

        private RgbColor ColorFromLightness(Point p)
        {
            double ty = lightRect.Height <= 1 ? 0.5 : (double)(p.Y - lightRect.Top) / (lightRect.Height - 1);
            AxisWindow lw = GetLightnessWindow();
            double L = lw.High + (lw.Low - lw.High) * ty;
            return ColorMath.LchToRgb(L, baseLch.C, baseLch.H, 16);
        }

        private void DisposeBitmaps()
        {
            DisposeSurfaceCache();
            if (colorBitmap != null) { colorBitmap.Dispose(); colorBitmap = null; }
            if (lightBitmap != null) { lightBitmap.Dispose(); lightBitmap = null; }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                RemoveKeyboardHook();
                StopPassiveDragTracking();
                DisposeBitmaps();
                if (inputTimer != null) { inputTimer.Stop(); inputTimer.Dispose(); inputTimer = null; }
                if (tray != null) { tray.Visible = false; tray.Dispose(); tray = null; }
            }
            base.Dispose(disposing);
        }
    }

    internal sealed class HudApplicationContext : ApplicationContext
    {
        private readonly HudForm form;

        public HudApplicationContext(HudForm hud, bool showAtStart)
        {
            form = hud;
            MainForm = form;
            form.FormClosed += delegate { ExitThread(); };
            IntPtr unused = form.Handle; // create the hidden native window so hotkey/IPC can work
            if (showAtStart) form.BeginInvoke((MethodInvoker)delegate { form.ShowHud(); });
            else form.BeginInvoke((MethodInvoker)delegate { form.PrewarmHoldSurface(); });
        }
    }

    internal static class Program
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")] private static extern bool PostMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")] private static extern bool SetProcessDPIAware();

        [STAThread]
        private static void Main(string[] args)
        {
            try { SetProcessDPIAware(); } catch { }

            bool showAtStart = true;
            bool ensureResident = false;
            bool followPhotoshop = false;

            for (int i = 0; i < args.Length; i++)
            {
                if (String.Equals(args[i], "--resident", StringComparison.OrdinalIgnoreCase))
                    showAtStart = false;
                else if (String.Equals(args[i], "--ensure-resident", StringComparison.OrdinalIgnoreCase))
                {
                    showAtStart = false;
                    ensureResident = true;
                }
                else if (String.Equals(args[i], "--follow-photoshop", StringComparison.OrdinalIgnoreCase))
                    followPhotoshop = true;
            }

            bool createdNew;
            using (Mutex mutex = new Mutex(true, "LocalColorFieldsNativeHUD_SingleInstance", out createdNew))
            {
                if (!createdNew)
                {
                    IntPtr hwnd = IntPtr.Zero;
                    for (int i = 0; i < 20 && hwnd == IntPtr.Zero; i++)
                    {
                        hwnd = FindWindow(null, HudForm.HostWindowTitle);
                        if (hwnd == IntPtr.Zero) Thread.Sleep(25);
                    }

                    // CEP startup/reload uses --ensure-resident. It must never toggle an already
                    // running HUD. If that existing instance was started manually, upgrade it in-place
                    // to Photoshop-follow mode so it will still close with the host.
                    if (ensureResident)
                    {
                        if (followPhotoshop && hwnd != IntPtr.Zero)
                            PostMessage(hwnd, HudForm.EnablePhotoshopFollowMessageId, IntPtr.Zero, IntPtr.Zero);
                        return;
                    }

                    if (hwnd != IntPtr.Zero)
                        PostMessage(hwnd, HudForm.TogglePersistentMessageId, IntPtr.Zero, IntPtr.Zero);
                    return;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                HudForm form = new HudForm(followPhotoshop);
                HudApplicationContext context = new HudApplicationContext(form, showAtStart);
                Application.Run(context);
            }
        }
    }
}
