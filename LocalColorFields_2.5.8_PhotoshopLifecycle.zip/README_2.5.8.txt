﻿Local Color Fields 2.5.8

Photoshop lifecycle update:
- A dedicated invisible CEP lifecycle extension starts automatically with Photoshop and silently ensures one resident Native HUD.
- Visible settings-panel reloads and lifecycle retries do not toggle or duplicate an existing HUD.
- The lifecycle-bound HUD checks Photoshop about every 400 ms and exits after Photoshop has been gone for ~0.9 s.
- A 10 s startup grace avoids false exits during Photoshop/CEP initialization.
- Manual EXE / Photoshop script launch still toggles the persistent HUD as before; if CEP later finds that instance, it upgrades it to Photoshop-follow mode in place.
- The installer no longer leaves an orphan resident HUD running when Photoshop is closed.

========================

Low-latency pressure-safe CapsLock hover picker
-----------------------------------------------
Recommended pen workflow:
1. Hold CapsLock.
2. The current-color marker appears directly under the pen/cursor.
3. Keep the pen hovering; move over Hue+Chroma or Lightness.
4. Release CapsLock to commit the last valid color.
5. Put the pen down on the Photoshop canvas.

Do not press the pen tip while the hold HUD is open. The HUD is intentionally
click-through so Photoshop remains the pen input target and first-stroke pressure stays intact.

2.5.7 low-latency changes retained
-----------------------------------
- CapsLock press/release is handled with WH_KEYBOARD_LL instead of waiting for the 15 ms UI timer.
- The color field, lightness field, marker surface and layered alpha surface are prepared while hidden.
- Normal hotkey-down only positions the already-prepared HUD and shows it.
- The hold click-through window style is also prepared while hidden.
- Photoshop foreground-color verification happens after the first visible frame on a background STA thread.
  If Photoshop's color did not change externally, no rebuild occurs while selecting.
- After a successful pick, the next color field is rebuilt after a short hidden delay instead of on the next summon.
- The short delay intentionally keeps render work away from the first drawing stroke after color selection.
- CapsLock is swallowed only while Photoshop is using the picker, so it does not also toggle Photoshop precise-cursor mode.
- If the low-level keyboard hook cannot be created, the previous timer polling remains as a fallback.

Retained from 2.5.6
-------------------
- Cursor-centered summon: current-color marker starts under the pen.
- Pressure-safe hover-only selection, no HUD PenDown/PenUp/Capture.
- Full click-through hold window.
- Hide-before-commit handoff.
- Persistent mouse HUD remains available.
- Cached static layered surface and marker-only movement redraw.
- OKLCH local Hue+Chroma field + independent Lightness bar.
- Chroma/Lightness min-max protection.

Install
-------
Run:
  INSTALL_ALL_2.5.8.bat

Photoshop path remains fixed to:
  D:\PhotoShopCC2018\Adobe Photoshop CC 2018

Restart Photoshop once after installing so the CEP settings panel reloads.
