﻿@echo off
set "EXE=%APPDATA%\LocalColorFields\NativeHUD\LocalColorFieldsNativeHUD.exe"
if not exist "%EXE%" (
  echo Native HUD is not installed.
  pause
  exit /b 1
)
start "" "%EXE%"
