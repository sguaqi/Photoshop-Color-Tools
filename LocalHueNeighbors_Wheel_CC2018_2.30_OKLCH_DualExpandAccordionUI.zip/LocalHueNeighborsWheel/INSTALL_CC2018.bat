@echo off
setlocal
set "SRC=%~dp0"
set "DST=%APPDATA%\Adobe\CEP\extensions\LocalHueNeighborsWheel"

echo.
echo Installing Local Hue Neighbors Wheel 2.30 OKLCH Dual Expand Accordion UI...
echo Please CLOSE Photoshop before continuing.
echo.
pause

mkdir "%APPDATA%\Adobe\CEP\extensions" 2>nul
if exist "%DST%" rmdir /S /Q "%DST%"
mkdir "%DST%"
xcopy "%SRC%*" "%DST%\" /E /I /Y >nul

reg add "HKCU\Software\Adobe\CSXS.8" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

echo.
echo Installed Local Hue Neighbors Wheel 2.30 OKLCH Dual Expand Accordion UI.
echo Start Photoshop:
echo Window ^> Extensions ^> Local Hue Neighbors Wheel
echo.
pause
