# Local Hue Neighbors Wheel 2.30

## 2.30 - dual expand + adaptive single-section limits

Based on 2.29 Accordion Fill UI, this version restores support for both sections being open at the same time, keeps the single visible section as the sizing baseline when the other is collapsed, and reduces the collapsed-bar height further.

- preserved Wheel/OKLCH logic, Photoshop sync, pen handling and performance caches
- flattened panel chrome and removed decorative borders/background blocks
- compact Lock + Settings header
- advanced parameters reorganized into a responsive minimal grid
- lighter section hierarchy and tighter spacing
- simplified slider/value fields and mode selector
- kept color gradients as functional information, not decoration

---

# Local Hue Neighbors Wheel 2.6

Built directly from Wheel 2.5.

## New: Lock / fixed wheel basis

Wheel now separates:

1. Current Photoshop foreground color
2. Wheel basis color

### Lock OFF

This is the original behavior.

Every new foreground color becomes the new Wheel basis:
- wheel Lightness updates
- displayed Chroma range updates
- outer hue ring basis updates
- wheel redraws around the new foreground color

### Lock ON

Turning Lock on captures the CURRENT wheel basis.

After that:
- inner-disc selections still change Photoshop foreground color
- outer-ring selections still change Photoshop foreground color
- Color sliders still change Photoshop foreground color
- current-color marker still moves
- Color sliders still display the current selected color

But:
- wheel pixels do not reset
- wheel Lightness remains fixed
- wheel Chroma range remains fixed
- outer ring basis remains fixed

This allows repeated color picking from one stable color field.

### Unlock

Turning Lock off immediately returns to live behavior.

The CURRENT Photoshop foreground color becomes the live wheel basis.

## Persistence

The following are saved automatically:
- Lock on/off
- locked basis RGB
- Range
- Hues
- Chroma
- Gray
- H
- UI %

So a locked color field survives Photoshop/plugin restart.

## Unchanged

- neutral-center Wheel 2.2 color model
- Wheel 2.5 slider rollback fix
- Photoshop CC 2018 sync
- pen / mouse behavior
- Color slider modes


## Wheel 2.7 - outer ring is now Rebase

The outer hue ring now represents BASE colors rather than an ordinary transient pick.

### Inner disc
- Lock OFF: behaves as before; picked colors can become the live wheel basis.
- Lock ON: picks foreground colors from the fixed wheel without changing the wheel.

### Outer hue ring
Selecting any ring color now ALWAYS performs a Rebase:

1. Photoshop foreground changes to the selected ring color.
2. The selected ring color becomes the new Wheel basis.
3. The inner wheel regenerates immediately around that color family.
4. Existing Lock state is preserved.

Therefore, with Lock ON:
- inner disc = explore/select within one fixed color family
- outer ring = jump directly to a new base color family

No Unlock -> select -> Lock sequence is required.

All other Wheel 2.6 behavior and persistence remain unchanged.


## Wheel 2.8 - exact UI color picking / marker fix

Fixed two related issues caused by gamut compression and reverse mapping.

### 1. Inner-disc color now exactly matches the visible UI pixel

Previously:
- pointer coordinate -> theoretical LCh -> sRGB gamut compression -> Photoshop RGB
- then Photoshop RGB -> LCh -> reverse radius calculation

This could make the current-color marker move away from the pointer, especially
for high-lightness/high-chroma colors.

Now:
- inner-disc selection reads the actual rendered Canvas RGB pixel under the pen/mouse
- Photoshop receives exactly the RGB the user can see

"What you see is what you pick."

### 2. Locked current-color marker preserves the exact picked position

While Lock is ON:
- inner-disc release stores the exact polar pointer position
- Photoshop foreground changes to the rendered pixel color
- marker stays exactly at that selected point
- wheel remains frozen

External Photoshop/Color-slider changes still use a best-effort calculated marker
because those colors may not exist exactly inside the locked wheel.

### 3. Outer ring marker now represents the locked BASE color

Since the outer ring is now Rebase:
- Lock ON -> outer marker stays at the frozen basis Hue
- inner selections no longer move the outer base marker
- selecting the ring rebases the wheel and updates the outer marker

No Wheel color-field algorithm, Lock persistence, slider behavior, or Photoshop
input handling was otherwise changed.


## Wheel 2.9 - OKLCH experiment

This build is directly based on Wheel 2.8.

Only the perceptual color space has changed:

Before:
- CIELAB -> LCh

Now:
- OKLab -> OKLCH

All Wheel interaction logic is unchanged:
- neutral center
- angle -> Hue
- radius -> Chroma
- Lock
- outer-ring Rebase
- exact Canvas RGB picking
- marker behavior
- Color sliders
- persistence
- pen / mouse handling

### Internal scaling

For compatibility with the existing Wheel parameter system:

- OKLab L is stored as 0–100
- OKLCH C is stored as C × 100
- Hue remains degrees

### sRGB gamut handling

If an OKLCH color is outside sRGB:
- Lightness is preserved
- Hue is preserved
- only Chroma is reduced until the RGB value fits

This build is intended specifically to compare perceptual behavior against the
CIELAB/LCh version, especially for bright yellow / blue / purple regions.


## Wheel 2.10 - pure outer ring + current-Hue marker sync

Built directly from Wheel 2.9 OKLCH.

Only two behavior changes:

### 1. Outer hue ring = pure base colors
The ring no longer uses the wheel basis Lightness/Chroma.

It always displays and selects:
- Hue = ring angle
- Saturation = 100%
- Brightness = 100%

So the ring is now a true basic/pure-color Rebase selector.

### 2. Ring marker follows current foreground Hue during Lock
Lock still freezes the inner wheel basis.

However, the outer ring marker now always tracks the CURRENT Photoshop
foreground Hue.

Therefore:
- inner-disc picking while locked does not reset the wheel
- the current-color marker on the outer ring still moves with the selected Hue
- clicking the ring still performs a Rebase to a pure base color

No OKLCH conversion, inner-wheel algorithm, Lock behavior, Color sliders,
persistence, exact Canvas RGB picking, or pen/mouse handling changed.


## Wheel 2.11 - complete outer-ring HSV fix

A full code audit of 2.10 found that several old OKLCH/LCh outer-ring paths
were still present.

Wheel 2.11 removes the remaining mismatch completely.

### Outer ring is now 100% HSV/HSB

Rendering:
- Hue = ring angle
- Saturation = 100
- Brightness = 100

Picking / Rebase:
- selected RGB = HSV(Hue, 100, 100)

Current-color marker:
- current Photoshop RGB -> HSV Hue -> ring marker position

Preview marker:
- ring angle -> HSV Hue -> marker position

### Inner disc remains OKLCH

The OKLCH inner-wheel algorithm is not changed.

Therefore the two roles are now intentionally separated:

- outer ring = Photoshop-friendly pure HSB base colors
- inner disc = perceptual OKLCH color field

This fixes the previous situation where an HSB color such as H=195°
could place the ring marker at an unrelated OKLCH hue angle.

No Lock, Rebase, exact Canvas RGB picking, slider, persistence,
or pen/mouse behavior was changed.


## Wheel 2.12 - compact UI + larger wheel

Built directly from the user-supplied Wheel 2.11 OKLCH.

### Compact UI

Always visible:
- Multi Color Field
- Lock
- wheel / inner color field
- Color sliders

Advanced only:
- Range
- Hues
- Chroma
- Gray
- H
- UI %

The Advanced open/closed state is saved automatically.

Lock remains permanently visible because it is a frequent painting interaction,
not a setup parameter.

### Wheel fills the selection box vertically

Previous geometry:
- outer radius = 46% of the smaller canvas dimension

New geometry:
- outer radius = half of the smaller dimension minus ~2 CSS px

So the selectable wheel now uses almost all available top/bottom space while
retaining a tiny antialiasing margin.

No OKLCH color algorithm, Lock behavior, Rebase, HSV outer-ring logic,
Color sliders, exact Canvas picking, persistence, or pen/mouse handling changed.


## Wheel 2.13 - wheel geometry controls

Added two Advanced parameters.

### Size
Controls the total diameter of:
- outer hue ring
- inner circular color field

Range:
- 55% to 100%

100% preserves the Wheel 2.12 behavior: the wheel nearly fills the available
top/bottom edges of the square UI.

The wheel always stays centered.

### Ring W
Controls the thickness of the outer hue ring.

Range:
- 6% to 32% of the outer radius

Changing Ring W gives the inner color field more or less room while keeping
the outer diameter unchanged.

### Persistence
Both Size and Ring W are saved automatically.

No OKLCH color algorithm, HSV outer ring, Lock, Rebase, marker,
Color sliders, Canvas picking, UI scale, or pen/mouse behavior changed.


## Wheel 2.14 - HSV outer ring / OKLCH inner field alignment

Built directly from Wheel 2.13 OKLCH.

The outer ring is pure HSV/HSB, while the inner field uses OKLCH.
Previously the same numeric hue angle was reused in both spaces, but HSV hue
degrees and OKLCH hue degrees do not represent exactly the same visible hue.

2.14 changes only the angular mapping layer:

direction
-> pure HSV(H,100,100)
-> RGB
-> OKLCH
-> use that OKLCH Hue in the inner field

This keeps the inner field perceptual OKLCH behavior while making each radial
direction correspond to the same visible hue family shown on the outer ring.

Unchanged:
- Range / Hues / Chroma / Gray
- Size / Ring W
- Lock / Rebase
- pure HSV outer ring
- exact Canvas RGB picking
- markers
- Color sliders
- Advanced UI
- persistence
- pen / mouse behavior


## Wheel 2.15 - hard HSV Hue / soft OKLCH L+C

This version changes the INNER FIELD mapping strategy.

### Why 2.14 still drifted

2.14 aligned each outer HSV hue anchor with an OKLCH hue at the outer endpoint.

But a constant OKLCH Hue path does not stay at a constant HSV Hue as Chroma /
Lightness change, especially through blue and purple regions.

So radial colors could still visibly rotate away from the outer ring.

### New priority model

HARD constraint:
- inner radial direction always keeps the exact HSV/HSB Hue of the outer ring

SOFT perceptual targets:
- OKLCH Lightness
- OKLCH Chroma

For each hue/radius sample the solver:
1. fixes HSV Hue
2. finds the highest Saturation that can still reach the target OKLCH Lightness
3. solves Brightness to match that Lightness
4. adjusts Saturation to approach the requested OKLCH Chroma
5. if the requested Chroma is impossible at that Lightness, uses the maximum
   feasible chroma without changing Hue

### Performance

The expensive correction is precomputed in a small LUT:
- angular samples = Hues
- radial samples = 48

Only S and V are interpolated.
The actual per-pixel Hue is still the exact geometric HSV ring Hue.

### Marker fix

For colors coming from Photoshop/Color sliders, the inner-disc marker angle now
uses the current RGB -> HSV Hue, matching the new angular axis.

Unchanged:
- outer pure HSV ring
- Range / Hues / Chroma / Gray
- Size / Ring W
- Lock / Rebase
- exact Canvas RGB picking
- Color sliders
- Advanced UI
- persistence
- pen / mouse behavior


## Wheel 2.17 - corrected per-Hue normalized Chroma build

2.16 had a packaging/refactor bug: `drawWheel()` referenced normalized radial
functions that had accidentally been removed from the final JavaScript file.
That caused a runtime ReferenceError before Canvas rendering, leaving the wheel
area black while the rest of the UI still appeared.

2.17 is rebuilt from the working Wheel 2.15 base.

### Color model

Preserved from 2.15:
- angle = exact outer-ring HSV Hue
- OKLCH Lightness is matched as closely as possible

Improved radial model:
- radius = percentage of each Hue's own available Chroma at that Lightness
- different Hues no longer compete for one absolute OKLCH C target

Chroma controls edge gamut utilization:
- 0 -> 75%
- 25 -> 81.25%
- 50 -> 87.5%
- 100 -> 100%

### Validation

Before packaging, 2.17 verifies:
- all normalized-Chroma helper functions exist
- no old absolute-Chroma solver references remain
- JavaScript passes syntax checking

All other Wheel 2.15 features remain unchanged.


## Wheel 2.18
- Range max increased from 90 to 200.
- Hues max increased from 24 to 72.
- The internal Range transition clamp was expanded from 0.90 to 2.00, so values above 90 now have real effect instead of being silently capped.
- Higher Hues improves angular smoothness but may redraw a bit slower on older systems.


## Wheel 2.19 - Range/Hues presets

Added a Preset control under Advanced.

Fine:
- Range 120
- Hues 72

Balanced:
- Range 90
- Hues 36

Performance:
- Range 90
- Hues 16

Custom:
- shown automatically whenever Range/Hues do not exactly match a preset

The preset is only a shortcut. Range and Hues remain fully editable up to:
- Range 200
- Hues 72

Why Performance keeps Range at 90:
Hues is the parameter that materially increases angular LUT work and redraw cost.
Range mainly changes radial appearance, so the performance preset reduces Hues
without unnecessarily changing the color-field look.

Preset/current values continue to persist automatically.


## Wheel 2.20 - radial parameter model redesign

Removed the overlapping Range / Chroma / Gray model.

### C Min
Center chroma lower limit, as a percentage of each Hue's own maximum available
Chroma at the current OKLCH Lightness.

### C Max
Upper chroma limit, on the same per-Hue normalized scale.

### Transition
Percentage of radius used to move from C Min to C Max.
- 100: reaches C Max at the outer edge
- 50: reaches C Max halfway out, then stays there
- 20: much faster transition near the center

There is no hard Gray core anymore.

Fine / Balanced / Performance presets now change only Hues (72 / 36 / 16), so
quality presets no longer alter the artist's radial color-field settings.

2.19 migration:
- C Min defaults to 0
- old Chroma maps to the previous 75..100% edge gamut usage as C Max
- old Range maps to Transition, capped at 100
- old Gray is intentionally discarded because its hard neutral disk is the
  behavior this redesign removes

Everything else remains unchanged.


## Wheel 2.21 OKLCH Performance

Performance-only pass based on 2.20 color behavior.

- Caps procedural Canvas preview DPR at 1.25.
- Coalesces repeated redraw requests into one animation-frame draw.
- Adds visual-key and inner-LUT caches.
- Reuses one fixed-Hue profile across all radial samples for that Hue.
- Uses 28/32/36 radial LUT samples depending on Hues instead of always 48.
- Prevents overlapping 80 ms Photoshop foreground reads.
- Canvas picking uses actual canvas/CSS scale after render-resolution optimization.
- Unlocked selection/rebase explicitly invalidates caches and forces a fresh wheel redraw.

Important behavior note: the 2.20 wheel field is fundamentally based on the current OKLCH Lightness. Inner-wheel colors are generated to preserve that Lightness, so selecting another inner color while unlocked can legitimately produce an almost identical field even though a real redraw occurred. A brightness/lightness change will visibly rebuild the field.


## Wheel 2.22 - unlocked Chroma-window navigation

C Min / C Max are now treated as a movable window over the complete
0..100% available-Chroma axis when Lock is OFF.

Example:
- current C Min / C Max = 0 / 50
- pick the outer edge (= 50%)
- new window becomes 50 / 100
- wheel redraws with the new purity range

The existing window width is preserved. When the window reaches the 100%
ceiling it stops as a whole instead of collapsing.

If C Min / C Max are already 0 / 100:
- the wheel already shows the complete Chroma gamut
- inner picks update Photoshop foreground color and markers
- no heavy wheel redraw is performed

Lock ON behavior is unchanged:
- C Min / C Max stay fixed
- the wheel stays fixed
- inner picks only select colors from the locked field

All Wheel 2.21 performance optimizations are retained.


## Wheel 2.23 - bidirectional current-Chroma reference model

C Min / C Max semantics are changed.

They are no longer absolute inner/outer Chroma bounds.

They now mean:
- C Min = how many percentage points of available Chroma to show BELOW
  the current/reference color
- C Max = how many percentage points to show ABOVE the current/reference color

Example:
- current usable-Chroma fraction = 60%
- C Min = 40
- C Max = 30
- actual radial field = 20% .. 90%

The current color marker is placed at its real position inside that range.
It is no longer forced to the wheel center / C Min boundary.

This makes exploration bidirectional:
- move toward gray
- then move outward toward color again
- no one-way C-window pushing

External color changes are now public inputs to the Wheel:
- HSB Color sliders
- Photoshop foreground color / eyedropper
- Wheel itself

When unlocked, any Chroma change updates `currentChromaFraction`, recomputes the
effective radial field and redraws only when the effective field really changed.

Lock freezes:
- basis Lightness
- reference Chroma fraction
- effective C Min/C Max delta field

Migration:
Old 2.20-2.22 C Min/C Max values used incompatible absolute-bound semantics.
On first 2.23 launch those two values reset to 50 / 50. Other saved settings
remain intact.

All 2.21 performance optimizations are retained.


## Wheel 2.24 - refresh performance pass

Built directly from the functionally-stable Wheel 2.23.

No color-window or interaction semantics changed.

### 1. Reusable Hue correction curves

Previously every C Min/C Max reference change rebuilt the inner LUT by repeatedly
solving OKLCH Lightness -> HSV S/V for every radial sample.

2.24 now builds one reusable Chroma correction curve per angular Hue:
- expensive Lightness solving is done once
- C-window changes only sample/interpolate those curves
- curves are reused while preview Lightness and Hues stay the same

This is particularly effective for normal Wheel picking because the inner field
is designed to keep Lightness nearly constant while Chroma changes.

### 2. Static geometry + outer-ring cache

The following no longer run again after every selected color:
- per-pixel sqrt distance
- per-pixel atan2 geometry
- outer HSV ring generation
- static dark background generation

They are cached until wheel geometry actually changes.

A normal refresh now:
- copies the cached background/ring image
- recalculates only inner-disc pixels

### 3. Preview Lightness stability

Preview Lightness is quantized to 0.1 L* for cache identity.
This prevents tiny RGB round-trip noise from invalidating every Hue profile.

The maximum preview difference is 0.05 L*, which is visually negligible.
Photoshop foreground RGB and the user's selected Canvas pixel remain normal RGB
values; this only affects when expensive preview caches are reused.

### 4. Radial LUT reduction

Radial LUT samples are now:
- 24 in light mode
- 28 in normal mode
- 32 in high-Hues mode

Continuous interpolation is retained.

Preserved from 2.23:
- bidirectional C Min/C Max delta model
- current-Chroma reference behavior
- external Photoshop/HSB Chroma synchronization
- Lock
- HSV outer ring
- OKLCH perceptual Lightness
- Transition
- Size / Ring W
- exact visible Canvas selection
- Advanced UI
- persistence
- pen / mouse behavior
