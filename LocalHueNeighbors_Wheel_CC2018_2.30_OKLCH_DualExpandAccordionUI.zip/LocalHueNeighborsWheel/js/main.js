(()=>{
"use strict";

const $=id=>document.getElementById(id);

const state={
  rgb:{r:128,g:128,b:128},
  lch:{L:53,C:0,h:0},

  chromaMin:50,     // % Chroma range available BELOW current color
  chromaMax:50,     // % Chroma range available ABOVE current color
  transition:100,   // % radius used to move from C Min to C Max
  hues:36,          // angular hue sampling resolution (higher = smoother but heavier)
  height:238,
  uiScale:100,
  advancedOpen:false,
  fieldCollapsed:false,
  colorCollapsed:false,

  // Geometry controls
  wheelSize:100,   // total wheel diameter as % of max available diameter
  ringWidth:15,    // outer hue-ring thickness as % of outer radius

  qualityPreset:"custom",

  locked:false,
  anchorRgb:null,
  anchorLch:null,
  anchorChromaFraction:null,

  // Current color's Chroma as a fraction of the maximum available
  // at its own HSV Hue + OKLCH Lightness.
  currentChromaFraction:0.5,

  // Exact polar location of the latest inner-disc pick while locked.
  // This avoids reverse-mapping a gamut-compressed RGB back to the wrong radius.
  lockedMarkerPolar:null,

  dragging:false,
  sliderDragging:false,
  pointerId:null,
  mode:null,

  psWriteBusy:false,
  psReadBusy:false,
  lastPhotoshopRGB:"",
  suppressSyncUntil:0
};

let wheelDrawRaf=0;
let wheelDrawForce=false;
let lastWheelVisualKey="";
let innerLutCacheKey="";
let innerLutCache=null;

// 2.24 performance caches (kept in 2.26):
// - Hue correction curves depend only on preview Lightness + Hues.
// - Geometry/ring pixels depend only on wheel size/shape.
let hueCurveCacheKey="";
let hueCurveCache=null;

let wheelGeometryCacheKey="";
let wheelGeometryCache=null;

const WHEEL_UI_STORAGE_KEY="LocalHueNeighborsWheel.ui.v1";

function loadWheelUiState(){
  try{
    const raw=localStorage.getItem(WHEEL_UI_STORAGE_KEY);
    if(!raw)return {};
    return JSON.parse(raw)||{};
  }catch(_){
    return {};
  }
}

function saveWheelUiState(){
  try{
    localStorage.setItem(WHEEL_UI_STORAGE_KEY,JSON.stringify({
      scale:state.uiScale,
      height:state.height,
      chromaRangeModel:"delta-v1",
      chromaMin:state.chromaMin,
      chromaMax:state.chromaMax,
      transition:state.transition,
      hues:state.hues,
      advancedOpen:state.advancedOpen,
      fieldCollapsed:state.fieldCollapsed,
      colorCollapsed:state.colorCollapsed,
      wheelSize:state.wheelSize,
      ringWidth:state.ringWidth,
      qualityPreset:state.qualityPreset,
      locked:state.locked,
      anchorRgb:state.anchorRgb,
      anchorChromaFraction:state.anchorChromaFraction
    }));
  }catch(_){}
}

function applyWheelUiScale(v){
  state.uiScale=clamp(Math.round(Number(v)||100),70,150);
  document.querySelector(".panel").style.zoom=(state.uiScale/100);
  const inp=$("uiScaleInput");
  if(inp)inp.value=state.uiScale;
  scheduleResponsiveDensity();
}

function applyResponsiveDensity(){
  const panel=document.querySelector(".panel");
  if(!panel)return;

  panel.classList.remove("compact","ultraCompact");

  const viewH=Math.max(0,window.innerHeight||document.documentElement.clientHeight||0);

  function fits(){
    return panel.scrollHeight<=viewH+1;
  }

  if(!fits())panel.classList.add("compact");
  if(!fits())panel.classList.add("ultraCompact");
}

function scheduleResponsiveDensity(){
  requestAnimationFrame(applyResponsiveDensity);
}


function applyWheelAdvancedState(open){
  state.advancedOpen=!!open;

  const panel=document.querySelector(".panel");
  if(panel){
    panel.classList.toggle(
      "advancedOpen",
      state.advancedOpen
    );
  }

  const btn=$("advancedToggle");
  if(btn){
    btn.setAttribute(
      "aria-expanded",
      state.advancedOpen ? "true" : "false"
    );
  }

  scheduleResponsiveDensity();
}

function syncSectionToggleUI(){
  const fieldBtn=$("fieldSectionToggle");
  const colorBtn=$("colorSectionToggle");
  const fieldBar=$("fieldCollapsedBar");
  const colorBar=$("colorCollapsedBar");

  if(fieldBtn){
    fieldBtn.setAttribute("aria-expanded", state.fieldCollapsed ? "false" : "true");
    fieldBtn.title = state.fieldCollapsed ? "Expand color field section" : "Collapse color field section";
  }

  if(colorBtn){
    colorBtn.setAttribute("aria-expanded", state.colorCollapsed ? "false" : "true");
    colorBtn.title = state.colorCollapsed ? "Expand color controls section" : "Collapse color controls section";
  }

  if(fieldBar){
    fieldBar.setAttribute("aria-label","Expand color field section");
    fieldBar.title="Expand color field section";
  }

  if(colorBar){
    colorBar.setAttribute("aria-label","Expand color controls section");
    colorBar.title="Expand color controls section";
  }
}

function applySectionCollapseState(fieldCollapsed,colorCollapsed){
  const nextField=!!fieldCollapsed;
  const nextColor=!!colorCollapsed;

  if(nextField && nextColor)return;

  state.fieldCollapsed=nextField;
  state.colorCollapsed=nextColor;

  const panel=document.querySelector(".panel");
  if(panel){
    panel.classList.toggle("fieldCollapsed",state.fieldCollapsed);
    panel.classList.toggle("colorCollapsed",state.colorCollapsed);
  }

  syncSectionToggleUI();
  saveWheelUiState();
  scheduleResponsiveDensity();

  setTimeout(()=>{
    invalidateWheelCaches();
    scheduleWheelDraw(true);
  },0);
}

function toggleFieldSection(){
  if(!state.fieldCollapsed && state.colorCollapsed)return;
  applySectionCollapseState(!state.fieldCollapsed, state.colorCollapsed);
}

function toggleColorSection(){
  if(state.fieldCollapsed && !state.colorCollapsed)return;
  applySectionCollapseState(state.fieldCollapsed, !state.colorCollapsed);
}

function expandFieldSection(){
  applySectionCollapseState(false, state.colorCollapsed);
}

function expandColorSection(){
  applySectionCollapseState(state.fieldCollapsed, false);
}

function setupSectionToggles(){
  const fieldBtn=$("fieldSectionToggle");
  const colorBtn=$("colorSectionToggle");
  const fieldBar=$("fieldCollapsedBar");
  const colorBar=$("colorCollapsedBar");

  if(fieldBtn){
    fieldBtn.addEventListener("click",()=>{
      toggleFieldSection();
    });
  }

  if(colorBtn){
    colorBtn.addEventListener("click",()=>{
      toggleColorSection();
    });
  }

  if(fieldBar){
    fieldBar.addEventListener("click",()=>{
      expandFieldSection();
    });
  }

  if(colorBar){
    colorBar.addEventListener("click",()=>{
      expandColorSection();
    });
  }

  syncSectionToggleUI();
}

function setupWheelAdvancedToggle(){
  const btn=$("advancedToggle");
  if(!btn)return;

  btn.addEventListener("click",function(){
    applyWheelAdvancedState(
      !state.advancedOpen
    );

    saveWheelUiState();

    // Layout changed; redraw once with the final measured size.
    setTimeout(function(){
      invalidateWheelCaches();
      scheduleWheelDraw(true);
    },0);
  });
}


function wheelBasisLch(){
  return state.locked && state.anchorLch
    ? state.anchorLch
    : state.lch;
}

function captureWheelAnchor(){
  state.anchorRgb={
    r:state.rgb.r,
    g:state.rgb.g,
    b:state.rgb.b
  };

  state.anchorLch={
    L:state.lch.L,
    C:state.lch.C,
    h:state.lch.h
  };

  state.anchorChromaFraction=state.currentChromaFraction;

  // A new basis invalidates any previous exact disc-pick location.
  state.lockedMarkerPolar=null;
}

function syncLockControl(){
  const input=$("lockInput");
  if(!input)return;

  input.checked=!!state.locked;

  const label=input.closest(".lockControl");
  if(label){
    label.classList.toggle("locked",!!state.locked);
  }
}

function setWheelLocked(locked,captureCurrent){
  state.locked=!!locked;

  if(state.locked){
    if(captureCurrent!==false || !state.anchorLch){
      captureWheelAnchor();
    }
  }else{
    state.anchorRgb=null;
    state.anchorLch=null;
    state.anchorChromaFraction=null;
    state.lockedMarkerPolar=null;
  }

  syncLockControl();
  saveWheelUiState();
  invalidateWheelCaches();
  scheduleWheelDraw(true);
  renderColorSliders();
}

function setupWheelLock(){
  const input=$("lockInput");
  if(!input)return;

  syncLockControl();

  input.addEventListener("change",function(){
    if(this.checked){
      // Freeze exactly what the wheel is based on right now.
      setWheelLocked(true,true);
    }else{
      // The current Photoshop foreground color becomes the live basis again.
      setWheelLocked(false,false);
    }
  });
}


function invalidateWheelCaches(){
  lastWheelVisualKey="";
  innerLutCacheKey="";
  innerLutCache=null;
}

function scheduleWheelDraw(force){
  if(force)wheelDrawForce=true;
  if(wheelDrawRaf)return;

  wheelDrawRaf=requestAnimationFrame(function(){
    const shouldForce=wheelDrawForce;
    wheelDrawRaf=0;
    wheelDrawForce=false;
    drawWheel(shouldForce);
  });
}

/* ------------------------------------------------------------
   CEP / Photoshop
------------------------------------------------------------ */

function hasCEP(){
  return !!(window.__adobe_cep__ &&
            typeof window.__adobe_cep__.evalScript==="function");
}

function evalScript(script,cb){
  if(!hasCEP()){
    if(cb)cb("NO_CEP");
    return;
  }

  try{
    window.__adobe_cep__.evalScript(script,res=>{
      if(cb)cb(res);
    });
  }catch(e){
    if(cb)cb("ERR:"+e.message);
  }
}

function yieldFocusToPhotoshop(){
  try{
    if(window.__adobe_cep__ && window.__adobe_cep__.dispatchEvent){
      window.__adobe_cep__.dispatchEvent({
        type:"com.adobe.PhotoshopLoseFocus",
        scope:"APPLICATION",
        appId:"PHXS",
        extensionId:"com.openai.localhueneighbors.wheel.panel",
        data:""
      });
    }
  }catch(_){}
}

function setPhotoshopColor(rgb,done){
  if(state.psWriteBusy){
    if(done)done(false,rgb);
    return;
  }

  state.psWriteBusy=true;

  const script=
    'try {'+
    'var c=new SolidColor();'+
    'c.rgb.red='+Number(rgb.r)+';'+
    'c.rgb.green='+Number(rgb.g)+';'+
    'c.rgb.blue='+Number(rgb.b)+';'+
    'app.foregroundColor=c;'+
    '"OK";'+
    '} catch(e) {"ERR:"+e.toString();}';

  evalScript(script,res=>{
    state.psWriteBusy=false;

    if(res==="OK"){
      state.lastPhotoshopRGB=
        Math.round(rgb.r)+","+
        Math.round(rgb.g)+","+
        Math.round(rgb.b);

      if(done)done(true,rgb);
    }else{
      if(done)done(false,rgb);
    }
  });
}

function readPhotoshopColor(force){
  if(state.psWriteBusy || state.psReadBusy || state.dragging || state.sliderDragging)return;

  state.psReadBusy=true;

  const script=
    'try {'+
    'var c=app.foregroundColor.rgb;'+
    'Math.round(c.red)+","+Math.round(c.green)+","+Math.round(c.blue);'+
    '} catch(e) {"ERR:"+e.toString();}';

  evalScript(script,res=>{
    state.psReadBusy=false;

    if(!res || res==="NO_CEP" || String(res).indexOf("ERR:")===0)return;

    const p=String(res).split(",");
    if(p.length!==3)return;

    const rgb={
      r:Number(p[0]),
      g:Number(p[1]),
      b:Number(p[2])
    };

    if([rgb.r,rgb.g,rgb.b].some(Number.isNaN))return;

    const key=rgb.r+","+rgb.g+","+rgb.b;

    if(force || key!==state.lastPhotoshopRGB){
      state.lastPhotoshopRGB=key;

      if(force || Date.now()>=state.suppressSyncUntil){
        setBaseColor(rgb);
      }
    }
  });
}

/* ------------------------------------------------------------
   Math / color conversion
------------------------------------------------------------ */

function clamp(v,lo,hi){
  return Math.max(lo,Math.min(hi,v));
}

function wrapHue(h){
  h%=360;
  if(h<0)h+=360;
  return h;
}

function smooth01(t){
  t=clamp(t,0,1);
  return t*t*(3-2*t);
}

function cosine01(t){
  t=clamp(t,0,1);
  return (1-Math.cos(Math.PI*t))*0.5;
}

function srgbToLinear(v){
  v/=255;
  return v<=.04045
    ? v/12.92
    : Math.pow((v+.055)/1.055,2.4);
}

function linearToSrgb(v){
  v=v<=.0031308
    ? 12.92*v
    : 1.055*Math.pow(v,1/2.4)-.055;

  return 255*v;
}


/* ------------------------------------------------------------
   OKLab / OKLCH conversion

   Public interface intentionally keeps the old function names:
   rgbToLch() and lchToRgb()

   so the Wheel logic above does not need to change.

   Returned scale:
   L = OKLab L * 100
   C = OKLCH C * 100
   h = degrees
------------------------------------------------------------ */

function rgbToLch(r,g,b){
  const R=srgbToLinear(r);
  const G=srgbToLinear(g);
  const B=srgbToLinear(b);

  const l=
    0.4122214708*R+
    0.5363325363*G+
    0.0514459929*B;

  const m=
    0.2119034982*R+
    0.6806995451*G+
    0.1073969566*B;

  const s=
    0.0883024619*R+
    0.2817188376*G+
    0.6299787005*B;

  const l_=Math.cbrt(l);
  const m_=Math.cbrt(m);
  const s_=Math.cbrt(s);

  const L=
    0.2104542553*l_+
    0.7936177850*m_-
    0.0040720468*s_;

  const a=
    1.9779984951*l_-
    2.4285922050*m_+
    0.4505937099*s_;

  const bb=
    0.0259040371*l_+
    0.7827717662*m_-
    0.8086757660*s_;

  const C=Math.sqrt(a*a+bb*bb);

  let h=Math.atan2(bb,a)*180/Math.PI;
  if(h<0)h+=360;

  return {
    L:L*100,
    C:C*100,
    h
  };
}

function oklchToRawRgb(L100,C100,h){
  const L=L100/100;
  const C=C100/100;
  const rad=wrapHue(h)*Math.PI/180;

  const a=C*Math.cos(rad);
  const b=C*Math.sin(rad);

  const l_=
    L+
    0.3963377774*a+
    0.2158037573*b;

  const m_=
    L-
    0.1055613458*a-
    0.0638541728*b;

  const s_=
    L-
    0.0894841775*a-
    1.2914855480*b;

  const l=l_*l_*l_;
  const m=m_*m_*m_;
  const s=s_*s_*s_;

  const R=
    4.0767416621*l-
    3.3077115913*m+
    0.2309699292*s;

  const G=
   -1.2684380046*l+
    2.6097574011*m-
    0.3413193965*s;

  const B=
   -0.0041960863*l-
    0.7034186147*m+
    1.7076147010*s;

  return {
    r:linearToSrgb(R),
    g:linearToSrgb(G),
    b:linearToSrgb(B)
  };
}

function rawRgbInGamut(rgb){
  return Number.isFinite(rgb.r) &&
         Number.isFinite(rgb.g) &&
         Number.isFinite(rgb.b) &&
         rgb.r>=0 && rgb.r<=255 &&
         rgb.g>=0 && rgb.g<=255 &&
         rgb.b>=0 && rgb.b<=255;
}

function lchToRgb(L,C,h){
  L=clamp(L,0,100);
  C=Math.max(0,C);
  h=wrapHue(h);

  let raw=oklchToRawRgb(L,C,h);

  if(rawRgbInGamut(raw)){
    return {
      r:Math.round(raw.r),
      g:Math.round(raw.g),
      b:Math.round(raw.b)
    };
  }

  // sRGB gamut compression:
  // preserve OKLCH Lightness and Hue,
  // reduce only Chroma until the color fits.
  let low=0;
  let high=C;
  let best=0;

  for(let i=0;i<16;i++){
    const mid=(low+high)*0.5;
    const test=oklchToRawRgb(L,mid,h);

    if(rawRgbInGamut(test)){
      best=mid;
      low=mid;
    }else{
      high=mid;
    }
  }

  raw=oklchToRawRgb(L,best,h);

  return {
    r:Math.round(clamp(raw.r,0,255)),
    g:Math.round(clamp(raw.g,0,255)),
    b:Math.round(clamp(raw.b,0,255))
  };
}

function hueVec(h){
  const r=wrapHue(h)*Math.PI/180;
  return {
    x:Math.cos(r),
    y:Math.sin(r)
  };
}

function vecHue(x,y,fallback){
  if(Math.abs(x)+Math.abs(y)<1e-8){
    return wrapHue(fallback);
  }

  return wrapHue(Math.atan2(y,x)*180/Math.PI);
}

function circularHueLerp(h0,h1,t){
  const a=hueVec(h0);
  const b=hueVec(h1);

  return vecHue(
    a.x*(1-t)+b.x*t,
    a.y*(1-t)+b.y*t,
    h0
  );
}

/* ------------------------------------------------------------
   Color sliders
------------------------------------------------------------ */

function formatNum(v,dec=1){
  return Math.abs(v-Math.round(v))<1e-8
    ? String(Math.round(v))
    : Number(v).toFixed(dec);
}

function rgbCss(c){
  return "rgb("+Math.round(c.r)+","+Math.round(c.g)+","+Math.round(c.b)+")";
}

function rgbToHsv(r,g,b){
  r/=255;g/=255;b/=255;

  const mx=Math.max(r,g,b);
  const mn=Math.min(r,g,b);
  const d=mx-mn;

  let h=0;

  if(d){
    if(mx===r)h=60*(((g-b)/d)%6);
    else if(mx===g)h=60*((b-r)/d+2);
    else h=60*((r-g)/d+4);
  }

  if(h<0)h+=360;

  return {
    h,
    s:mx===0?0:d/mx*100,
    v:mx*100
  };
}

function hsvToRgb(h,s,v){
  h=wrapHue(h);
  s/=100;
  v/=100;

  const c=v*s;
  const x=c*(1-Math.abs((h/60)%2-1));
  const m=v-c;

  let rp=0,gp=0,bp=0;

  if(h<60){rp=c;gp=x}
  else if(h<120){rp=x;gp=c}
  else if(h<180){gp=c;bp=x}
  else if(h<240){gp=x;bp=c}
  else if(h<300){rp=x;bp=c}
  else{rp=c;bp=x}

  return {
    r:Math.round((rp+m)*255),
    g:Math.round((gp+m)*255),
    b:Math.round((bp+m)*255)
  };
}

function rgbToCmyk(r,g,b){
  r/=255;g/=255;b/=255;

  const k=1-Math.max(r,g,b);

  if(k>=.999999){
    return {c:0,m:0,y:0,k:100};
  }

  return {
    c:(1-r-k)/(1-k)*100,
    m:(1-g-k)/(1-k)*100,
    y:(1-b-k)/(1-k)*100,
    k:k*100
  };
}

function cmykToRgb(c,m,y,k){
  c/=100;m/=100;y/=100;k/=100;

  return {
    r:Math.round(255*(1-c)*(1-k)),
    g:Math.round(255*(1-m)*(1-k)),
    b:Math.round(255*(1-y)*(1-k))
  };
}

function hueGradient(){
  return "linear-gradient(to right,"+
    "#f00 0%,"+
    "#ff0 16.67%,"+
    "#0f0 33.33%,"+
    "#0ff 50%,"+
    "#00f 66.67%,"+
    "#f0f 83.33%,"+
    "#f00 100%)";
}

function rgbChannelGradient(channel,rgb){
  const a={r:rgb.r,g:rgb.g,b:rgb.b};
  const b={r:rgb.r,g:rgb.g,b:rgb.b};

  a[channel]=0;
  b[channel]=255;

  return "linear-gradient(to right,"+
    rgbCss(a)+","+
    rgbCss(b)+")";
}

function makeCustomSelect(el,options,initialValue,onChange){
  if(!el)return null;

  let value=String(initialValue);

  const button=document.createElement("div");
  button.className="customSelectButton";

  const label=document.createElement("span");

  const arrow=document.createElement("span");
  arrow.className="customSelectArrow";
  arrow.textContent="▼";

  button.appendChild(label);
  button.appendChild(arrow);

  const menu=document.createElement("div");
  menu.className="customSelectMenu";

  function getOpt(v){
    return options.find(o=>String(o.value)===String(v))||options[0];
  }

  function sync(){
    const opt=getOpt(value);

    label.textContent=opt.label;
    el.dataset.value=String(opt.value);

    Array.prototype.forEach.call(
      menu.children,
      ch=>{
        ch.classList.toggle(
          "active",
          String(ch.dataset.value)===String(opt.value)
        );
      }
    );
  }

  function close(){
    el.classList.remove("open");
  }

  options.forEach(opt=>{
    const item=document.createElement("div");
    item.className="customSelectOption";
    item.dataset.value=String(opt.value);
    item.textContent=opt.label;

    item.addEventListener("pointerdown",e=>{
      e.preventDefault();
    });

    item.addEventListener("pointerup",e=>{
      value=String(opt.value);
      sync();
      close();

      if(onChange)onChange(opt.value);

      e.preventDefault();
    });

    menu.appendChild(item);
  });

  button.addEventListener("pointerdown",e=>{
    document.querySelectorAll(".customSelect.open").forEach(other=>{
      if(other!==el)other.classList.remove("open");
    });

    if(el.classList.contains("open")){
      close();
    }else{
      el.classList.add("open");
    }

    e.preventDefault();
  });

  el.innerHTML="";
  el.appendChild(button);
  el.appendChild(menu);

  sync();

  return el;
}

document.addEventListener("pointerdown",e=>{
  document.querySelectorAll(".customSelect.open").forEach(el=>{
    if(!el.contains(e.target)){
      el.classList.remove("open");
    }
  });
});

function commitSliderColor(rgb){
  state.suppressSyncUntil=Date.now()+140;

  setPhotoshopColor(rgb,(ok,confirmed)=>{
    if(ok){
      setBaseColor(confirmed);
    }else{
      setTimeout(
        ()=>readPhotoshopColor(true),
        30
      );
    }
  });
}

function makeSliderRow(label,min,max,step,value,gradient,onInput){
  const container=$("colorSliders");

  const row=document.createElement("div");
  row.className="sliderRow";

  const lab=document.createElement("div");
  lab.className="sliderLabel";
  lab.textContent=label;

  const slider=document.createElement("div");
  slider.className="customSlider";

  if(gradient){
    slider.style.background=gradient;
  }

  const fill=document.createElement("div");
  fill.className="customSliderFill";

  const thumb=document.createElement("div");
  thumb.className="customSliderThumb";

  slider.appendChild(fill);
  slider.appendChild(thumb);

  const num=document.createElement("input");
  num.type="number";
  num.className="sliderValue";
  num.min=min;
  num.max=max;
  num.step=step;

  let current=clamp(Number(value),Number(min),Number(max));
  let dragging=false;
  let pointerId=null;

  function quantize(v){
    const mn=Number(min);
    const mx=Number(max);
    const st=Number(step)||1;

    v=clamp(Number(v),mn,mx);

    return clamp(
      Math.round((v-mn)/st)*st+mn,
      mn,mx
    );
  }

  function syncVisual(v){
    current=quantize(v);

    const t=(current-Number(min))/(Number(max)-Number(min));

    thumb.style.left=(t*100)+"%";
    fill.style.width=(t*100)+"%";
    num.value=formatNum(current,1);
  }

  function valueFromX(clientX){
    const rect=slider.getBoundingClientRect();
    const x=clamp(clientX-rect.left,0,rect.width);
    const t=rect.width?x/rect.width:0;

    return quantize(
      Number(min)+t*(Number(max)-Number(min))
    );
  }

  function preview(e){
    const v=valueFromX(e.clientX);
    syncVisual(v);
    onInput(v,false);
  }

  function cleanup(){
    document.removeEventListener("pointermove",move,true);
    document.removeEventListener("pointerup",up,true);
    document.removeEventListener("pointercancel",cancel,true);

    dragging=false;
    pointerId=null;
    state.sliderDragging=false;
  }

  function move(e){
    if(!dragging||e.pointerId!==pointerId)return;

    preview(e);
    e.preventDefault();
  }

  function up(e){
    if(!dragging||e.pointerId!==pointerId)return;

    const v=valueFromX(e.clientX);
    syncVisual(v);

    cleanup();

    // Commit asynchronously. Keep the thumb at the chosen local position
    // until Photoshop confirms the new foreground color.
    // setBaseColor() will perform the authoritative re-render.
    onInput(v,true);

    e.preventDefault();
  }

  function cancel(e){
    if(e.pointerId!==pointerId)return;

    cleanup();
    renderColorSliders();
  }

  slider.addEventListener("pointerdown",e=>{
    if(e.isPrimary===false)return;

    dragging=true;
    pointerId=e.pointerId;
    state.sliderDragging=true;

    preview(e);

    document.addEventListener("pointermove",move,true);
    document.addEventListener("pointerup",up,true);
    document.addEventListener("pointercancel",cancel,true);

    e.preventDefault();
    e.stopPropagation();
  });

  num.addEventListener("change",()=>{
    const v=quantize(num.value);
    syncVisual(v);
    // Do not rebuild from stale state.rgb while Photoshop is committing.
    onInput(v,true);
  });

  slider.addEventListener("wheel",e=>{
    e.preventDefault();

    const st=Number(step)||1;
    const v=quantize(
      current+(e.deltaY>0?-st:st)
    );

    syncVisual(v);
    // Keep the new visual value in place until Photoshop confirms it.
    onInput(v,true);
  },{passive:false});

  syncVisual(current);

  row.appendChild(lab);
  row.appendChild(slider);
  row.appendChild(num);

  container.appendChild(row);

  attachIconStepper(num,dir=>{
    const st=Number(step)||1;
    const v=quantize(current+dir*st);
    syncVisual(v);
    onInput(v,true);
  });

  scheduleResponsiveDensity();
}

function renderWebSafe(rgb){
  const container=$("colorSliders");
  const levels=[0,51,102,153,204,255];

  function nearest(v){
    return levels.reduce(
      (a,b)=>Math.abs(b-v)<Math.abs(a-v)?b:a
    );
  }

  const nr=nearest(rgb.r);
  const ng=nearest(rgb.g);
  const nb=nearest(rgb.b);

  const row=document.createElement("div");
  row.className="webRow";

  const sw=document.createElement("div");
  sw.className="webSwatches";

  const candidates=[];

  [-1,0,1].forEach(dr=>
    [-1,0,1].forEach(dg=>
      [-1,0,1].forEach(db=>{
        const ri=clamp(levels.indexOf(nr)+dr,0,5);
        const gi=clamp(levels.indexOf(ng)+dg,0,5);
        const bi=clamp(levels.indexOf(nb)+db,0,5);

        const c={
          r:levels[ri],
          g:levels[gi],
          b:levels[bi]
        };

        const key=c.r+","+c.g+","+c.b;

        if(!candidates.some(x=>x.key===key)){
          candidates.push({key,c});
        }
      })
    )
  );

  candidates.slice(0,18).forEach(o=>{
    const btn=document.createElement("button");
    btn.className="webSwatch";
    btn.style.background=rgbCss(o.c);

    btn.addEventListener("click",()=>{
      commitSliderColor(o.c);
    });

    sw.appendChild(btn);
  });

  const info=document.createElement("div");
  info.className="webInfo";
  info.textContent="6×6×6";

  row.appendChild(sw);
  row.appendChild(info);
  container.appendChild(row);
}

function renderColorSliders(){
  const container=$("colorSliders");
  if(!container)return;

  container.innerHTML="";

  const mode=$("colorMode").dataset.value||"HSB";
  const rgb={
    r:state.rgb.r,
    g:state.rgb.g,
    b:state.rgb.b
  };

  if(mode==="RGB"){
    ["r","g","b"].forEach(ch=>{
      makeSliderRow(
        ch.toUpperCase(),
        0,255,1,
        rgb[ch],
        rgbChannelGradient(ch,rgb),
        (v,commit)=>{
          if(!commit)return;

          const c={
            r:state.rgb.r,
            g:state.rgb.g,
            b:state.rgb.b
          };

          c[ch]=Math.round(v);
          commitSliderColor(c);
        }
      );
    });
  }
  else if(mode==="HSB"){
    const h=rgbToHsv(rgb.r,rgb.g,rgb.b);

    makeSliderRow(
      "H",
      0,360,.1,
      h.h,
      hueGradient(),
      (v,commit)=>{
        if(commit){
          commitSliderColor(
            hsvToRgb(v,h.s,h.v)
          );
        }
      }
    );

    makeSliderRow(
      "S",
      0,100,.1,
      h.s,
      "linear-gradient(to right,#888,"+
        rgbCss(hsvToRgb(h.h,100,h.v))+
        ")",
      (v,commit)=>{
        if(commit){
          commitSliderColor(
            hsvToRgb(h.h,v,h.v)
          );
        }
      }
    );

    makeSliderRow(
      "B",
      0,100,.1,
      h.v,
      "linear-gradient(to right,#000,"+
        rgbCss(hsvToRgb(h.h,h.s,100))+
        ")",
      (v,commit)=>{
        if(commit){
          commitSliderColor(
            hsvToRgb(h.h,h.s,v)
          );
        }
      }
    );
  }
  else if(mode==="GRAY"){
    const Y=Math.round(
      (.2126*rgb.r+.7152*rgb.g+.0722*rgb.b)/255*100
    );

    makeSliderRow(
      "K",
      0,100,.1,
      100-Y,
      "linear-gradient(to right,#fff,#000)",
      (v,commit)=>{
        if(!commit)return;

        const g=Math.round(255*(1-v/100));

        commitSliderColor({
          r:g,g:g,b:g
        });
      }
    );
  }
  else if(mode==="CMYK"){
    const cmyk=rgbToCmyk(rgb.r,rgb.g,rgb.b);

    [
      ["C","c"],
      ["M","m"],
      ["Y","y"],
      ["K","k"]
    ].forEach(([label,key])=>{
      makeSliderRow(
        label,
        0,100,.1,
        cmyk[key],
        null,
        (v,commit)=>{
          if(!commit)return;

          const next=Object.assign({},cmyk);
          next[key]=v;

          commitSliderColor(
            cmykToRgb(
              next.c,next.m,next.y,next.k
            )
          );
        }
      );
    });
  }
  else if(mode==="LAB"){
    const xyz=rgbToXyz(rgb.r,rgb.g,rgb.b);
    const lab=xyzToLab(xyz.X,xyz.Y,xyz.Z);

    [
      ["L",0,100,.1,lab.L],
      ["a",-128,127,.1,lab.a],
      ["b",-128,127,.1,lab.b]
    ].forEach(([name,min,max,step,val])=>{
      makeSliderRow(
        name,
        min,max,step,val,
        null,
        (v,commit)=>{
          if(!commit)return;

          const next={
            L:lab.L,
            a:lab.a,
            b:lab.b
          };

          next[name]=v;

          const xyz2=labToXyz(
            next.L,next.a,next.b
          );

          commitSliderColor(
            xyzToRgb(
              xyz2.X,xyz2.Y,xyz2.Z,false
            )
          );
        }
      );
    });
  }
  else if(mode==="WEB"){
    renderWebSafe(rgb);
  }

  scheduleResponsiveDensity();
}

function setupColorSliders(){
  makeCustomSelect(
    $("colorMode"),
    [
      {value:"HSB",label:"HSB sliders"},
      {value:"RGB",label:"RGB sliders"},
      {value:"GRAY",label:"Grayscale slider"},
      {value:"CMYK",label:"CMYK sliders"},
      {value:"LAB",label:"Lab sliders"},
      {value:"WEB",label:"Web-safe color"}
    ],
    "HSB",
    ()=>renderColorSliders()
  );

  renderColorSliders();
}

/* ------------------------------------------------------------
   Wheel model
------------------------------------------------------------ */

function previewBasisLightness(L){
  return Math.round(
    clamp(Number(L)||0,0,100)*10
  )/10;
}


function getGeometry(){
  const canvas=$("wheelCanvas");
  const rect=canvas.getBoundingClientRect();

  const cssW=Math.max(1,rect.width);
  const cssH=Math.max(1,rect.height);
  // Performance: Photoshop CEP can report 1.5x/2x DPR. Rendering the
  // procedural field at full HiDPI multiplies pixel work dramatically.
  // 1.25 keeps edges clean while limiting preview cost.
  const screenDpr=Math.max(1,window.devicePixelRatio||1);
  const dpr=Math.min(screenDpr,1.25);

  const pxW=Math.max(1,Math.round(cssW*dpr));
  const pxH=Math.max(1,Math.round(cssH*dpr));

  const cx=cssW*0.5;
  const cy=cssH*0.5;

  // Wheel 2.13:
  // First determine the largest possible wheel with ~2 CSS px clearance.
  const availableRadius=Math.max(
    20,
    Math.min(cssW,cssH)*0.5-2
  );

  // Size scales the entire circular selector while keeping it centered.
  const sizeScale=clamp(
    state.wheelSize/100,
    0.55,
    1
  );

  const ringOuter=Math.max(
    20,
    availableRadius*sizeScale
  );

  // Ring W controls only the outer hue-ring thickness.
  // It is proportional to the selected wheel radius so it scales naturally.
  const widthScale=clamp(
    state.ringWidth/100,
    0.06,
    0.32
  );

  const ringWidth=clamp(
    ringOuter*widthScale,
    6,
    Math.max(6,ringOuter*0.38)
  );

  const ringInner=ringOuter-ringWidth;

  // Keep the existing dark separator gap between ring and inner disc.
  const discRadius=Math.max(
    12,
    ringInner-8
  );

  return {
    cssW,cssH,dpr,pxW,pxH,
    cx,cy,
    ringOuter,ringInner,discRadius
  };
}

function angleToRingHue(angleRad){
  // Top is red, then clockwise through yellow/green/cyan/blue/magenta.
  return wrapHue(angleRad*180/Math.PI+90);
}

function exactHsvHueAtPoint(x,y,g){
  const dx=x-g.cx;
  const dy=y-g.cy;

  if(Math.abs(dx)+Math.abs(dy)<1e-8){
    // Hue is irrelevant at the neutral center.
    // Use current Photoshop HSV hue as a harmless fallback.
    return rgbToHsv(
      state.rgb.r,
      state.rgb.g,
      state.rgb.b
    ).h;
  }

  return angleToRingHue(
    Math.atan2(dy,dx)
  );
}

function fixedHueProfileAtLightness(hue,targetL){
  hue=wrapHue(hue);
  targetL=clamp(targetL,0,100);

  function lchAt(s01,v01){
    const rgb=hsvToRgb(
      hue,
      clamp(s01,0,1)*100,
      clamp(v01,0,1)*100
    );

    return rgbToLch(
      rgb.r,
      rgb.g,
      rgb.b
    );
  }

  function solveVForL(s01){
    let lo=0;
    let hi=1;

    const atMax=lchAt(s01,1);

    // At this saturation the requested L is brighter than sRGB can reach.
    // Use V=100 as the best available result.
    if(atMax.L<=targetL){
      return {
        v:1,
        lch:atMax
      };
    }

    for(let i=0;i<11;i++){
      const mid=(lo+hi)*0.5;
      const cur=lchAt(s01,mid);

      if(cur.L<targetL){
        lo=mid;
      }else{
        hi=mid;
      }
    }

    const v=(lo+hi)*0.5;

    return {
      v:v,
      lch:lchAt(s01,v)
    };
  }

  // Maximum saturation that can still reach the requested OKLCH Lightness.
  let sLo=0;
  let sHi=1;

  for(let i=0;i<11;i++){
    const mid=(sLo+sHi)*0.5;
    const maxAtThisS=lchAt(mid,1);

    if(maxAtThisS.L>=targetL){
      sLo=mid;
    }else{
      sHi=mid;
    }
  }

  const maxS=sLo;
  const maxSolved=solveVForL(maxS);

  return {
    hue:hue,
    maxS:maxS,
    maxV:maxSolved.v,
    maxC:Math.max(0,maxSolved.lch.C),
    solveVForL:solveVForL
  };
}

function hsvAtFixedHueForChromaFraction(hue,targetL,chromaFraction){
  /*
    HARD constraint:
      HSV Hue stays exactly aligned with the outer ring.

    Radial meaning:
      0 = neutral
      1 = this Hue's own maximum usable Chroma at target OKLCH Lightness.

    This avoids making yellow, blue, green, etc. compete for one
    absolute OKLCH Chroma value.
  */
  const profile=fixedHueProfileAtLightness(
    hue,
    targetL
  );

  const fraction=clamp(
    chromaFraction,
    0,
    1
  );

  if(profile.maxC<=0.0001 || fraction<=0.0001){
    const neutral=profile.solveVForL(0);

    return {
      h:profile.hue,
      s:0,
      v:neutral.v*100,
      maxC:profile.maxC
    };
  }

  if(fraction>=0.9999){
    return {
      h:profile.hue,
      s:profile.maxS*100,
      v:profile.maxV*100,
      maxC:profile.maxC
    };
  }

  const targetC=profile.maxC*fraction;

  let lo=0;
  let hi=profile.maxS;

  for(let i=0;i<12;i++){
    const mid=(lo+hi)*0.5;
    const solved=profile.solveVForL(mid);

    if(solved.lch.C<targetC){
      lo=mid;
    }else{
      hi=mid;
    }
  }

  const s=(lo+hi)*0.5;
  const solved=profile.solveVForL(s);

  return {
    h:profile.hue,
    s:s*100,
    v:solved.v*100,
    maxC:profile.maxC
  };
}

function hueAtDiscPoint(x,y,g){
  // Wheel 2.15:
  // Angular identity is now the exact HSV/HSB hue of the outer ring.
  // We no longer convert the direction into an OKLCH Hue axis.
  return exactHsvHueAtPoint(x,y,g);
}

function computeAvailableChromaFraction(rgb,lch){
  const hsv=rgbToHsv(
    rgb.r,
    rgb.g,
    rgb.b
  );

  const profile=fixedHueProfileAtLightness(
    hsv.h,
    lch.L
  );

  if(profile.maxC<=1e-7){
    return 0;
  }

  return clamp(
    lch.C/profile.maxC,
    0,
    1
  );
}

function wheelReferenceChromaFraction(){
  if(state.locked &&
     Number.isFinite(Number(state.anchorChromaFraction))){
    return clamp(
      state.anchorChromaFraction,
      0,
      1
    );
  }

  return clamp(
    state.currentChromaFraction,
    0,
    1
  );
}

function chromaWindowBounds(){
  /*
    C Min / C Max are DELTAS around the current/reference Chroma.

    Example:
      current = 60%
      C Min = 40
      C Max = 30

      field = 20% .. 90%

    The current color is therefore somewhere INSIDE the radial field,
    rather than being forced to the center/inner boundary.
  */
  const current=wheelReferenceChromaFraction();

  const below=clamp(
    state.chromaMin/100,
    0,
    1
  );

  const above=clamp(
    state.chromaMax/100,
    0,
    1
  );

  return {
    current:current,
    low:Math.max(
      0,
      current-below
    ),
    high:Math.min(
      1,
      current+above
    )
  };
}

function radialTransitionMix(rn){
  const t=clamp(rn,0,1);

  // Transition = how much radius is used to move from low bound to high bound.
  const width=clamp(
    state.transition/100,
    0.05,
    1
  );

  return smooth01(
    clamp(t/width,0,1)
  );
}

function chromaFractionAtRadius(rn){
  const bounds=chromaWindowBounds();

  return bounds.low+
    (bounds.high-bounds.low)*
    radialTransitionMix(rn);
}

function radiusForChroma(targetC){
  const basis=wheelBasisLch();

  const hsv=rgbToHsv(
    state.rgb.r,
    state.rgb.g,
    state.rgb.b
  );

  const profile=fixedHueProfileAtLightness(
    hsv.h,
    basis.L
  );

  if(profile.maxC<=1e-7){
    return 0;
  }

  const targetFraction=clamp(
    targetC/profile.maxC,
    0,
    1
  );

  const bounds=chromaWindowBounds();
  const low=bounds.low;
  const high=bounds.high;

  if(high-low<=1e-7){
    return 0;
  }

  if(targetFraction<=low){
    return 0;
  }

  if(targetFraction>=high){
    return 1;
  }

  const wantedMix=clamp(
    (targetFraction-low)/(high-low),
    0,
    1
  );

  let lo=0;
  let hi=1;

  for(let i=0;i<18;i++){
    const mid=(lo+hi)*0.5;

    if(radialTransitionMix(mid)<wantedMix){
      lo=mid;
    }else{
      hi=mid;
    }
  }

  return (lo+hi)*0.5;
}

function edgeCoverage(dist,radius){
  // ~1 CSS px anti-aliased edge, while the canvas itself is HiDPI.
  const aa=0.9;

  if(dist<=radius-aa)return 1;
  if(dist>=radius+aa)return 0;

  return 1-(dist-(radius-aa))/(aa*2);
}


function hsvFromFixedHueProfileForChromaFraction(profile,chromaFraction){
  const fraction=clamp(chromaFraction,0,1);

  if(profile.maxC<=0.0001 || fraction<=0.0001){
    const neutral=profile.solveVForL(0);
    return {h:profile.hue,s:0,v:neutral.v*100,maxC:profile.maxC};
  }

  if(fraction>=0.9999){
    return {h:profile.hue,s:profile.maxS*100,v:profile.maxV*100,maxC:profile.maxC};
  }

  const targetC=profile.maxC*fraction;
  let lo=0;
  let hi=profile.maxS;

  // Preview LUT does not need 12 rounds; 9 is visually indistinguishable
  // at the interpolated field resolution and cuts repeated OKLCH work.
  for(let i=0;i<9;i++){
    const mid=(lo+hi)*0.5;
    const solved=profile.solveVForL(mid);
    if(solved.lch.C<targetC)lo=mid;
    else hi=mid;
  }

  const s=(lo+hi)*0.5;
  const solved=profile.solveVForL(s);
  return {h:profile.hue,s:s*100,v:solved.v*100,maxC:profile.maxC};
}


function buildHueCorrectionCurve(profile,sampleCount){
  const count=Math.max(
    24,
    Math.round(sampleCount)
  );

  const cNorm=new Float32Array(count+1);
  const sat=new Float32Array(count+1);
  const val=new Float32Array(count+1);

  let lastC=0;

  for(let i=0;i<=count;i++){
    const t=i/count;
    const s01=profile.maxS*t;
    const solved=profile.solveVForL(s01);

    let cn=profile.maxC>1e-7
      ? clamp(solved.lch.C/profile.maxC,0,1)
      : 0;

    // Keep the inverse lookup monotonic even around tiny numerical wiggles.
    if(cn<lastC)cn=lastC;
    lastC=cn;

    cNorm[i]=cn;
    sat[i]=s01*100;
    val[i]=solved.v*100;
  }

  // Guarantee exact endpoint.
  cNorm[count]=1;
  sat[count]=profile.maxS*100;
  val[count]=profile.maxV*100;

  return {
    hue:profile.hue,
    count:count,
    cNorm:cNorm,
    sat:sat,
    val:val
  };
}

function sampleHueCorrectionCurve(curve,fraction){
  const f=clamp(fraction,0,1);

  if(f<=0){
    return {
      h:curve.hue,
      s:curve.sat[0],
      v:curve.val[0]
    };
  }

  if(f>=1){
    return {
      h:curve.hue,
      s:curve.sat[curve.count],
      v:curve.val[curve.count]
    };
  }

  let lo=0;
  let hi=curve.count;

  while(hi-lo>1){
    const mid=(lo+hi)>>1;

    if(curve.cNorm[mid]<f){
      lo=mid;
    }else{
      hi=mid;
    }
  }

  const c0=curve.cNorm[lo];
  const c1=curve.cNorm[hi];
  const denom=c1-c0;

  const t=denom>1e-7
    ? clamp((f-c0)/denom,0,1)
    : 0;

  return {
    h:curve.hue,
    s:curve.sat[lo]+
      (curve.sat[hi]-curve.sat[lo])*t,
    v:curve.val[lo]+
      (curve.val[hi]-curve.val[lo])*t
  };
}

function getHueCorrectionCurves(basis){
  const aCount=Math.max(
    3,
    Math.min(72,Math.round(state.hues))
  );

  const previewL=previewBasisLightness(
    basis.L
  );

  const key=[
    previewL.toFixed(1),
    aCount
  ].join("|");

  if(hueCurveCache &&
     hueCurveCacheKey===key){
    return hueCurveCache;
  }

  // More angular detail gets a slightly denser saturation curve.
  // This is still dramatically cheaper than solving every radial sample.
  const curveSamples=
    aCount>=60 ? 56 :
    aCount>=30 ? 48 :
    40;

  const curves=new Array(aCount);

  for(let ai=0;ai<aCount;ai++){
    const angle=(Math.PI*2*ai)/aCount;
    const hue=angleToRingHue(angle);

    const profile=fixedHueProfileAtLightness(
      hue,
      previewL
    );

    curves[ai]=buildHueCorrectionCurve(
      profile,
      curveSamples
    );
  }

  hueCurveCache={
    aCount:aCount,
    previewL:previewL,
    curves:curves
  };

  hueCurveCacheKey=key;
  return hueCurveCache;
}

function getInnerCorrectionLut(g,basis){
  const bounds=chromaWindowBounds();
  const previewL=previewBasisLightness(
    basis.L
  );

  const key=[
    previewL.toFixed(1),
    Number(bounds.low).toFixed(4),
    Number(bounds.high).toFixed(4),
    Math.round(state.transition),
    Math.round(state.hues)
  ].join("|");

  if(innerLutCache && innerLutCacheKey===key){
    return innerLutCache;
  }

  innerLutCache=buildInnerCorrectionLut(
    g,
    basis
  );

  innerLutCacheKey=key;
  return innerLutCache;
}

function buildInnerCorrectionLut(g,basis){
  const curveSet=getHueCorrectionCurves(
    basis
  );

  const aCount=curveSet.aCount;

  // Radial interpolation stays lightweight.
  const rCount=
    aCount>=60 ? 32 :
    aCount>=30 ? 28 :
    24;

  const rows=new Array(aCount);

  for(let ai=0;ai<aCount;ai++){
    const curve=curveSet.curves[ai];
    const row=new Array(rCount+1);

    for(let ri=0;ri<=rCount;ri++){
      const rn=ri/rCount;

      row[ri]=sampleHueCorrectionCurve(
        curve,
        chromaFractionAtRadius(rn)
      );
    }

    rows[ai]=row;
  }

  return {
    aCount:aCount,
    rCount:rCount,
    rows:rows
  };
}

function correctionFromLut(lut,angleRad,rn){
  // Angular coordinate in the same geometry used by the outer ring.
  const deg=wrapHue(
    angleRad*180/Math.PI
  );

  const aPos=deg/360*lut.aCount;
  const aWhole=Math.floor(aPos);

  const a0=((aWhole%lut.aCount)+lut.aCount)%lut.aCount;
  const a1=(a0+1)%lut.aCount;
  const at=aPos-aWhole;

  const rPos=clamp(rn,0,1)*lut.rCount;
  const r0=Math.floor(rPos);
  const r1=Math.min(lut.rCount,r0+1);
  const rt=rPos-r0;

  const p00=lut.rows[a0][r0];
  const p01=lut.rows[a0][r1];
  const p10=lut.rows[a1][r0];
  const p11=lut.rows[a1][r1];

  const s0=p00.s*(1-rt)+p01.s*rt;
  const s1=p10.s*(1-rt)+p11.s*rt;

  const v0=p00.v*(1-rt)+p01.v*rt;
  const v1=p10.v*(1-rt)+p11.v*rt;

  return {
    s:s0*(1-at)+s1*at,
    v:v0*(1-at)+v1*at
  };
}


function getWheelGeometryRenderCache(g){
  const key=[
    g.pxW,g.pxH,
    Number(g.dpr).toFixed(3),
    Number(g.cx).toFixed(2),
    Number(g.cy).toFixed(2),
    Number(g.discRadius).toFixed(2),
    Number(g.ringInner).toFixed(2),
    Number(g.ringOuter).toFixed(2)
  ].join("|");

  if(wheelGeometryCache &&
     wheelGeometryCacheKey===key){
    return wheelGeometryCache;
  }

  const total=g.pxW*g.pxH;
  const baseData=new Uint8ClampedArray(
    total*4
  );

  const bg=32;

  // Temporary arrays are converted to typed arrays once.
  const discIndex=[];
  const discRn=[];
  const discAngle=[];
  const discCover=[];

  let pixel=0;

  for(let py=0;py<g.pxH;py++){
    const y=(py+0.5)/g.dpr;

    for(let px=0;px<g.pxW;px++,pixel++){
      const x=(px+0.5)/g.dpr;
      const dx=x-g.cx;
      const dy=y-g.cy;
      const dist=Math.sqrt(
        dx*dx+dy*dy
      );

      let r=bg;
      let gg=bg;
      let b=bg;

      if(dist<=g.discRadius+1){
        const cover=edgeCoverage(
          dist,
          g.discRadius
        );

        if(cover>0){
          discIndex.push(pixel);
          discRn.push(
            clamp(
              dist/g.discRadius,
              0,
              1
            )
          );
          discAngle.push(
            Math.atan2(dy,dx)
          );
          discCover.push(cover);
        }
      }
      else if(dist>=g.ringInner-1 &&
              dist<=g.ringOuter+1){

        const outer=edgeCoverage(
          dist,
          g.ringOuter
        );

        const inner=
          dist>=g.ringInner
          ? 1
          : 1-edgeCoverage(
              dist,
              g.ringInner
            );

        const cover=clamp(
          outer*inner,
          0,
          1
        );

        if(cover>0){
          const hue=angleToRingHue(
            Math.atan2(dy,dx)
          );

          const rgb=hsvToRgb(
            hue,
            100,
            100
          );

          r=Math.round(
            bg*(1-cover)+
            rgb.r*cover
          );
          gg=Math.round(
            bg*(1-cover)+
            rgb.g*cover
          );
          b=Math.round(
            bg*(1-cover)+
            rgb.b*cover
          );
        }
      }

      const p=pixel*4;
      baseData[p]=r;
      baseData[p+1]=gg;
      baseData[p+2]=b;
      baseData[p+3]=255;
    }
  }

  wheelGeometryCache={
    baseData:baseData,
    discIndex:new Uint32Array(discIndex),
    discRn:new Float32Array(discRn),
    discAngle:new Float32Array(discAngle),
    discCover:new Float32Array(discCover)
  };

  wheelGeometryCacheKey=key;
  return wheelGeometryCache;
}

function drawWheel(force){
  const canvas=$("wheelCanvas");
  if(!canvas)return;

  const g=getGeometry();
  const basis=wheelBasisLch();
  const bounds=chromaWindowBounds();
  const previewL=previewBasisLightness(
    basis.L
  );

  const visualKey=[
    g.pxW,g.pxH,
    previewL.toFixed(1),
    Number(bounds.low).toFixed(4),
    Number(bounds.high).toFixed(4),
    Math.round(state.transition),
    Math.round(state.hues),
    Math.round(state.wheelSize),
    Math.round(state.ringWidth)
  ].join("|");

  if(!force &&
     visualKey===lastWheelVisualKey){
    placeMarkersAtBase();
    return;
  }

  const innerLut=getInnerCorrectionLut(
    g,
    basis
  );

  if(canvas.width!==g.pxW){
    canvas.width=g.pxW;
  }

  if(canvas.height!==g.pxH){
    canvas.height=g.pxH;
  }

  const ctx=canvas.getContext("2d");
  const geo=getWheelGeometryRenderCache(g);

  const img=ctx.createImageData(
    g.pxW,
    g.pxH
  );

  const data=img.data;

  // Background + outer HSV ring are static for this geometry.
  data.set(geo.baseData);

  const bg=32;
  const count=geo.discIndex.length;

  // Only inner-disc pixels change after a color selection.
  for(let i=0;i<count;i++){
    const angle=geo.discAngle[i];
    const rn=geo.discRn[i];
    const cover=geo.discCover[i];

    const hue=angleToRingHue(
      angle
    );

    const corrected=correctionFromLut(
      innerLut,
      angle,
      rn
    );

    const rgb=hsvToRgb(
      hue,
      corrected.s,
      corrected.v
    );

    const p=geo.discIndex[i]*4;

    data[p]=Math.round(
      bg*(1-cover)+
      rgb.r*cover
    );

    data[p+1]=Math.round(
      bg*(1-cover)+
      rgb.g*cover
    );

    data[p+2]=Math.round(
      bg*(1-cover)+
      rgb.b*cover
    );

    data[p+3]=255;
  }

  ctx.putImageData(
    img,
    0,
    0
  );

  ctx.save();
  ctx.setTransform(
    g.dpr,0,0,g.dpr,0,0
  );

  ctx.strokeStyle=
    "rgba(255,255,255,.18)";

  ctx.lineWidth=1/g.dpr;

  ctx.beginPath();
  ctx.arc(
    g.cx,g.cy,
    g.discRadius,
    0,Math.PI*2
  );
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(
    g.cx,g.cy,
    g.ringInner,
    0,Math.PI*2
  );
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(
    g.cx,g.cy,
    g.ringOuter,
    0,Math.PI*2
  );
  ctx.stroke();

  ctx.restore();

  lastWheelVisualKey=visualKey;
  placeMarkersAtBase();
}


/* ------------------------------------------------------------
   Picking / markers
------------------------------------------------------------ */

function setMarker(el,x,y){
  el.style.left=x+"px";
  el.style.top=y+"px";
  el.style.display="block";
}

function placeRingMarker(hue){
  const g=getGeometry();
  const marker=$("ringMarker");

  const rr=(g.ringInner+g.ringOuter)*0.5;
  const rad=(wrapHue(hue)-90)*Math.PI/180;

  setMarker(
    marker,
    g.cx+Math.cos(rad)*rr,
    g.cy+Math.sin(rad)*rr
  );
}

function placeMarkersAtBase(){
  const g=getGeometry();

  if(state.locked && state.lockedMarkerPolar){
    // Exact position selected from this fixed wheel.
    const rn=clamp(state.lockedMarkerPolar.rn,0,1);
    const angle=state.lockedMarkerPolar.angle;

    setMarker(
      $("discMarker"),
      g.cx+Math.cos(angle)*g.discRadius*rn,
      g.cy+Math.sin(angle)*g.discRadius*rn
    );
  }else{
    // Fallback for external Photoshop/sliders colors:
    // show the closest polar representation based on the current Hue/Chroma.
    const rn=radiusForChroma(
      state.lch.C
    );

    const rr=g.discRadius*rn;

    const currentHsv=rgbToHsv(
      state.rgb.r,
      state.rgb.g,
      state.rgb.b
    );

    const rad=(wrapHue(currentHsv.h)-90)*Math.PI/180;

    setMarker(
      $("discMarker"),
      g.cx+Math.cos(rad)*rr,
      g.cy+Math.sin(rad)*rr
    );
  }

  // Outer ring geometry is HSV/HSB, so the marker must use HSV Hue too.
  // It follows the CURRENT Photoshop foreground Hue even while Lock is on.
  const currentHsv=rgbToHsv(
    state.rgb.r,
    state.rgb.g,
    state.rgb.b
  );

  placeRingMarker(
    currentHsv.h
  );
}


function hitFromEvent(e){
  const canvas=$("wheelCanvas");
  const rect=canvas.getBoundingClientRect();
  const g=getGeometry();

  const x=clamp(e.clientX-rect.left,0,rect.width);
  const y=clamp(e.clientY-rect.top,0,rect.height);

  const dx=x-g.cx;
  const dy=y-g.cy;
  const dist=Math.sqrt(dx*dx+dy*dy);

  let mode="none";

  if(dist<=g.discRadius){
    mode="disc";
  }else if(dist>=g.ringInner &&
           dist<=g.ringOuter){
    mode="ring";
  }

  return {
    mode,x,y,dx,dy,dist,g
  };
}

function rgbFromRenderedDisc(hit){
  const canvas=$("wheelCanvas");
  const g=hit.g || getGeometry();
  const ctx=canvas.getContext("2d");

  // hit.x/y are CSS pixels; canvas pixels are scaled by devicePixelRatio.
  const scaleX=canvas.width/Math.max(1,g.cssW);
  const scaleY=canvas.height/Math.max(1,g.cssH);

  const px=clamp(
    Math.floor(hit.x*scaleX),
    0,
    canvas.width-1
  );

  const py=clamp(
    Math.floor(hit.y*scaleY),
    0,
    canvas.height-1
  );

  try{
    const d=ctx.getImageData(px,py,1,1).data;

    return {
      r:d[0],
      g:d[1],
      b:d[2]
    };
  }catch(_){
    // Safe mathematical fallback.
    const basis=wheelBasisLch();
    const rn=clamp(
      hit.dist/g.discRadius,
      0,1
    );

    const hue=angleToRingHue(
      Math.atan2(hit.dy,hit.dx)
    );

    const solved=hsvAtFixedHueForChromaFraction(
      hue,
      basis.L,
      chromaFractionAtRadius(rn)
    );

    return hsvToRgb(
      hue,
      solved.s,
      solved.v
    );
  }
}

function rgbFromHit(hit){
  const basis=wheelBasisLch();

  if(hit.mode==="ring"){
    const hue=angleToRingHue(
      Math.atan2(hit.dy,hit.dx)
    );

    // Ring selects the exact pure base Hue shown by the ring.
    return hsvToRgb(
      hue,
      100,
      100
    );
  }

  // Inner-disc picking samples the already-rendered UI pixel exactly.
  return rgbFromRenderedDisc(hit);
}

function previewHit(hit){
  if(hit.mode==="disc"){
    setMarker(
      $("discMarker"),
      hit.x,
      hit.y
    );

    const currentHsv=rgbToHsv(
      state.rgb.r,
      state.rgb.g,
      state.rgb.b
    );

    placeRingMarker(
      currentHsv.h
    );
  }
  else if(hit.mode==="ring"){
    // The ring is a BASE / REBASE selector.
    // Preview only the new base Hue on the ring.
    // Keep the current inner-disc marker where it actually is.
    const previewHsvHue=angleToRingHue(
      Math.atan2(hit.dy,hit.dx)
    );

    placeRingMarker(
      previewHsvHue
    );
  }
}

/* ------------------------------------------------------------
   Base state / interaction
------------------------------------------------------------ */

function setBaseColor(rgb,options){
  options=options||{};

  // Unless this update came from an exact locked disc pick,
  // the saved mouse/pointer location is no longer authoritative.
  if(!options.keepLockedMarker){
    state.lockedMarkerPolar=null;
  }

  // `state.rgb/lch` always mean the CURRENT Photoshop foreground color.
  state.rgb={
    r:Math.round(rgb.r),
    g:Math.round(rgb.g),
    b:Math.round(rgb.b)
  };

  state.lch=rgbToLch(
    state.rgb.r,
    state.rgb.g,
    state.rgb.b
  );

  state.currentChromaFraction=
    computeAvailableChromaFraction(
      state.rgb,
      state.lch
    );

  if(state.locked){
    // On first locked initialization, fall back to the current color only
    // if no persisted anchor exists.
    if(!state.anchorLch){
      captureWheelAnchor();
      saveWheelUiState();
      invalidateWheelCaches();
      scheduleWheelDraw(true);
    }else{
      // Keep the wheel pixels fixed. Only move the current-color markers.
      placeMarkersAtBase();
    }
  }else{
    /*
      Unlocked:
      the field follows the CURRENT color's Chroma reference.

      Do not forcibly invalidate caches. drawWheel() compares the effective
      low/high bounds + Lightness, so:
      - saturation/chroma changes redraw when needed
      - hue-only changes can reuse the same all-Hue field
      - a fully clipped 0..100 field does not waste a redraw
    */
    scheduleWheelDraw(false);
  }

  renderColorSliders();
}

function commitHit(hit){
  if(hit.mode==="none"){
    placeMarkersAtBase();
    return;
  }

  const rgb=rgbFromHit(hit);

  state.suppressSyncUntil=Date.now()+140;

  setPhotoshopColor(rgb,(ok,confirmed)=>{
    if(ok){
      if(hit.mode==="ring"){
        /*
          Wheel 2.7:
          The outer hue ring is now the BASE-COLOR / REBASE control.

          Selecting the ring:
          1. changes Photoshop foreground color
          2. makes that color the new wheel basis immediately
          3. regenerates the whole inner wheel
          4. preserves the current Lock on/off state

          So while locked, the user can jump to a new color family without
          doing Unlock -> select -> Lock.
        */

        state.rgb={
          r:Math.round(confirmed.r),
          g:Math.round(confirmed.g),
          b:Math.round(confirmed.b)
        };

        state.lch=rgbToLch(
          state.rgb.r,
          state.rgb.g,
          state.rgb.b
        );

        state.currentChromaFraction=
          computeAvailableChromaFraction(
            state.rgb,
            state.lch
          );

        if(state.locked){
          // Rebase the frozen wheel while staying locked.
          captureWheelAnchor();
          saveWheelUiState();
        }

        // Whether locked or unlocked, ring selection explicitly resets
        // the wheel around this newly chosen base color.
        invalidateWheelCaches();
        scheduleWheelDraw(true);
        renderColorSliders();
      }else{
        if(state.locked){
          // Preserve the exact point picked from the fixed wheel.
          state.lockedMarkerPolar={
            rn:clamp(hit.dist/hit.g.discRadius,0,1),
            angle:Math.atan2(hit.dy,hit.dx)
          };

          setBaseColor(
            confirmed,
            {keepLockedMarker:true}
          );
        }else{
          /*
            Wheel 2.23:
            no one-way window pushing.

            The picked color becomes the new CURRENT Chroma reference.
            C Min / C Max remain the user-defined inward/outward deltas,
            so the next field is regenerated around the new current purity
            and can move in either direction.
          */
          setBaseColor(
            confirmed
          );
        }
      }
    }else{
      setTimeout(
        ()=>readPhotoshopColor(true),
        30
      );
    }
  });
}

function beginDrag(e){
  if(e.isPrimary===false)return;

  const hit=hitFromEvent(e);
  if(hit.mode==="none")return;

  state.dragging=true;
  state.pointerId=e.pointerId;
  state.mode=hit.mode;

  previewHit(hit);

  document.addEventListener(
    "pointermove",
    dragMove,
    true
  );

  document.addEventListener(
    "pointerup",
    dragEnd,
    true
  );

  document.addEventListener(
    "pointercancel",
    dragCancel,
    true
  );

  e.preventDefault();
  e.stopPropagation();
}

function dragMove(e){
  if(!state.dragging ||
     e.pointerId!==state.pointerId){
    return;
  }

  const hit=hitFromEvent(e);

  if(hit.mode!=="none"){
    previewHit(hit);
  }

  e.preventDefault();
}

function endDragListeners(){
  document.removeEventListener(
    "pointermove",
    dragMove,
    true
  );

  document.removeEventListener(
    "pointerup",
    dragEnd,
    true
  );

  document.removeEventListener(
    "pointercancel",
    dragCancel,
    true
  );

  state.dragging=false;
  state.pointerId=null;
  state.mode=null;
}

function dragEnd(e){
  if(!state.dragging ||
     e.pointerId!==state.pointerId){
    return;
  }

  const hit=hitFromEvent(e);

  endDragListeners();
  commitHit(hit);

  e.preventDefault();
}

function dragCancel(e){
  if(e.pointerId!==state.pointerId)return;

  endDragListeners();
  placeMarkersAtBase();
}

/* ------------------------------------------------------------
   Controls
------------------------------------------------------------ */

function attachIconStepper(input,onStep){
  if(!input || input.dataset.iconStepper==="1")return;

  const wrapper=document.createElement("div");
  wrapper.className="numField";

  const parent=input.parentNode;
  if(!parent)return;

  parent.insertBefore(wrapper,input);
  wrapper.appendChild(input);

  const stepper=document.createElement("div");
  stepper.className="iconStepper";

  const up=document.createElement("button");
  up.type="button";
  up.className="iconBtn iconBtnUp";
  up.title="Increase";

  const down=document.createElement("button");
  down.type="button";
  down.className="iconBtn iconBtnDown";
  down.title="Decrease";

  function handle(dir,e){
    if(e){
      e.preventDefault();
      e.stopPropagation();
    }
    onStep(dir);
    input.focus();
  }

  up.addEventListener("click",e=>handle(1,e));
  down.addEventListener("click",e=>handle(-1,e));

  stepper.appendChild(up);
  stepper.appendChild(down);
  wrapper.appendChild(stepper);

  input.dataset.iconStepper="1";
}

function bindNumberInput(id,config){
  const input=$(id);
  if(!input)return;

  const {
    min,max,step,
    get,set,
    redraw=true
  }=config;

  function normalize(v){
    let n=Number(v);
    if(Number.isNaN(n))n=get();

    n=clamp(n,min,max);

    if(step>=1){
      n=Math.round(n/step)*step;
    }else{
      n=Math.round(n/step)*step;
    }

    return clamp(n,min,max);
  }

  function apply(v){
    const n=normalize(v);
    set(n);
    input.value=n;

    if(redraw){
      invalidateWheelCaches();
      scheduleWheelDraw(true);
    }
  }

  input.value=get();

  input.addEventListener("input",()=>{
    apply(input.value);
  });

  input.addEventListener("change",()=>{
    apply(input.value);
  });

  input.addEventListener("wheel",e=>{
    e.preventDefault();

    const dir=e.deltaY>0 ? -1 : 1;
    apply(get()+dir*step);
  },{passive:false});

  attachIconStepper(input,dir=>apply(get()+dir*step));
  scheduleResponsiveDensity();
}


function presetForValues(hues){
  const h=Math.round(Number(hues));

  if(h===72)return "fine";
  if(h===36)return "balanced";
  if(h===16)return "performance";

  return "custom";
}

function syncQualityPresetFromValues(){
  state.qualityPreset=presetForValues(state.hues);

  const select=$("qualityPreset");
  if(select)select.value=state.qualityPreset;
}

function applyQualityPreset(name){
  const presets={
    fine:{hues:72},
    balanced:{hues:36},
    performance:{hues:16}
  };

  const preset=presets[name];

  if(!preset){
    state.qualityPreset="custom";
    saveWheelUiState();
    return;
  }

  state.hues=preset.hues;
  state.qualityPreset=name;

  const huesInput=$("huesInput");
  const select=$("qualityPreset");

  if(huesInput)huesInput.value=state.hues;
  if(select)select.value=name;

  saveWheelUiState();
  invalidateWheelCaches();
  scheduleWheelDraw(true);
}

function setupQualityPreset(){
  const select=$("qualityPreset");
  if(!select)return;

  syncQualityPresetFromValues();

  select.addEventListener("change",function(){
    applyQualityPreset(this.value);
  });
}

function setupControls(){
  const saved=loadWheelUiState();

  if(Number.isFinite(Number(saved.scale))){
    state.uiScale=clamp(Number(saved.scale),70,150);
  }

  if(Number.isFinite(Number(saved.height))){
    state.height=clamp(Number(saved.height),140,420);
  }

  /*
    Wheel 2.23 delta model.

    Old 2.20-2.22 saved C Min/C Max values were absolute radial bounds,
    so they cannot be meaningfully reused as below/above differences.
    Migrate once to a symmetric 50 / 50 exploration range.
  */
  if(saved.chromaRangeModel==="delta-v1"){
    if(Number.isFinite(Number(saved.chromaMin))){
      state.chromaMin=clamp(Number(saved.chromaMin),0,100);
    }

    if(Number.isFinite(Number(saved.chromaMax))){
      state.chromaMax=clamp(Number(saved.chromaMax),0,100);
    }
  }else{
    state.chromaMin=50;
    state.chromaMax=50;
  }

  if(Number.isFinite(Number(saved.transition))){
    state.transition=clamp(Number(saved.transition),5,100);
  }else if(Number.isFinite(Number(saved.range))){
    state.transition=clamp(Number(saved.range),5,100);
  }

  if(Number.isFinite(Number(saved.hues))){
    state.hues=clamp(Math.round(Number(saved.hues)),3,72);
  }

  if(typeof saved.advancedOpen==="boolean"){
    state.advancedOpen=saved.advancedOpen;
  }

  if(typeof saved.fieldCollapsed==="boolean"){
    state.fieldCollapsed=saved.fieldCollapsed;
  }

  if(typeof saved.colorCollapsed==="boolean"){
    state.colorCollapsed=saved.colorCollapsed;
  }

  if(state.fieldCollapsed && state.colorCollapsed){
    state.colorCollapsed=false;
  }

  if(Number.isFinite(Number(saved.wheelSize))){
    state.wheelSize=clamp(Number(saved.wheelSize),55,100);
  }

  if(Number.isFinite(Number(saved.ringWidth))){
    state.ringWidth=clamp(Number(saved.ringWidth),6,32);
  }

  if(typeof saved.qualityPreset==="string"){
    state.qualityPreset=saved.qualityPreset;
  }

  state.locked=!!saved.locked;

  if(saved.anchorRgb &&
     Number.isFinite(Number(saved.anchorRgb.r)) &&
     Number.isFinite(Number(saved.anchorRgb.g)) &&
     Number.isFinite(Number(saved.anchorRgb.b))){

    state.anchorRgb={
      r:clamp(Math.round(Number(saved.anchorRgb.r)),0,255),
      g:clamp(Math.round(Number(saved.anchorRgb.g)),0,255),
      b:clamp(Math.round(Number(saved.anchorRgb.b)),0,255)
    };

    state.anchorLch=rgbToLch(
      state.anchorRgb.r,
      state.anchorRgb.g,
      state.anchorRgb.b
    );

    if(Number.isFinite(Number(saved.anchorChromaFraction))){
      state.anchorChromaFraction=clamp(
        Number(saved.anchorChromaFraction),
        0,
        1
      );
    }else{
      state.anchorChromaFraction=
        computeAvailableChromaFraction(
          state.anchorRgb,
          state.anchorLch
        );
    }
  }

  if(!state.locked){
    state.anchorRgb=null;
    state.anchorLch=null;
    state.anchorChromaFraction=null;
  }

  applyWheelUiScale(state.uiScale);
  applyWheelAdvancedState(state.advancedOpen);
  applySectionCollapseState(state.fieldCollapsed,state.colorCollapsed);

  bindNumberInput("chromaMinInput",{
    min:0,max:100,step:1,
    get:()=>state.chromaMin,
    set:v=>{
      // Delta toward lower Chroma; independent from C Max.
      state.chromaMin=v;
      saveWheelUiState();
    }
  });

  bindNumberInput("chromaMaxInput",{
    min:0,max:100,step:1,
    get:()=>state.chromaMax,
    set:v=>{
      // Delta toward higher Chroma; independent from C Min.
      state.chromaMax=v;
      saveWheelUiState();
    }
  });

  bindNumberInput("transitionInput",{
    min:5,max:100,step:1,
    get:()=>state.transition,
    set:v=>{
      state.transition=v;
      saveWheelUiState();
    }
  });

  bindNumberInput("huesInput",{
    min:3,max:72,step:1,
    get:()=>state.hues,
    set:v=>{
      state.hues=v;
      syncQualityPresetFromValues();
      saveWheelUiState();
    }
  });

  bindNumberInput("heightInput",{
    min:140,max:420,step:1,
    get:()=>state.height,
    set:v=>{
      state.height=v;
      $("wheelWrap").style.height=v+"px";
      saveWheelUiState();
    }
  });

  bindNumberInput("wheelSizeInput",{
    min:55,max:100,step:1,
    get:()=>state.wheelSize,
    set:v=>{
      state.wheelSize=v;
      saveWheelUiState();
    }
  });

  bindNumberInput("ringWidthInput",{
    min:6,max:32,step:1,
    get:()=>state.ringWidth,
    set:v=>{
      state.ringWidth=v;
      saveWheelUiState();
    }
  });

  bindNumberInput("uiScaleInput",{
    min:70,max:150,step:5,
    get:()=>state.uiScale,
    set:v=>{
      applyWheelUiScale(v);
      saveWheelUiState();
      setTimeout(function(){ invalidateWheelCaches(); scheduleWheelDraw(true); },0);
    }
  });
}

/* ------------------------------------------------------------
   Init
------------------------------------------------------------ */

function init(){
  setupControls();
  setupQualityPreset();
  setupWheelAdvancedToggle();
  setupWheelLock();
  setupSectionToggles();

  $("wheelWrap").style.height=state.height+"px";

  setupColorSliders();

  $("wheelCanvas").addEventListener(
    "pointerdown",
    beginDrag
  );

  window.addEventListener(
    "resize",
    function(){
      invalidateWheelCaches();
      scheduleWheelDraw(true);
      scheduleResponsiveDensity();
    }
  );

  // Yield CEP mouse/pen focus only when the pointer actually exits the panel.
  let lastYield=0;

  function panelLeave(){
    const now=Date.now();

    if(now-lastYield<40)return;

    lastYield=now;
    yieldFocusToPhotoshop();
  }

  document.documentElement.addEventListener(
    "pointerleave",
    panelLeave,
    false
  );

  document.documentElement.addEventListener(
    "mouseleave",
    panelLeave,
    false
  );

  drawWheel(true);
  scheduleResponsiveDensity();

  setInterval(
    ()=>readPhotoshopColor(false),
    80
  );

  setTimeout(
    ()=>readPhotoshopColor(true),
    180
  );
}

init();

})();
