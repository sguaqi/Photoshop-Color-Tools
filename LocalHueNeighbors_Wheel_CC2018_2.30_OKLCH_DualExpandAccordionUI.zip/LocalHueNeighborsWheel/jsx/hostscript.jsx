
function LHN_getForegroundRGB() {
    try {
        var c = app.foregroundColor.rgb;
        return JSON.stringify({
            ok: true,
            r: Math.round(c.red),
            g: Math.round(c.green),
            b: Math.round(c.blue)
        });
    } catch (e) {
        return JSON.stringify({ok:false, error:e.toString()});
    }
}

function LHN_setForegroundRGB(r, g, b) {
    try {
        var c = new SolidColor();
        c.rgb.red = Number(r);
        c.rgb.green = Number(g);
        c.rgb.blue = Number(b);
        app.foregroundColor = c;
        return "OK";
    } catch (e) {
        return "ERROR:" + e.toString();
    }
}
