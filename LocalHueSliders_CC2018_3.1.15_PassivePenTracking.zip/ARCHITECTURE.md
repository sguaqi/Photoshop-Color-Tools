# v3.1.15 architecture

## Input ownership

The visible HUD is WPF but display-only; WPF Stylus/Touch support is disabled before PresentationCore loads. Each module has a tiny transparent Win32 no-activate input sink for initial mouse-compatible button hits.

Unlike v3.1.14, the HUD never calls `SetCapture`. On a left-button down the native sink installs a temporary `WH_MOUSE_LL` observer. The observer only copies move/up screen coordinates into the HUD queue and immediately forwards the event with `CallNextHookEx`. This lets the HUD follow a pen outside its own HWND without taking input ownership away from Photoshop. On left-button up the observer unhooks. If hook setup fails, that press is marked non-native and uses the older cursor polling fallback.

## Drag rendering

Active drag ticks run at 5 ms maximum and coalesce multiple native move events to the latest point. The marker itself moves through `TranslateTransform` so the hot path avoids WPF layout. Idle input returns to 16 ms.

## State / color bridge

The v3.1.12 cache-first state pipeline remains unchanged: cheap keys are checked before expensive OKLCH bar generation, module image/brush resources are reused, and Photoshop/state/lifecycle timers stay separated by responsibility.
