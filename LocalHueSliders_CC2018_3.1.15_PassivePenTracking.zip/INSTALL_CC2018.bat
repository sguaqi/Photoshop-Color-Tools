@echo off
setlocal
set "SRC=%~dp0"
set "DST=%APPDATA%\Adobe\CEP\extensions\LocalHueSliders"
echo.
echo Installing Local Hue Sliders v3.1.15 Background Host build...
echo Please CLOSE Photoshop before continuing.
echo.
pause
echo.
echo Closing any stale Local Hue HUD process from an older build...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SRC%overlay\CleanupOverlay.ps1" >nul 2>&1
mkdir "%APPDATA%\Adobe\CEP\extensions" 2>nul
if exist "%DST%" rmdir /S /Q "%DST%"
mkdir "%DST%"
xcopy "%SRC%*" "%DST%\" /E /I /Y >nul
reg add "HKCU\Software\Adobe\CSXS.8" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo.
echo Installed.
echo The invisible CEP background host and transparent HUD start with Photoshop.
echo The Control Center no longer needs to stay open.
echo Open it only when needed from:
echo Window ^> Extensions ^> Local Hue Sliders Control Center
echo.
pause
