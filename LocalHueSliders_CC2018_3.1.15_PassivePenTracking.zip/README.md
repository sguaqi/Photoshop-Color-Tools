# Local Hue Sliders v3.1.15 — Passive Pen Tracking HUD

This build keeps all v3.1.12 performance work and the v3.1.13 high-refresh marker path, but removes the v3.1.14 Win32 `SetCapture` drag ownership.

## v3.1.15 Pen pressure + outside-HUD drag

- Visible WPF HUD windows remain display-only. WPF Stylus/Touch support stays disabled, so WPF does not open a competing tablet context.
- The tiny native no-activate input sinks still detect the initial mouse/pen-compatible button down over each HUD module.
- During the active left-button drag, a temporary `WH_MOUSE_LL` observer reads screen-space move/up coordinates globally. It never captures the pointer, never changes focus, and always calls `CallNextHookEx`, so Photoshop keeps normal ownership of its Windows Ink / WinTab input path.
- The observer exists only for the active press and is removed on button-up. If hook installation fails, the HUD automatically falls back to the v3.1.13 `GetCursorPos`/`GetAsyncKeyState` polling path instead of breaking drag behavior.
- Move events are coalesced on the existing 5 ms active-drag HUD tick; idle input polling returns to 16 ms.

## Performance retained from v3.1.12 / v3.1.13

- State/color bars are only rebuilt when their effective inputs change.
- Custom harmony anchors are prepared once per bar generation rather than per sample.
- OKLCH gamut mapping reuses hue trigonometry during binary search.
- WPF color bitmaps/brushes are reused instead of recreated every refresh.
- Marker motion uses compositor `RenderTransform` rather than layout-triggering `Canvas.Left`.
- Photoshop color polling, CEP state publishing, HUD commands, and host-follow timers remain decoupled.

## Compatibility note

Internal bridge/prefs/mutex names intentionally remain on their established compatibility names so upgrades keep the existing layout/settings and do not launch duplicate HUD instances.

CC2018-compatible CEP + Windows PowerShell 5.1 / .NET WPF; no external runtime required.
