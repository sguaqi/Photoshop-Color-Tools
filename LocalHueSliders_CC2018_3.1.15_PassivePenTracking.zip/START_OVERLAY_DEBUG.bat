@echo off
cd /d "%~dp0"
echo Local Hue Sliders v3.1.15 Overlay debug launcher
echo Keep Photoshop and the CEP Control Center open first.
echo.
set "LHS_OVERLAY_DEBUG=1"
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0overlay\LocalHueOverlay.ps1"
echo.
echo Overlay process ended. If an error is shown above, send a screenshot of it.
pause
