(function(){
"use strict";

var $=function(id){return document.getElementById(id);};
var panel=document.querySelector('.panel');
var STORAGE_KEY='LocalHueSliders.ui.v13';
var LEGACY_STORAGE_KEY='LocalHueSliders.ui.v12';
var EXTENSION_ID='com.openai.localhuesliders.panel';
try{if(window.__adobe_cep__&&typeof window.__adobe_cep__.getExtensionId==='function')EXTENSION_ID=String(window.__adobe_cep__.getExtensionId()||EXTENSION_ID);}catch(_ext){}
var IS_BACKGROUND=/\.background$/i.test(EXTENSION_ID);
var applyingRemoteState=false,backgroundSyncTimer=0;

var photoshopReadBusy=false,photoshopReadSince=0,pendingForcedRead=false,internalWrite=false,internalWriteSince=0,draggingZone=null,overlayDraggingZone=null,overlayDraggingSince=0,lastPhotoshopRGB=null,suppressSyncUntil=0,initialized=false,uiScale=100,advancedOpen=false,lastDocumentPoll=0;
var currentRGB={r:128,g:128,b:128},currentLCH={L:53.6,C:0,h:0};
var globalStep=.1,globalSnap=true;
var zone1={base:{L:53.6,C:0,h:0},range:30,height:42,selectedHue:0};
var zone2={base:{L:53.6,C:0,h:0},height:42,t:.5,mode:'Analogous',includeCenter:true,customAnchors:[
  {id:'ca1',pos:.4167,degree:-30},{id:'ca2',pos:.5833,degree:30}
],nextCustomIndex:3};
var zone3={hue:0,height:42,t:.5,leftC:6,leftL:18,rightC:24,rightL:88};
var zone4={base:{L:53.6,C:0,h:0},height:42,t:.5,range:45,edgeC:25};
var zone5={history:[],pinnedByDoc:{},legacyPinned:[],historyMax:16,pinnedMax:24,currentDocKey:'__none__',currentDocId:null,currentDocName:'No document'};
var renderKeys={z1:'',z2:'',z3:'',z4:''};
var overlaySampleCache={};
var modeIds=['Analogous','Complement','Split','Triad','Square','Hexadic','Custom'];
var MODULE_IDS=['hue','harmony','tone','hc','store'];
var layoutState={order:MODULE_IDS.slice(),hidden:{hue:false,harmony:false,tone:false,hc:false,store:false}};
var layoutDrag=null;
var PRESETS={
  Analogous:{range:30,offsets:[-30,30],summary:'Analogous · ±30°'},
  Complement:{range:180,offsets:[180],summary:'Complement · 180°'},
  Split:{range:150,offsets:[-150,150],summary:'Split comp. · ±150°'},
  Triad:{range:120,offsets:[-120,120],summary:'Triad · ±120°'},
  Square:{range:180,offsets:[-90,90,180],summary:'Square · ±90° + 180°'},
  Hexadic:{range:180,offsets:[-120,-60,60,120,180],summary:'Hexadic · ±60° , ±120°'}
};

function clamp(v,lo,hi){return Math.max(lo,Math.min(hi,v));}
function wrapHue(h){h%=360;if(h<0)h+=360;return h;}
function angularDiff(a,b){var d=wrapHue(a)-wrapHue(b);if(d>180)d-=360;if(d<-180)d+=360;return d;}
function lerp(a,b,t){return a+(b-a)*t;}
function formatNum(v){return Math.abs(v-Math.round(v))<1e-8?String(Math.round(v)):Number(v).toFixed(1);}
function copyLCH(c){return {L:c.L,C:c.C,h:c.h};}
function hasCEP(){return !!(window.__adobe_cep__&&typeof window.__adobe_cep__.evalScript==='function');}
function evalScript(script,cb){if(!hasCEP()){if(cb)cb('NO_CEP');return;}try{window.__adobe_cep__.evalScript(script,function(r){if(cb)cb(r);});}catch(e){if(cb)cb('ERR:'+e.message);}}
function yieldFocus(){try{if(window.__adobe_cep__&&window.__adobe_cep__.dispatchEvent){window.__adobe_cep__.dispatchEvent({type:'com.adobe.PhotoshopLoseFocus',scope:'APPLICATION',appId:'PHXS',extensionId:EXTENSION_ID,data:''});}}catch(_){} }
document.documentElement.addEventListener('pointerleave',yieldFocus,false);document.documentElement.addEventListener('mouseleave',yieldFocus,false);
function backendTransportReady(){try{return !IS_BACKGROUND&&window.LocalHueTransport&&typeof window.LocalHueTransport.sendCommand==='function'&&(!window.LocalHueTransport.backendAlive||window.LocalHueTransport.backendAlive());}catch(_){return false;}}
function requestBackgroundStateSync(){if(IS_BACKGROUND||applyingRemoteState)return;if(backgroundSyncTimer)clearTimeout(backgroundSyncTimer);backgroundSyncTimer=setTimeout(function(){backgroundSyncTimer=0;try{if(window.LocalHueTransport&&typeof window.LocalHueTransport.sendCoreState==='function')window.LocalHueTransport.sendCoreState(persistedStateObject());}catch(_){}},45);}

function setCanvasHeight(id,h){$(id).style.height=Math.round(h)+'px';}
function previewWidth(canvas){var cssW=Math.max(2,canvas.getBoundingClientRect().width),w=Math.max(2,Math.min(420,Math.round(cssW)));if(canvas.width!==w)canvas.width=w;if(canvas.height!==1)canvas.height=1;return w;}
function setMarker(id,t){$(id).style.left=clamp(t,0,1)*100+'%';}
function eventT(e,canvas){var r=canvas.getBoundingClientRect(),x=clamp(e.clientX-r.left,0,r.width);return r.width?clamp(x/r.width,0,1):.5;}
function quantizedT(t){var step=clamp(globalStep,.1,25)/100;t=clamp(t,0,1);return clamp(Math.round(t/step)*step,0,1);}
function interactionT(t){return globalSnap?quantizedT(t):clamp(t,0,1);}
function offsetToT(offset,range){return clamp((offset+range)/(2*range),0,1);}
function tToOffset(t,range){return (clamp(t,0,1)*2-1)*range;}
function degreeStep(){return 360*(clamp(globalStep,.1,25)/100);}
function quantizeDegree(d){if(!globalSnap)return clamp(d,-180,180);var s=degreeStep();return clamp(Math.round(d/s)*s,-180,180);}
function getCustomAnchor(id){for(var i=0;i<zone2.customAnchors.length;i++)if(zone2.customAnchors[i].id===id)return zone2.customAnchors[i];return null;}
function sortedCustomAnchors(){return zone2.customAnchors.slice().sort(function(a,b){return a.pos-b.pos;});}

function srgbToLinear(v){v/=255;return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);}
function linearToSrgb(v){v=v<=.0031308?12.92*v:1.055*Math.pow(v,1/2.4)-.055;return 255*v;}
function rgbToLch(r,g,b){var R=srgbToLinear(r),G=srgbToLinear(g),B=srgbToLinear(b),l=.4122214708*R+.5363325363*G+.0514459929*B,m=.2119034982*R+.6806995451*G+.1073969566*B,s=.0883024619*R+.2817188376*G+.6299787005*B,ll=Math.cbrt(l),mm=Math.cbrt(m),ss=Math.cbrt(s),L=.2104542553*ll+.7936177850*mm-.0040720468*ss,a=1.9779984951*ll-2.4285922050*mm+.4505937099*ss,bb=.0259040371*ll+.7827717662*mm-.8086757660*ss,C=Math.sqrt(a*a+bb*bb),h=Math.atan2(bb,a)*180/Math.PI;if(h<0)h+=360;return {L:L*100,C:C*100,h:h};}
function oklchToRawRgbPrepared(L100,C100,cosH,sinH){var L=L100/100,C=C100/100,a=C*cosH,b=C*sinH,ll=L+.3963377774*a+.2158037573*b,mm=L-.1055613458*a-.0638541728*b,ss=L-.0894841775*a-1.2914855480*b,l=ll*ll*ll,m=mm*mm*mm,s=ss*ss*ss,R=4.0767416621*l-3.3077115913*m+.2309699292*s,G=-1.2684380046*l+2.6097574011*m-.3413193965*s,B=-.0041960863*l-.7034186147*m+1.7076147010*s;return {r:linearToSrgb(R),g:linearToSrgb(G),b:linearToSrgb(B)};}
function oklchToRawRgb(L100,C100,h){var rad=wrapHue(h)*Math.PI/180;return oklchToRawRgbPrepared(L100,C100,Math.cos(rad),Math.sin(rad));}
function inGamut(c){return isFinite(c.r)&&isFinite(c.g)&&isFinite(c.b)&&c.r>=0&&c.r<=255&&c.g>=0&&c.g<=255&&c.b>=0&&c.b<=255;}
function lchToRgbCore(L,C,h,iters){L=clamp(L,0,100);C=Math.max(0,C);h=wrapHue(h);var rad=h*Math.PI/180,cosH=Math.cos(rad),sinH=Math.sin(rad),raw=oklchToRawRgbPrepared(L,C,cosH,sinH);if(inGamut(raw))return {r:Math.round(raw.r),g:Math.round(raw.g),b:Math.round(raw.b)};var low=0,high=C,best=0,i,mid,test;for(i=0;i<iters;i++){mid=(low+high)*.5;test=oklchToRawRgbPrepared(L,mid,cosH,sinH);if(inGamut(test)){best=mid;low=mid;}else high=mid;}raw=oklchToRawRgbPrepared(L,best,cosH,sinH);return {r:Math.round(clamp(raw.r,0,255)),g:Math.round(clamp(raw.g,0,255)),b:Math.round(clamp(raw.b,0,255))};}
function lchToRgb(L,C,h){return lchToRgbCore(L,C,h,16);}function lchToRgbPreview(L,C,h){return lchToRgbCore(L,C,h,8);}

function harmonyRange(){return zone2.mode==='Custom'?180:PRESETS[zone2.mode].range;}
function harmonyOffsets(){if(zone2.mode==='Custom'){var a=sortedCustomAnchors(),out=[];for(var i=0;i<a.length;i++)out.push(clamp(a[i].degree,-180,180));return out;}return PRESETS[zone2.mode].offsets.slice();}
function harmonySummary(){return zone2.mode==='Custom'?'Custom · '+zone2.customAnchors.length+' fixed lines':PRESETS[zone2.mode].summary;}
function colorForOffset(offset){var c={L:zone2.base.L,C:zone2.base.C,h:wrapHue(zone2.base.h+offset)};return lchToRgbPreview(c.L,c.C,c.h);}

function customNodes(){
  var nodes=[{pos:0,degree:-180,fixed:true},{pos:.5,degree:0,fixed:true},{pos:1,degree:180,fixed:true}],a=sortedCustomAnchors();
  for(var i=0;i<a.length;i++)nodes.push({pos:clamp(a[i].pos,.001,.999),degree:clamp(a[i].degree,-180,180),id:a[i].id});
  nodes.sort(function(x,y){if(Math.abs(x.pos-y.pos)>.00001)return x.pos-y.pos;if(x.fixed&&!y.fixed)return 1;if(!x.fixed&&y.fixed)return -1;return 0;});
  return nodes;
}
function customDegreeAt(t,n){
  t=clamp(t,0,1);n=n||customNodes();
  if(t<=n[0].pos)return n[0].degree;
  for(var i=0;i<n.length-1;i++){
    var a=n[i],b=n[i+1];
    if(t<=b.pos){var span=b.pos-a.pos;if(span<.000001)return b.degree;return lerp(a.degree,b.degree,(t-a.pos)/span);}
  }
  return n[n.length-1].degree;
}

function persistedStateObject(){return {scale:uiScale,advanced:advancedOpen,step:globalStep,snap:globalSnap,layout:{order:layoutState.order.slice(),hidden:{hue:!!layoutState.hidden.hue,harmony:!!layoutState.hidden.harmony,tone:!!layoutState.hidden.tone,hc:!!layoutState.hidden.hc,store:!!layoutState.hidden.store}},z1:{range:zone1.range,height:zone1.height},z2:{height:zone2.height,mode:zone2.mode,includeCenter:zone2.includeCenter,customAnchors:zone2.customAnchors,nextCustomIndex:zone2.nextCustomIndex},z3:{height:zone3.height,leftC:zone3.leftC,leftL:zone3.leftL,rightC:zone3.rightC,rightL:zone3.rightL},z4:{height:zone4.height,range:zone4.range,edgeC:zone4.edgeC},z5:{history:zone5.history,pinnedByDoc:zone5.pinnedByDoc}};}
function saveState(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(persistedStateObject()));}catch(_){} }
function saveStateAndSync(){saveState();requestBackgroundStateSync();}
function normalizeRGB(c){return {r:clamp(Math.round(Number(c&&c.r)||0),0,255),g:clamp(Math.round(Number(c&&c.g)||0),0,255),b:clamp(Math.round(Number(c&&c.b)||0),0,255)};}
function rgbKey(c){c=normalizeRGB(c);return c.r+','+c.g+','+c.b;}
function rgbHex(c){c=normalizeRGB(c);function h(v){var x=v.toString(16).toUpperCase();return x.length<2?'0'+x:x;}return '#'+h(c.r)+h(c.g)+h(c.b);}
function loadColorArray(a,max){var out=[],seen={};if(!Array.isArray(a))return out;for(var i=0;i<a.length&&out.length<max;i++){var c=normalizeRGB(a[i]),k=rgbKey(c);if(!seen[k]){seen[k]=true;out.push(c);}}return out;}
function currentPinned(){var key=zone5.currentDocKey||'__none__';if(!zone5.pinnedByDoc[key])zone5.pinnedByDoc[key]=[];return zone5.pinnedByDoc[key];}
function addHistoryColor(c){c=normalizeRGB(c);var k=rgbKey(c),out=[c];for(var i=0;i<zone5.history.length&&out.length<zone5.historyMax;i++){if(rgbKey(zone5.history[i])!==k)out.push(zone5.history[i]);}zone5.history=out;renderColorStores();saveStateAndSync();}
function pinColor(c){if(zone5.currentDocKey==='__none__')return;c=normalizeRGB(c);var arr=currentPinned(),k=rgbKey(c);for(var i=0;i<arr.length;i++)if(rgbKey(arr[i])===k){renderColorStores();return;}arr.unshift(c);if(arr.length>zone5.pinnedMax)arr.length=zone5.pinnedMax;renderColorStores();saveStateAndSync();}
function removePinnedColor(c){var arr=currentPinned(),k=rgbKey(c),out=[];for(var i=0;i<arr.length;i++)if(rgbKey(arr[i])!==k)out.push(arr[i]);zone5.pinnedByDoc[zone5.currentDocKey]=out;renderColorStores();saveStateAndSync();}
function makeStoreSwatch(c,isPinned){c=normalizeRGB(c);var b=document.createElement('button');b.type='button';b.className='storeSwatch'+(isPinned?' pinned':'')+(rgbKey(c)===rgbKey(currentRGB)?' current':'');b.style.background='rgb('+c.r+','+c.g+','+c.b+')';b.title=rgbHex(c)+' · RGB '+c.r+', '+c.g+', '+c.b;b.addEventListener('click',function(e){e.preventDefault();setPhotoshopColor(c,isPinned?'pinned':'history');});b.addEventListener('contextmenu',function(e){e.preventDefault();e.stopPropagation();if(isPinned)removePinnedColor(c);else pinColor(c);});return b;}
function renderColorStore(hostId,arr,isPinned){var host=$(hostId);if(!host)return;host.innerHTML='';if(!arr.length){var empty=document.createElement('div');empty.className='emptyStore';empty.textContent=isPinned?'No pinned colors':'No history yet';host.appendChild(empty);return;}for(var i=0;i<arr.length;i++)host.appendChild(makeStoreSwatch(arr[i],isPinned));}
function renderColorStores(){if(IS_BACKGROUND)return;var label=$('pinnedStoreLabel');if(label)label.textContent=zone5.currentDocKey==='__none__'?'Pinned · no document':'Pinned · '+zone5.currentDocName;renderColorStore('historySwatches',zone5.history,false);renderColorStore('pinnedSwatches',zone5.currentDocKey==='__none__'?[]:currentPinned(),true);}

function migrateCustomAnchor(a,i){
  if(!a)return null;
  var id=a.id||('ca'+(i+1));
  if(isFinite(Number(a.pos))&&isFinite(Number(a.degree)))return {id:id,pos:clamp(Number(a.pos),.001,.999),degree:clamp(Number(a.degree),-180,180)};
  var oldOffset=isFinite(Number(a.offset))?clamp(Number(a.offset),-180,180):0;
  return {id:id,pos:offsetToT(oldOffset,180),degree:oldOffset};
}
function applyPersistedState(s,refreshUI){
  if(!s||typeof s!=='object')return false;
  try{
    if(isFinite(Number(s.scale)))uiScale=clamp(Number(s.scale),70,150);
    if(typeof s.advanced==='boolean')advancedOpen=s.advanced;
    if(isFinite(Number(s.step)))globalStep=clamp(Number(s.step),.1,25);
    if(typeof s.snap==='boolean')globalSnap=s.snap;
    if(s.layout){
      if(Array.isArray(s.layout.order)){
        var seen={},order=[];
        for(var oi=0;oi<s.layout.order.length;oi++){var mid=String(s.layout.order[oi]);if(MODULE_IDS.indexOf(mid)>=0&&!seen[mid]){seen[mid]=true;order.push(mid);}}
        for(oi=0;oi<MODULE_IDS.length;oi++)if(!seen[MODULE_IDS[oi]])order.push(MODULE_IDS[oi]);
        layoutState.order=order;
      }
      if(s.layout.hidden&&typeof s.layout.hidden==='object')for(var hi=0;hi<MODULE_IDS.length;hi++){var hm=MODULE_IDS[hi];if(typeof s.layout.hidden[hm]==='boolean')layoutState.hidden[hm]=s.layout.hidden[hm];}
    }
    if(s.z1){if(isFinite(Number(s.z1.range)))zone1.range=clamp(Number(s.z1.range),.1,180);if(isFinite(Number(s.z1.height)))zone1.height=clamp(Number(s.z1.height),24,160);}
    if(s.z2){
      if(isFinite(Number(s.z2.height)))zone2.height=clamp(Number(s.z2.height),24,160);
      if(typeof s.z2.mode==='string'&&modeIds.indexOf(s.z2.mode)>=0)zone2.mode=s.z2.mode;
      if(typeof s.z2.includeCenter==='boolean')zone2.includeCenter=s.z2.includeCenter;
      if(Array.isArray(s.z2.customAnchors)&&s.z2.customAnchors.length){var migrated=[];for(var i=0;i<s.z2.customAnchors.length;i++){var m=migrateCustomAnchor(s.z2.customAnchors[i],i);if(m)migrated.push(m);}if(migrated.length)zone2.customAnchors=migrated;}
      if(isFinite(Number(s.z2.nextCustomIndex)))zone2.nextCustomIndex=Math.max(1,Math.round(Number(s.z2.nextCustomIndex)));
    }
    if(s.z3){if(isFinite(Number(s.z3.height)))zone3.height=clamp(Number(s.z3.height),24,160);if(isFinite(Number(s.z3.leftC)))zone3.leftC=clamp(Number(s.z3.leftC),0,45);if(isFinite(Number(s.z3.leftL)))zone3.leftL=clamp(Number(s.z3.leftL),0,100);if(isFinite(Number(s.z3.rightC)))zone3.rightC=clamp(Number(s.z3.rightC),0,45);if(isFinite(Number(s.z3.rightL)))zone3.rightL=clamp(Number(s.z3.rightL),0,100);}
    if(s.z4){if(isFinite(Number(s.z4.height)))zone4.height=clamp(Number(s.z4.height),24,160);if(isFinite(Number(s.z4.range)))zone4.range=clamp(Number(s.z4.range),.1,180);if(isFinite(Number(s.z4.edgeC)))zone4.edgeC=clamp(Number(s.z4.edgeC),0,100);}
    if(s.z5){
      zone5.history=loadColorArray(s.z5.history,zone5.historyMax);
      if(s.z5.pinnedByDoc&&typeof s.z5.pinnedByDoc==='object'){
        var nextPinned={};for(var dk in s.z5.pinnedByDoc)if(s.z5.pinnedByDoc.hasOwnProperty(dk))nextPinned[dk]=loadColorArray(s.z5.pinnedByDoc[dk],zone5.pinnedMax);zone5.pinnedByDoc=nextPinned;
      }else zone5.legacyPinned=loadColorArray(s.z5.pinned,zone5.pinnedMax);
    }
    if(refreshUI){syncInputsFromState();invalidate();renderAll();fitWindowSoon();}
    return true;
  }catch(_){return false;}
}
function loadState(){try{var s=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');if(!s)s=JSON.parse(localStorage.getItem(LEGACY_STORAGE_KEY)||'null');if(s)applyPersistedState(s,false);}catch(_){} }
function syncInputsFromState(){if(IS_BACKGROUND)return;$('uiScaleInput').value=uiScale;$('globalStepSlider').value=globalStep;$('globalStepValue').textContent=formatNum(globalStep)+'%';$('globalSnap').checked=globalSnap;$('hueRangeInput').value=formatNum(zone1.range);$('hueHeightInput').value=Math.round(zone1.height);$('anchorHeightInput').value=Math.round(zone2.height);$('anchorIncludeCenter').checked=zone2.includeCenter;$('toneHeightInput').value=Math.round(zone3.height);$('toneLeftC').value=formatNum(zone3.leftC);$('toneLeftL').value=formatNum(zone3.leftL);$('toneRightC').value=formatNum(zone3.rightC);$('toneRightL').value=formatNum(zone3.rightL);$('hcHeightInput').value=Math.round(zone4.height);$('hcRangeInput').value=formatNum(zone4.range);$('hcEdgeCInput').value=formatNum(zone4.edgeC);panel.style.zoom=uiScale/100;panel.classList.toggle('advancedOpen',advancedOpen);$('advancedToggle').setAttribute('aria-expanded',advancedOpen?'true':'false');$('settingsOverlay').setAttribute('aria-hidden',advancedOpen?'false':'true');setCanvasHeight('hueCanvas',zone1.height);setCanvasHeight('anchorCanvas',zone2.height);setCanvasHeight('toneCanvas',zone3.height);setCanvasHeight('hcCanvas',zone4.height);applyLayoutState();syncVisibilityControls();updateHarmonyUI();}


function moduleElement(id){return $('module-'+id);}
function currentDomOrder(){var stack=$('moduleStack'),out=[];if(!stack)return layoutState.order.slice();var kids=stack.children;for(var i=0;i<kids.length;i++){var id=kids[i].getAttribute('data-module');if(id&&MODULE_IDS.indexOf(id)>=0)out.push(id);}return out;}
function applyLayoutState(){var stack=$('moduleStack');if(!stack)return;for(var i=0;i<layoutState.order.length;i++){var el=moduleElement(layoutState.order[i]);if(el)stack.appendChild(el);}for(i=0;i<MODULE_IDS.length;i++){var id=MODULE_IDS[i],m=moduleElement(id);if(m)m.classList.toggle('moduleHidden',!!layoutState.hidden[id]);}}
function syncVisibilityControls(){var map={hue:'showHueModule',harmony:'showHarmonyModule',tone:'showToneModule',hc:'showHCModule',store:'showStoreModule'};for(var id in map)if(map.hasOwnProperty(id)&&$(map[id]))$(map[id]).checked=!layoutState.hidden[id];}
function setModuleVisible(id,visible){if(MODULE_IDS.indexOf(id)<0)return;layoutState.hidden[id]=!visible;applyLayoutState();syncVisibilityControls();saveStateAndSync();invalidate();renderAll();fitWindowSoon();}
function resetModuleLayout(){layoutState.order=MODULE_IDS.slice();applyLayoutState();saveStateAndSync();fitWindowSoon();}
function showAllModules(){for(var i=0;i<MODULE_IDS.length;i++)layoutState.hidden[MODULE_IDS[i]]=false;applyLayoutState();syncVisibilityControls();saveStateAndSync();invalidate();renderAll();fitWindowSoon();}
function fitWindowSoon(){setTimeout(function(){try{if(!window.__adobe_cep__||typeof window.__adobe_cep__.resizeContent!=='function')return;var stack=$('moduleStack'),toolbar=document.querySelector('.miniToolbar'),h=(toolbar?toolbar.offsetHeight:28)+(stack?stack.scrollHeight:200)+14;h=clamp(Math.ceil(h),130,760);var w=clamp(Math.ceil(document.body.clientWidth||360),285,760);window.__adobe_cep__.resizeContent(w,h);}catch(_){}},30);}
function findModuleFromNode(node){while(node&&node!==document){if(node.classList&&node.classList.contains('toolModule'))return node;node=node.parentNode;}return null;}
function bindModuleDragging(){var grips=document.querySelectorAll('.moduleGrip');for(var i=0;i<grips.length;i++)(function(grip){grip.addEventListener('pointerdown',function(e){if(e.isPrimary===false)return;var mod=findModuleFromNode(grip);if(!mod)return;layoutDrag={module:mod,pid:e.pointerId};mod.classList.add('moduleDragging');draggingZone='layout';function move(ev){if(!layoutDrag||ev.pointerId!==layoutDrag.pid)return;var stack=$('moduleStack'),kids=stack.children,target=null;for(var k=0;k<kids.length;k++){var candidate=kids[k];if(candidate===mod||candidate.classList.contains('moduleHidden'))continue;var r=candidate.getBoundingClientRect();if(ev.clientY<r.top+r.height/2){target=candidate;break;}}if(target)stack.insertBefore(mod,target);else stack.appendChild(mod);ev.preventDefault();}function clean(){document.removeEventListener('pointermove',move,true);document.removeEventListener('pointerup',up,true);document.removeEventListener('pointercancel',cancel,true);mod.classList.remove('moduleDragging');}function up(ev){if(!layoutDrag||ev.pointerId!==layoutDrag.pid)return;layoutState.order=currentDomOrder();layoutDrag=null;draggingZone=null;clean();saveStateAndSync();fitWindowSoon();ev.preventDefault();}function cancel(ev){if(!layoutDrag||ev.pointerId!==layoutDrag.pid)return;layoutDrag=null;draggingZone=null;clean();applyLayoutState();}document.addEventListener('pointermove',move,true);document.addEventListener('pointerup',up,true);document.addEventListener('pointercancel',cancel,true);e.preventDefault();e.stopPropagation();});})(grips[i]);}
function renderStrip(id,keyName,colorAt,keyParts){var canvas=$(id),w=previewWidth(canvas),key=[w].concat(keyParts).join('|');if(renderKeys[keyName]===key)return;renderKeys[keyName]=key;var ctx=canvas.getContext('2d'),img=ctx.createImageData(w,1),data=img.data,p=0;for(var x=0;x<w;x++){var t=w<=1?.5:x/(w-1),c=colorAt(t),rgb=lchToRgbPreview(c.L,c.C,c.h);data[p++]=rgb.r;data[p++]=rgb.g;data[p++]=rgb.b;data[p++]=255;}ctx.putImageData(img,0,0);}
function toneAt(t,q){if(q)t=interactionT(t);return {L:lerp(zone3.leftL,zone3.rightL,t),C:lerp(zone3.leftC,zone3.rightC,t),h:zone3.hue};}
function projectToneT(lch){var dL=zone3.rightL-zone3.leftL,dC=(zone3.rightC-zone3.leftC)*2.5,pL=lch.L-zone3.leftL,pC=(lch.C-zone3.leftC)*2.5,den=dL*dL+dC*dC;return den?clamp((pL*dL+pC*dC)/den,0,1):.5;}
function syncToneMarkerFromCurrent(){if(!currentLCH||!isFinite(currentLCH.L)||!isFinite(currentLCH.C))return;zone3.t=interactionT(projectToneT(currentLCH));}
function hueChromaAt(t){var u=clamp(t,0,1)*2-1,abs=Math.abs(u),edge=clamp(zone4.edgeC,0,100)/100;return {L:zone4.base.L,C:zone4.base.C*lerp(1,edge,abs),h:wrapHue(zone4.base.h+u*zone4.range)};}

function renderZone1(){if(IS_BACKGROUND)return;renderStrip('hueCanvas','z1',function(t){t=interactionT(t);return {L:zone1.base.L,C:zone1.base.C,h:wrapHue(zone1.base.h+(t*2-1)*zone1.range)};},[zone1.base.L.toFixed(3),zone1.base.C.toFixed(3),zone1.base.h.toFixed(3),zone1.range,globalStep]);var d=clamp(angularDiff(zone1.selectedHue,zone1.base.h),-zone1.range,zone1.range);setMarker('hueMarker',(d+zone1.range)/(2*zone1.range));}
function renderZone2Canvas(){
  if(zone2.mode==='Custom'){
    var nodes=customNodes();renderStrip('anchorCanvas','z2',function(t){t=interactionT(t);var deg=customDegreeAt(t,nodes);return {L:zone2.base.L,C:zone2.base.C,h:wrapHue(zone2.base.h+deg)};},[zone2.base.L.toFixed(3),zone2.base.C.toFixed(3),zone2.base.h.toFixed(3),zone2.mode,JSON.stringify(zone2.customAnchors),globalStep]);
  }else{
    var range=harmonyRange();renderStrip('anchorCanvas','z2',function(t){t=interactionT(t);return {L:zone2.base.L,C:zone2.base.C,h:wrapHue(zone2.base.h+tToOffset(t,range))};},[zone2.base.L.toFixed(3),zone2.base.C.toFixed(3),zone2.base.h.toFixed(3),zone2.mode,range,globalStep]);
  }
}
function renderZone2(){if(IS_BACKGROUND)return;renderZone2Canvas();setMarker('anchorMarker',zone2.t);updateAnchorTicks();updateHarmonyUI();updateAnchorLines();updateAnchorSwatches();}
function renderZone3(){if(IS_BACKGROUND)return;renderStrip('toneCanvas','z3',function(t){return toneAt(t,true);},[zone3.hue,globalStep,zone3.leftC,zone3.leftL,zone3.rightC,zone3.rightL]);setMarker('toneMarker',zone3.t);}
function renderZone4(){if(IS_BACKGROUND)return;renderStrip('hcCanvas','z4',function(t){return hueChromaAt(interactionT(t));},[zone4.base.L,zone4.base.C,zone4.base.h,zone4.range,zone4.edgeC,globalStep]);setMarker('hcMarker',zone4.t);}
function renderAll(){if(IS_BACKGROUND)return;renderZone1();renderZone2();renderZone3();renderZone4();renderColorStores();}
function invalidate(z){if(z)renderKeys[z]='';else renderKeys={z1:'',z2:'',z3:'',z4:''};}

function updateHarmonyUI(){var buttons=document.querySelectorAll('.modeButton');for(var i=0;i<buttons.length;i++)buttons[i].classList.toggle('active',buttons[i].getAttribute('data-mode')===zone2.mode);$('anchorModeSummary').textContent=harmonySummary();$('customHelpPill').classList.toggle('visible',zone2.mode==='Custom');$('customEditHint').textContent=zone2.mode==='Custom'?'White line = selected color · drag colored lines to change degree':'White line = selected color · relation lines are locked';}
function updateAnchorTicks(){var host=$('anchorTicks');host.innerHTML='';function add(left,cls){var s=document.createElement('span');s.className='anchorTick'+(cls?' '+cls:'');s.style.left=left+'%';host.appendChild(s);}if(zone2.mode==='Custom'){add(50,'center');return;}var range=harmonyRange();for(var d=-range;d<=range+.001;d+=30){var cls='';if(Math.abs(d)<.001)cls='center';else if(Math.round(Math.abs(d))%90===0)cls='primary';add(offsetToT(d,range)*100,cls);}}
function placePresetLine(el,offset,range){var t=offsetToT(offset,range);el.style.left=(t*100)+'%';el.classList.toggle('edgeLeft',t<=.001);el.classList.toggle('edgeRight',t>=.999);var rgb=colorForOffset(offset);el.style.background='rgb('+rgb.r+','+rgb.g+','+rgb.b+')';el.title=(offset>=0?'+':'')+formatNum(offset)+'°';}
function placeCustomLine(el,a){var t=clamp(a.pos,0,1);el.style.left=(t*100)+'%';el.classList.toggle('edgeLeft',t<=.001);el.classList.toggle('edgeRight',t>=.999);var rgb=colorForOffset(a.degree);el.style.background='rgb('+rgb.r+','+rgb.g+','+rgb.b+')';el.title='Position '+Math.round(t*100)+'% · '+(a.degree>=0?'+':'')+formatNum(a.degree)+'°';}
function updateAnchorLines(){var host=$('anchorHandles');host.innerHTML='';if(zone2.mode==='Custom'){var list=sortedCustomAnchors();for(var i=0;i<list.length;i++)(function(a){var el=document.createElement('div');el.className='anchorLine custom';el.dataset.anchorId=a.id;placeCustomLine(el,a);bindCustomLine(el,a.id);host.appendChild(el);})(list[i]);}else{var range=harmonyRange(),offsets=harmonyOffsets();for(var j=0;j<offsets.length;j++){var el2=document.createElement('div');el2.className='anchorLine';placePresetLine(el2,offsets[j],range);host.appendChild(el2);}}}
function bindCustomLine(el,id){
  el.addEventListener('pointerdown',function(e){if(e.button===2||e.isPrimary===false)return;e.preventDefault();e.stopPropagation();var a=getCustomAnchor(id);if(!a)return;draggingZone='anchorLine';el.classList.add('dragging');var pid=e.pointerId,canvas=$('anchorCanvas'),r=canvas.getBoundingClientRect(),startX=e.clientX,startDegree=a.degree;
    function move(ev){if(ev.pointerId!==pid||draggingZone!=='anchorLine')return;var anchor=getCustomAnchor(id);if(!anchor)return;var dx=ev.clientX-startX,newDegree=startDegree+(r.width?dx/r.width*360:0);anchor.degree=quantizeDegree(newDegree);placeCustomLine(el,anchor);invalidate('z2');renderZone2Canvas();updateAnchorSwatches();ev.preventDefault();}
    function clean(){el.classList.remove('dragging');document.removeEventListener('pointermove',move,true);document.removeEventListener('pointerup',up,true);document.removeEventListener('pointercancel',cancel,true);}
    function up(ev){if(ev.pointerId!==pid)return;draggingZone=null;clean();saveStateAndSync();renderZone2();ev.preventDefault();}
    function cancel(ev){if(ev.pointerId!==pid)return;draggingZone=null;clean();renderZone2();}
    document.addEventListener('pointermove',move,true);document.addEventListener('pointerup',up,true);document.addEventListener('pointercancel',cancel,true);
  });
  el.addEventListener('contextmenu',function(e){e.preventDefault();e.stopPropagation();if(zone2.customAnchors.length<=1)return;zone2.customAnchors=zone2.customAnchors.filter(function(a){return a.id!==id;});saveStateAndSync();invalidate('z2');renderZone2();});
}
function swatchItems(){var items=[];if(zone2.includeCenter)items.push({label:'Center',degree:0,pos:.5});if(zone2.mode==='Custom'){var list=sortedCustomAnchors();for(var i=0;i<list.length;i++)items.push({label:(list[i].degree>=0?'+':'')+formatNum(list[i].degree)+'°',degree:list[i].degree,pos:list[i].pos});}else{var range=harmonyRange(),offsets=harmonyOffsets();for(var j=0;j<offsets.length;j++)items.push({label:(offsets[j]>=0?'+':'')+formatNum(offsets[j])+'°',degree:offsets[j],pos:offsetToT(offsets[j],range)});}return items;}
function updateAnchorSwatches(){var host=$('anchorSwatches');host.innerHTML='';var items=swatchItems();for(var i=0;i<items.length;i++)(function(item){var rgb=colorForOffset(item.degree),btn=document.createElement('button');btn.type='button';btn.className='anchorSwatch'+(Math.abs(item.pos-zone2.t)<.0001?' active':'');btn.innerHTML='<span class="anchorSwatchColor"></span><span class="anchorSwatchLabel">'+item.label+'</span>';btn.querySelector('.anchorSwatchColor').style.background='rgb('+rgb.r+','+rgb.g+','+rgb.b+')';btn.addEventListener('click',function(){zone2.t=item.pos;renderZone2();var c={L:zone2.base.L,C:zone2.base.C,h:wrapHue(zone2.base.h+item.degree)};setPhotoshopColor(lchToRgb(c.L,c.C,c.h),'anchor');});host.appendChild(btn);})(items[i]);}
function addCustomAnchorAt(clientX){var canvas=$('anchorCanvas'),r=canvas.getBoundingClientRect(),pos=interactionT(clamp((clientX-r.left)/r.width,0,1));if(pos<.012||pos>.988||Math.abs(pos-.5)<.012)return;var list=zone2.customAnchors;for(var i=0;i<list.length;i++)if(Math.abs(list[i].pos-pos)<.012)return;var degree=customDegreeAt(pos),id='ca'+(zone2.nextCustomIndex++);zone2.customAnchors.push({id:id,pos:pos,degree:degree});saveStateAndSync();invalidate('z2');renderZone2();}
function addCustomAnchorAtT(pos){pos=interactionT(clamp(Number(pos),0,1));if(pos<.012||pos>.988||Math.abs(pos-.5)<.012)return false;var list=zone2.customAnchors;for(var i=0;i<list.length;i++)if(Math.abs(list[i].pos-pos)<.012)return false;var degree=customDegreeAt(pos),id='ca'+(zone2.nextCustomIndex++);zone2.customAnchors.push({id:id,pos:pos,degree:degree});saveState();invalidate('z2');renderZone2();return true;}

function sanitizeDocKey(s){return String(s||'').replace(/\\/g,'/').toLowerCase();}
function switchDocumentIdentity(docId,docKey,docName){docId=String(docId||'');docKey=String(docKey||'__none__');docName=String(docName||'Untitled');if(docKey==='')docKey='__none__';var oldKey=zone5.currentDocKey,oldId=zone5.currentDocId;if(oldKey===docKey&&String(oldId||'')===docId){zone5.currentDocName=docName;return;}if(oldKey&&oldKey!=='__none__'&&oldId&&docId&&String(oldId)===docId&&docKey!==oldKey&&zone5.pinnedByDoc[oldKey]&&!zone5.pinnedByDoc[docKey]){zone5.pinnedByDoc[docKey]=zone5.pinnedByDoc[oldKey];delete zone5.pinnedByDoc[oldKey];}zone5.currentDocKey=docKey;zone5.currentDocId=docId||null;zone5.currentDocName=docName;if(docKey!=='__none__'&&!zone5.pinnedByDoc[docKey])zone5.pinnedByDoc[docKey]=[];if(docKey!=='__none__'&&zone5.legacyPinned.length&&!zone5.pinnedByDoc[docKey].length){zone5.pinnedByDoc[docKey]=zone5.legacyPinned.slice(0,zone5.pinnedMax);zone5.legacyPinned=[];}renderColorStores();saveStateAndSync();}
function readPhotoshopDocumentIdentity(){var script='try {if(!app.documents.length){"NO_DOC";}else{var d=app.activeDocument;var id="";try{var ref=new ActionReference();ref.putProperty(charIDToTypeID("Prpr"),stringIDToTypeID("documentID"));ref.putEnumerated(charIDToTypeID("Dcmn"),charIDToTypeID("Ordn"),charIDToTypeID("Trgt"));id=executeActionGet(ref).getInteger(stringIDToTypeID("documentID"));}catch(_){id=d.name;}var key="";try{key="path:"+d.fullName.fsName;}catch(_2){key="unsaved:"+id;}String(id)+"\n"+key+"\n"+d.name;}}catch(e){"NO_DOC";}';evalScript(script,function(res){if(!res||res==='NO_CEP'||String(res).indexOf('ERR:')===0)return;if(res==='NO_DOC'){switchDocumentIdentity('','__none__','No document');return;}var parts=String(res).split('\n'),id=parts[0]||'',key=sanitizeDocKey(parts[1]||('unsaved:'+id)),name=parts.slice(2).join('\n')||'Untitled';switchDocumentIdentity(id,key,name);});}
function notifyForegroundChanged(c,source){currentRGB={r:c.r,g:c.g,b:c.b};addHistoryColor(currentRGB);currentLCH=rgbToLch(c.r,c.g,c.b);zone1.base=copyLCH(currentLCH);zone1.selectedHue=currentLCH.h;if(source!=='anchor'){zone2.base=copyLCH(currentLCH);zone2.t=.5;}zone3.hue=currentLCH.h;syncToneMarkerFromCurrent();if(source==='hc'){zone4.base.h=currentLCH.h;}else{zone4.base=copyLCH(currentLCH);zone4.t=.5;}invalidate();renderAll();}
function initializeFromForeground(c){currentRGB={r:c.r,g:c.g,b:c.b};addHistoryColor(currentRGB);currentLCH=rgbToLch(c.r,c.g,c.b);zone1.base=copyLCH(currentLCH);zone1.selectedHue=currentLCH.h;zone2.base=copyLCH(currentLCH);zone2.t=.5;zone3.hue=currentLCH.h;syncToneMarkerFromCurrent();zone4.base=copyLCH(currentLCH);zone4.t=.5;initialized=true;invalidate();renderAll();}
function setPhotoshopColor(c,source,done){
  c=normalizeRGB(c);
  if(backendTransportReady()){
    var sent=false;try{sent=window.LocalHueTransport.sendCommand({type:'useColor',rgb:c,source:String(source||'panel')});}catch(_){}
    if(sent){if(done)done(true,c);return;}
  }
  internalWrite=true;internalWriteSince=Date.now();
  var script='try {var c=new SolidColor();c.rgb.red='+Number(c.r)+';c.rgb.green='+Number(c.g)+';c.rgb.blue='+Number(c.b)+';app.foregroundColor=c;"OK";} catch(e) {"ERR:"+e.toString();}';
  evalScript(script,function(res){internalWrite=false;internalWriteSince=0;if(res==='OK'){lastPhotoshopRGB=c.r+','+c.g+','+c.b;suppressSyncUntil=Date.now()+250;notifyForegroundChanged(c,source);if(done)done(true,c);}else{if(done)done(false,c);setTimeout(function(){readPhotoshopColor(true);},40);}});
}
function readPhotoshopColor(force){if(photoshopReadBusy){if(force)pendingForcedRead=true;return;}photoshopReadBusy=true;photoshopReadSince=Date.now();var script='try {var c=app.foregroundColor.rgb;Math.round(c.red)+","+Math.round(c.green)+","+Math.round(c.blue);} catch(e) {"ERR:"+e.toString();}';evalScript(script,function(res){photoshopReadBusy=false;photoshopReadSince=0;if(res&&res!=='NO_CEP'&&String(res).indexOf('ERR:')!==0){var p=String(res).split(',');if(p.length===3){var c={r:Number(p[0]),g:Number(p[1]),b:Number(p[2])};if(!isNaN(c.r)&&!isNaN(c.g)&&!isNaN(c.b)){var key=c.r+','+c.g+','+c.b;if(!initialized){lastPhotoshopRGB=key;initializeFromForeground(c);}else if(force||key!==lastPhotoshopRGB){lastPhotoshopRGB=key;if(force||Date.now()>=suppressSyncUntil)notifyForegroundChanged(c,'external');}}}}if(pendingForcedRead){pendingForcedRead=false;setTimeout(function(){readPhotoshopColor(true);},0);}});}


function coreSyncSnapshot(){
  return {persisted:persistedStateObject(),runtime:{
    currentRGB:normalizeRGB(currentRGB),currentLCH:copyLCH(currentLCH),
    zone1:{base:copyLCH(zone1.base),selectedHue:zone1.selectedHue},
    zone2:{base:copyLCH(zone2.base),t:zone2.t},
    zone3:{hue:zone3.hue,t:zone3.t},
    zone4:{base:copyLCH(zone4.base),t:zone4.t},
    zone5:{currentDocKey:zone5.currentDocKey,currentDocId:zone5.currentDocId,currentDocName:zone5.currentDocName},
    initialized:!!initialized,lastPhotoshopRGB:lastPhotoshopRGB
  }};
}
function applySyncSnapshot(sync){
  if(IS_BACKGROUND||!sync||typeof sync!=='object')return false;
  applyingRemoteState=true;
  try{
    if(sync.persisted)applyPersistedState(sync.persisted,false);
    var r=sync.runtime||{};
    if(r.currentRGB)currentRGB=normalizeRGB(r.currentRGB);
    if(r.currentLCH)currentLCH={L:Number(r.currentLCH.L)||0,C:Number(r.currentLCH.C)||0,h:wrapHue(Number(r.currentLCH.h)||0)};
    if(r.zone1){if(r.zone1.base)zone1.base=copyLCH(r.zone1.base);if(isFinite(Number(r.zone1.selectedHue)))zone1.selectedHue=wrapHue(Number(r.zone1.selectedHue));}
    if(r.zone2){if(r.zone2.base)zone2.base=copyLCH(r.zone2.base);if(isFinite(Number(r.zone2.t)))zone2.t=clamp(Number(r.zone2.t),0,1);}
    if(r.zone3){if(isFinite(Number(r.zone3.hue)))zone3.hue=wrapHue(Number(r.zone3.hue));if(isFinite(Number(r.zone3.t)))zone3.t=clamp(Number(r.zone3.t),0,1);}
    if(r.zone4){if(r.zone4.base)zone4.base=copyLCH(r.zone4.base);if(isFinite(Number(r.zone4.t)))zone4.t=clamp(Number(r.zone4.t),0,1);}
    if(r.zone5){zone5.currentDocKey=String(r.zone5.currentDocKey||'__none__');zone5.currentDocId=r.zone5.currentDocId||null;zone5.currentDocName=String(r.zone5.currentDocName||'No document');}
    initialized=typeof r.initialized==='boolean'?r.initialized:true;
    lastPhotoshopRGB=r.lastPhotoshopRGB||rgbKey(currentRGB);
    syncInputsFromState();invalidate();renderAll();saveState();
    return true;
  }catch(_){return false;}finally{applyingRemoteState=false;}
}

function overlayCanvasSampleKey(id,count){
  count=Math.max(8,Math.min(320,Math.round(Number(count)||128)));
  var common=[count,globalStep,globalSnap?1:0],parts;
  if(id==='hueCanvas')parts=[zone1.base.L,zone1.base.C,zone1.base.h,zone1.range];
  else if(id==='anchorCanvas')parts=[zone2.base.L,zone2.base.C,zone2.base.h,zone2.mode,zone2.mode==='Custom'?JSON.stringify(zone2.customAnchors):harmonyRange()];
  else if(id==='toneCanvas')parts=[zone3.hue,zone3.leftC,zone3.leftL,zone3.rightC,zone3.rightL];
  else if(id==='hcCanvas')parts=[zone4.base.L,zone4.base.C,zone4.base.h,zone4.range,zone4.edgeC];
  else parts=[];
  return id+'|'+common.concat(parts).join('|');
}
function overlayCanvasSamples(id,count){
  count=Math.max(8,Math.min(320,Math.round(Number(count)||128)));
  var key=overlayCanvasSampleKey(id,count),cached=overlaySampleCache[id];
  if(cached&&cached.key===key)return cached.samples;
  var out=[],customNodesCache=(id==='anchorCanvas'&&zone2.mode==='Custom')?customNodes():null;
  for(var i=0;i<count;i++){
    var t=count<=1?.5:i/(count-1),q=interactionT(t),c=null;
    if(id==='hueCanvas')c={L:zone1.base.L,C:zone1.base.C,h:wrapHue(zone1.base.h+(q*2-1)*zone1.range)};
    else if(id==='anchorCanvas'){
      var degree=zone2.mode==='Custom'?customDegreeAt(q,customNodesCache):tToOffset(q,harmonyRange());
      c={L:zone2.base.L,C:zone2.base.C,h:wrapHue(zone2.base.h+degree)};
    }else if(id==='toneCanvas')c=toneAt(q,false);
    else if(id==='hcCanvas')c=hueChromaAt(q);
    if(c){var rgb=lchToRgbPreview(c.L,c.C,c.h);out.push([rgb.r,rgb.g,rgb.b]);}
  }
  overlaySampleCache[id]={key:key,samples:out};
  return out;
}
function overlayHueT(){var d=clamp(angularDiff(zone1.selectedHue,zone1.base.h),-zone1.range,zone1.range);return clamp((d+zone1.range)/(2*zone1.range),0,1);}
function overlayHarmonyLines(){var out=[],i,rgb;if(zone2.mode==='Custom'){var a=sortedCustomAnchors();for(i=0;i<a.length;i++){rgb=colorForOffset(a[i].degree);out.push({id:a[i].id,pos:a[i].pos,degree:a[i].degree,draggable:true,rgb:[rgb.r,rgb.g,rgb.b]});}}else{var range=harmonyRange(),offs=harmonyOffsets();for(i=0;i<offs.length;i++){rgb=colorForOffset(offs[i]);out.push({id:'preset'+i,pos:offsetToT(offs[i],range),degree:offs[i],draggable:false,rgb:[rgb.r,rgb.g,rgb.b]});}}return out;}
function overlayHarmonySwatches(){var items=swatchItems(),out=[];for(var i=0;i<items.length;i++){var rgb=colorForOffset(items[i].degree);out.push({label:items[i].label,degree:items[i].degree,pos:items[i].pos,rgb:[rgb.r,rgb.g,rgb.b]});}return out;}
function overlaySnapshot(){
  return {version:2,currentRGB:normalizeRGB(currentRGB),globalStep:globalStep,globalSnap:globalSnap,document:{key:zone5.currentDocKey,name:zone5.currentDocName},sync:coreSyncSnapshot(),modules:{
    hue:{visible:!layoutState.hidden.hue,height:zone1.height,marker:overlayHueT(),sampleKey:overlayCanvasSampleKey('hueCanvas',320),samples:overlayCanvasSamples('hueCanvas',320)},
    harmony:{visible:!layoutState.hidden.harmony,height:zone2.height,marker:zone2.t,mode:zone2.mode,includeCenter:zone2.includeCenter,sampleKey:overlayCanvasSampleKey('anchorCanvas',320),uiKey:[zone2.mode,zone2.includeCenter?1:0,zone2.base.L,zone2.base.C,zone2.base.h,globalStep,globalSnap?1:0,zone2.mode==='Custom'?JSON.stringify(zone2.customAnchors):harmonyOffsets().join(',')].join('|'),samples:overlayCanvasSamples('anchorCanvas',320),lines:overlayHarmonyLines(),swatches:overlayHarmonySwatches()},
    tone:{visible:!layoutState.hidden.tone,height:zone3.height,marker:zone3.t,sampleKey:overlayCanvasSampleKey('toneCanvas',320),samples:overlayCanvasSamples('toneCanvas',320)},
    hc:{visible:!layoutState.hidden.hc,height:zone4.height,marker:zone4.t,sampleKey:overlayCanvasSampleKey('hcCanvas',320),samples:overlayCanvasSamples('hcCanvas',320)},
    store:{visible:!layoutState.hidden.store,uiKey:[zone5.currentDocKey,zone5.currentDocName,rgbKey(currentRGB),JSON.stringify(zone5.history),zone5.currentDocKey==='__none__'?'[]':JSON.stringify(currentPinned())].join('|'),history:zone5.history.slice(0,zone5.historyMax),pinned:zone5.currentDocKey==='__none__'?[]:currentPinned().slice(0,zone5.pinnedMax),docName:zone5.currentDocName}
  }};
}
function beginOverlayInteraction(zone){overlayDraggingZone=String(zone||'overlay');overlayDraggingSince=Date.now();return true;}
function endOverlayInteraction(){overlayDraggingZone=null;overlayDraggingSince=0;return true;}
function overlaySelect(module,t){endOverlayInteraction();t=interactionT(clamp(Number(t),0,1));if(module==='hue'){zone1.selectedHue=wrapHue(zone1.base.h+(t*2-1)*zone1.range);renderZone1();setPhotoshopColor(lchToRgb(zone1.base.L,zone1.base.C,zone1.selectedHue),'hue');return true;}if(module==='harmony'){zone2.t=t;renderZone2();var degree=zone2.mode==='Custom'?customDegreeAt(zone2.t):tToOffset(zone2.t,harmonyRange()),c={L:zone2.base.L,C:zone2.base.C,h:wrapHue(zone2.base.h+degree)};setPhotoshopColor(lchToRgb(c.L,c.C,c.h),'anchor');return true;}if(module==='tone'){zone3.t=t;renderZone3();var tc=toneAt(zone3.t,false);setPhotoshopColor(lchToRgb(tc.L,tc.C,tc.h),'tone');return true;}if(module==='hc'){zone4.t=t;renderZone4();var hc=hueChromaAt(zone4.t);setPhotoshopColor(lchToRgb(hc.L,hc.C,hc.h),'hc',function(ok){if(ok){zone4.t=.5;renderZone4();}});return true;}return false;}
function overlayDispatch(cmd){try{if(!cmd||typeof cmd!=='object')return false;var type=String(cmd.type||'');if(type==='interactionBegin')return beginOverlayInteraction(cmd.module);if(type==='interactionEnd')return endOverlayInteraction();if(type==='select')return overlaySelect(String(cmd.module||''),cmd.t);if(type==='harmonyMode'){endOverlayInteraction();setHarmonyMode(String(cmd.mode||''));return true;}if(type==='addAnchor'){endOverlayInteraction();if(zone2.mode!=='Custom')return false;return addCustomAnchorAtT(cmd.t);}if(type==='setAnchorDegree'){if(zone2.mode!=='Custom'){if(cmd.final)endOverlayInteraction();return false;}beginOverlayInteraction('anchorLine');var a=getCustomAnchor(String(cmd.id||''));if(!a){if(cmd.final)endOverlayInteraction();return false;}a.degree=quantizeDegree(Number(cmd.degree)||0);saveState();invalidate('z2');renderZone2();if(cmd.final)endOverlayInteraction();return true;}if(type==='deleteAnchor'){endOverlayInteraction();if(zone2.mode!=='Custom'||zone2.customAnchors.length<=1)return false;var id=String(cmd.id||''),before=zone2.customAnchors.length;zone2.customAnchors=zone2.customAnchors.filter(function(x){return x.id!==id;});if(zone2.customAnchors.length===before)return false;saveState();invalidate('z2');renderZone2();return true;}if(type==='useColor'){endOverlayInteraction();var c=normalizeRGB(cmd.rgb||{});setPhotoshopColor(c,String(cmd.source||'overlay'));return true;}if(type==='pinCurrent'){endOverlayInteraction();pinColor(currentRGB);return true;}if(type==='pinColor'){endOverlayInteraction();pinColor(normalizeRGB(cmd.rgb||{}));return true;}if(type==='deletePinned'){endOverlayInteraction();removePinnedColor(normalizeRGB(cmd.rgb||{}));return true;}if(type==='clearHistory'){endOverlayInteraction();zone5.history=[];renderColorStores();saveState();return true;}return false;}catch(_){endOverlayInteraction();return false;}}
window.LocalHueCoreAPI={snapshot:overlaySnapshot,stateKey:function(){try{return JSON.stringify(coreSyncSnapshot());}catch(_){return String(Date.now());}},dispatch:overlayDispatch,render:renderAll,persistedState:persistedStateObject,applyPersistedState:function(state,persist){var ok=applyPersistedState(state,true);if(ok&&persist)saveState();return ok;},syncSnapshot:coreSyncSnapshot,applySyncSnapshot:applySyncSnapshot};

function bindStrip(canvasId,zoneName,previewFn,commitFn,cancelFn){var canvas=$(canvasId);canvas.addEventListener('pointerdown',function(e){if(e.isPrimary===false)return;draggingZone=zoneName;var pid=e.pointerId,lastT=.5;function apply(ev){lastT=eventT(ev,canvas);previewFn(lastT);}function move(ev){if(ev.pointerId!==pid||draggingZone!==zoneName)return;apply(ev);ev.preventDefault();}function cleanup(){document.removeEventListener('pointermove',move,true);document.removeEventListener('pointerup',up,true);document.removeEventListener('pointercancel',cancel,true);}function up(ev){if(ev.pointerId!==pid||draggingZone!==zoneName)return;apply(ev);draggingZone=null;cleanup();commitFn(lastT);ev.preventDefault();}function cancel(ev){if(ev.pointerId!==pid)return;draggingZone=null;cleanup();if(cancelFn)cancelFn();}apply(e);document.addEventListener('pointermove',move,true);document.addEventListener('pointerup',up,true);document.addEventListener('pointercancel',cancel,true);e.preventDefault();});}

bindStrip('hueCanvas','hue',function(t){t=interactionT(t);zone1.selectedHue=wrapHue(zone1.base.h+(t*2-1)*zone1.range);setMarker('hueMarker',t);},function(){setPhotoshopColor(lchToRgb(zone1.base.L,zone1.base.C,zone1.selectedHue),'hue');},function(){zone1.selectedHue=zone1.base.h;renderZone1();});
(function bindHarmony(){var wrap=$('anchorWrap'),canvas=$('anchorCanvas'),marker=$('anchorMarker');wrap.addEventListener('contextmenu',function(e){if(zone2.mode!=='Custom')return;if(e.target&&e.target.classList&&(e.target.classList.contains('anchorLine')||e.target.classList.contains('anchorSelectedMarker')))return;e.preventDefault();addCustomAnchorAt(e.clientX);});function startPick(e,fromMarker){if(e.button===2||e.isPrimary===false)return;if(fromMarker){e.preventDefault();e.stopPropagation();}draggingZone='anchor';var pid=e.pointerId,lastT=zone2.t;function apply(ev){lastT=interactionT(eventT(ev,canvas));zone2.t=lastT;setMarker('anchorMarker',zone2.t);updateAnchorSwatches();}function move(ev){if(ev.pointerId!==pid||draggingZone!=='anchor')return;apply(ev);ev.preventDefault();}function cleanup(){document.removeEventListener('pointermove',move,true);document.removeEventListener('pointerup',up,true);document.removeEventListener('pointercancel',cancel,true);}function up(ev){if(ev.pointerId!==pid||draggingZone!=='anchor')return;apply(ev);draggingZone=null;cleanup();var degree=zone2.mode==='Custom'?customDegreeAt(zone2.t):tToOffset(zone2.t,harmonyRange()),c={L:zone2.base.L,C:zone2.base.C,h:wrapHue(zone2.base.h+degree)};setPhotoshopColor(lchToRgb(c.L,c.C,c.h),'anchor');ev.preventDefault();}function cancel(ev){if(ev.pointerId!==pid)return;draggingZone=null;cleanup();renderZone2();}if(!fromMarker)apply(e);document.addEventListener('pointermove',move,true);document.addEventListener('pointerup',up,true);document.addEventListener('pointercancel',cancel,true);e.preventDefault();}canvas.addEventListener('pointerdown',function(e){startPick(e,false);});marker.addEventListener('pointerdown',function(e){startPick(e,true);});})();
bindStrip('toneCanvas','tone',function(t){zone3.t=interactionT(t);setMarker('toneMarker',zone3.t);},function(){var c=toneAt(zone3.t,false);setPhotoshopColor(lchToRgb(c.L,c.C,c.h),'tone');},function(){renderZone3();});
bindStrip('hcCanvas','hc',function(t){zone4.t=interactionT(t);setMarker('hcMarker',zone4.t);},function(){var c=hueChromaAt(zone4.t);setPhotoshopColor(lchToRgb(c.L,c.C,c.h),'hc',function(ok){if(ok){zone4.t=.5;renderZone4();}});},function(){zone4.t=.5;renderZone4();});

function bindNumber(id,getter,setter,lo,hi,z,after){$(id).addEventListener('change',function(){var v=clamp(Number(this.value),lo,hi);if(!isFinite(v))v=getter();setter(v);this.value=formatNum(v);if(z)invalidate(z);if(after)after();saveStateAndSync();renderAll();});}
function setHarmonyMode(mode){if(modeIds.indexOf(mode)<0)return;zone2.mode=mode;zone2.t=.5;invalidate('z2');saveStateAndSync();renderZone2();}
$('advancedToggle').addEventListener('click',function(){advancedOpen=!advancedOpen;panel.classList.toggle('advancedOpen',advancedOpen);this.setAttribute('aria-expanded',advancedOpen?'true':'false');$('settingsOverlay').setAttribute('aria-hidden',advancedOpen?'false':'true');saveStateAndSync();setTimeout(function(){invalidate();renderAll();},0);});
bindNumber('uiScaleInput',function(){return uiScale;},function(v){uiScale=v;panel.style.zoom=uiScale/100;},70,150,null,function(){setTimeout(function(){invalidate();renderAll();},0);});
$('globalStepSlider').addEventListener('input',function(){globalStep=clamp(Number(this.value)||.1,.1,25);$('globalStepValue').textContent=formatNum(globalStep)+'%';syncToneMarkerFromCurrent();invalidate();saveStateAndSync();renderAll();});$('globalSnap').addEventListener('change',function(){globalSnap=this.checked;syncToneMarkerFromCurrent();saveStateAndSync();renderZone3();});
bindNumber('hueRangeInput',function(){return zone1.range;},function(v){zone1.range=v;},.1,180,'z1');bindNumber('hueHeightInput',function(){return zone1.height;},function(v){zone1.height=v;setCanvasHeight('hueCanvas',v);},24,160,'z1');bindNumber('anchorHeightInput',function(){return zone2.height;},function(v){zone2.height=v;setCanvasHeight('anchorCanvas',v);},24,160,'z2');$('anchorIncludeCenter').addEventListener('change',function(){zone2.includeCenter=this.checked;saveStateAndSync();renderZone2();});var modeButtons=document.querySelectorAll('.modeButton');for(var mb=0;mb<modeButtons.length;mb++)(function(btn){btn.addEventListener('click',function(){setHarmonyMode(btn.getAttribute('data-mode'));});})(modeButtons[mb]);
bindNumber('toneHeightInput',function(){return zone3.height;},function(v){zone3.height=v;setCanvasHeight('toneCanvas',v);},24,160,'z3');bindNumber('toneLeftC',function(){return zone3.leftC;},function(v){zone3.leftC=v;},0,45,'z3',syncToneMarkerFromCurrent);bindNumber('toneLeftL',function(){return zone3.leftL;},function(v){zone3.leftL=v;},0,100,'z3',syncToneMarkerFromCurrent);bindNumber('toneRightC',function(){return zone3.rightC;},function(v){zone3.rightC=v;},0,45,'z3',syncToneMarkerFromCurrent);bindNumber('toneRightL',function(){return zone3.rightL;},function(v){zone3.rightL=v;},0,100,'z3',syncToneMarkerFromCurrent);bindNumber('hcHeightInput',function(){return zone4.height;},function(v){zone4.height=v;setCanvasHeight('hcCanvas',v);},24,160,'z4');bindNumber('hcRangeInput',function(){return zone4.range;},function(v){zone4.range=v;},.1,180,'z4');bindNumber('hcEdgeCInput',function(){return zone4.edgeC;},function(v){zone4.edgeC=v;},0,100,'z4');$('pinCurrentBtn').addEventListener('click',function(){pinColor(currentRGB);});$('clearHistoryBtn').addEventListener('click',function(){zone5.history=[];renderColorStores();saveStateAndSync();});

$('settingsCloseBtn').addEventListener('click',function(){advancedOpen=false;panel.classList.remove('advancedOpen');$('advancedToggle').setAttribute('aria-expanded','false');$('settingsOverlay').setAttribute('aria-hidden','true');saveStateAndSync();});
$('showHueModule').addEventListener('change',function(){setModuleVisible('hue',this.checked);});
$('showHarmonyModule').addEventListener('change',function(){setModuleVisible('harmony',this.checked);});
$('showToneModule').addEventListener('change',function(){setModuleVisible('tone',this.checked);});
$('showHCModule').addEventListener('change',function(){setModuleVisible('hc',this.checked);});
$('showStoreModule').addEventListener('change',function(){setModuleVisible('store',this.checked);});
$('showAllModulesBtn').addEventListener('click',showAllModules);
$('resetLayoutBtn').addEventListener('click',resetModuleLayout);
bindModuleDragging();
window.addEventListener('resize',function(){invalidate();renderAll();});

loadState();syncInputsFromState();renderAll();
if(!IS_BACKGROUND){try{if(window.__adobe_cep__&&window.__adobe_cep__.invokeSync)window.__adobe_cep__.invokeSync('setWindowTitle','Local Hue Sliders');}catch(_){}fitWindowSoon();}
setInterval(function(){
  var now=Date.now();
  if(internalWrite&&internalWriteSince&&now-internalWriteSince>1500){internalWrite=false;internalWriteSince=0;suppressSyncUntil=0;pendingForcedRead=true;}
  if(photoshopReadBusy&&photoshopReadSince&&now-photoshopReadSince>1500){photoshopReadBusy=false;photoshopReadSince=0;}
  if(overlayDraggingZone&&overlayDraggingSince&&now-overlayDraggingSince>2500)endOverlayInteraction();
  var useDirectHost=IS_BACKGROUND||!backendTransportReady();
  if(useDirectHost&&!draggingZone&&!overlayDraggingZone&&!internalWrite)readPhotoshopColor(false);
  if(useDirectHost&&now-lastDocumentPoll>500){lastDocumentPoll=now;readPhotoshopDocumentIdentity();}
},100);
setTimeout(function(){if(IS_BACKGROUND||!backendTransportReady()){readPhotoshopDocumentIdentity();readPhotoshopColor(true);}},120);
})();
