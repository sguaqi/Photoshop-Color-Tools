(function(){
"use strict";

var PREF_KEY='LocalHueSliders.overlay.v311';
var SEED_KEY='LocalHueSliders.background.seeded.v315';
var prefs={enabled:true,visible:true,topmost:true,locked:false,opacity:0.96,resetToken:0,sizes:{hue:{width:320,height:42},harmony:{width:320,height:42},tone:{width:320,height:42},hc:{width:320,height:42},store:{width:320}}};
var sizePrefsPresent=false;
var fs=null,path=null,os=null,cp=null;
var bridgeDir='',commandsDir='',statePath='',heartbeatPath='',backendHeartbeatPath='',prefsPath='',overlayScript='',launcherScript='';
var lastState='',lastCoreStateKey='',lastOverlayStateKey='',lastLaunch=0,started=false,lastPrefsWrite=0,lastBackgroundStateWrite=0,lastBackendBeat=0,initialSeedSent=false;
var extensionId='com.openai.localhuesliders.panel';
try{if(window.__adobe_cep__&&typeof window.__adobe_cep__.getExtensionId==='function')extensionId=String(window.__adobe_cep__.getExtensionId()||extensionId);}catch(_){}
var isBackground=/\.background$/i.test(extensionId);

function $(id){return document.getElementById(id);}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function nodeRequire(name){try{if(window.cep_node&&window.cep_node.require)return window.cep_node.require(name);}catch(_){}try{if(typeof require==='function')return require(name);}catch(_){}return null;}
function ensureDir(p){try{if(!fs.existsSync(p))fs.mkdirSync(p);}catch(_){} }
function atomicWrite(fp,text){try{var tmp=fp+'.'+String(process&&process.pid||0)+'.tmp';fs.writeFileSync(tmp,text,'utf8');try{if(fs.existsSync(fp))fs.unlinkSync(fp);}catch(_){}fs.renameSync(tmp,fp);return true;}catch(_){try{fs.writeFileSync(fp,text,'utf8');return true;}catch(_2){return false;}}}
function fsExtensionPath(){try{var p=window.__adobe_cep__.getSystemPath('extension');p=decodeURIComponent(String(p||''));p=p.replace(/^file:\/\/\//i,'');if(/^\/[A-Za-z]:/.test(p))p=p.substr(1);return p.replace(/[\\\/]/g,path.sep);}catch(_){return '';}}
function appDataDir(){try{if(typeof process!=='undefined'&&process.env&&process.env.APPDATA)return process.env.APPDATA;}catch(_){}try{return path.join(os.homedir(),'AppData','Roaming');}catch(_2){return os.tmpdir();}}

function copySizes(){return {hue:{width:prefs.sizes.hue.width,height:prefs.sizes.hue.height},harmony:{width:prefs.sizes.harmony.width,height:prefs.sizes.harmony.height},tone:{width:prefs.sizes.tone.width,height:prefs.sizes.tone.height},hc:{width:prefs.sizes.hc.width,height:prefs.sizes.hc.height},store:{width:prefs.sizes.store.width}};}
function applySizeGroup(dst,src,minWidth,hasHeight){if(!src||typeof src!=='object')return; if(isFinite(Number(src.width)))dst.width=clamp(Number(src.width),minWidth,720); if(hasHeight&&isFinite(Number(src.height)))dst.height=clamp(Number(src.height),24,160);}
function applySizesObject(x){if(!x||typeof x!=='object')return false;var before=JSON.stringify(copySizes());applySizeGroup(prefs.sizes.hue,x.hue,180,true);applySizeGroup(prefs.sizes.harmony,x.harmony,220,true);applySizeGroup(prefs.sizes.tone,x.tone,180,true);applySizeGroup(prefs.sizes.hc,x.hc,180,true);applySizeGroup(prefs.sizes.store,x.store,180,false);return before!==JSON.stringify(copySizes());}
function seedSizesFromCoreIfNeeded(){if(sizePrefsPresent||!window.LocalHueCoreAPI||!window.LocalHueCoreAPI.snapshot)return;try{var s=window.LocalHueCoreAPI.snapshot();if(s&&s.modules){if(s.modules.hue&&isFinite(Number(s.modules.hue.height)))prefs.sizes.hue.height=clamp(Number(s.modules.hue.height),24,160);if(s.modules.harmony&&isFinite(Number(s.modules.harmony.height)))prefs.sizes.harmony.height=clamp(Number(s.modules.harmony.height),24,160);if(s.modules.tone&&isFinite(Number(s.modules.tone.height)))prefs.sizes.tone.height=clamp(Number(s.modules.tone.height),24,160);if(s.modules.hc&&isFinite(Number(s.modules.hc.height)))prefs.sizes.hc.height=clamp(Number(s.modules.hc.height),24,160);}}catch(_){}sizePrefsPresent=true;savePrefs();}

function loadPrefs(){
  var x=null;
  try{if(fs&&prefsPath&&fs.existsSync(prefsPath))x=JSON.parse(fs.readFileSync(prefsPath,'utf8'));}catch(_){}
  if(!x){try{x=JSON.parse(localStorage.getItem(PREF_KEY)||'null');}catch(_2){}}
  if(x){
    if(typeof x.enabled==='boolean')prefs.enabled=x.enabled;
    if(typeof x.visible==='boolean')prefs.visible=x.visible;
    if(typeof x.topmost==='boolean')prefs.topmost=x.topmost;
    if(typeof x.locked==='boolean')prefs.locked=x.locked;
    if(isFinite(Number(x.opacity)))prefs.opacity=clamp(Number(x.opacity),.35,1);
    if(isFinite(Number(x.resetToken)))prefs.resetToken=Math.max(0,Math.round(Number(x.resetToken)));
    if(x.sizes&&typeof x.sizes==='object'){applySizesObject(x.sizes);sizePrefsPresent=true;}
  }
}
function prefsObject(){return {enabled:!!prefs.enabled,visible:!!prefs.visible,topmost:!!prefs.topmost,locked:!!prefs.locked,opacity:prefs.opacity,resetToken:prefs.resetToken,sizes:copySizes()};}
function savePrefs(){
  var text=JSON.stringify(prefsObject());
  try{localStorage.setItem(PREF_KEY,text);}catch(_){}
  if(fs&&prefsPath)atomicWrite(prefsPath,text);
}
function applyPrefsObject(x){
  if(!x||typeof x!=='object')return false;
  var before=JSON.stringify(prefsObject());
  if(typeof x.enabled==='boolean')prefs.enabled=x.enabled;
  if(typeof x.visible==='boolean')prefs.visible=x.visible;
  if(typeof x.topmost==='boolean')prefs.topmost=x.topmost;
  if(typeof x.locked==='boolean')prefs.locked=x.locked;
  if(isFinite(Number(x.opacity)))prefs.opacity=clamp(Number(x.opacity),.35,1);
  if(isFinite(Number(x.resetToken)))prefs.resetToken=Math.max(0,Math.round(Number(x.resetToken)));
  if(x.sizes&&typeof x.sizes==='object'){applySizesObject(x.sizes);sizePrefsPresent=true;}
  return before!==JSON.stringify(prefsObject());
}

function initNode(){
  fs=nodeRequire('fs');path=nodeRequire('path');os=nodeRequire('os');cp=nodeRequire('child_process');
  if(!fs||!path||!os||!cp)return false;
  bridgeDir=path.join(os.tmpdir(),'LocalHueSlidersBridgeV315');
  commandsDir=path.join(bridgeDir,'commands');
  ensureDir(bridgeDir);ensureDir(commandsDir);
  statePath=path.join(bridgeDir,'state.json');
  heartbeatPath=path.join(bridgeDir,'heartbeat.txt');
  backendHeartbeatPath=path.join(bridgeDir,'backend-heartbeat.txt');
  var appDir=path.join(appDataDir(),'LocalHueSliders');ensureDir(appDir);
  prefsPath=path.join(appDir,'overlay-prefs-v315.json');
  overlayScript=path.join(fsExtensionPath(),'overlay','LocalHueOverlay.ps1');
  launcherScript=path.join(fsExtensionPath(),'overlay','LaunchOverlay.vbs');
  if(isBackground){
    try{
      var stale=fs.readdirSync(commandsDir),now=Date.now();
      for(var i=0;i<stale.length;i++)if(/\.(json|tmp)$/i.test(stale[i])){
        var fp=path.join(commandsDir,stale[i]);
        try{if(now-fs.statSync(fp).mtime.getTime()>10000)fs.unlinkSync(fp);}catch(_s){}
      }
    }catch(_3){}
  }
  return true;
}
function fileFresh(fp,ms){try{return !!(fs&&fs.existsSync(fp)&&(Date.now()-fs.statSync(fp).mtime.getTime())<ms);}catch(_){return false;}}
function heartbeatAlive(){return fileFresh(heartbeatPath,3500);}
function backendAlive(){return isBackground||fileFresh(backendHeartbeatPath,2800);}
function beatBackend(){if(!isBackground||!fs)return;var now=Date.now();if(now-lastBackendBeat<650)return;lastBackendBeat=now;atomicWrite(backendHeartbeatPath,String(now));}
function backgroundSeeded(){try{return localStorage.getItem(SEED_KEY)==='1';}catch(_){return false;}}
function markBackgroundSeeded(){try{localStorage.setItem(SEED_KEY,'1');}catch(_){} }

function setStatus(text,ok){var el=$('overlayStatus');if(!el)return;el.textContent=text;el.className='overlayStatus'+(ok?' running':'');}
function updateStatus(){
  if(!started){setStatus('Bridge unavailable',false);return;}
  if(isBackground)return;
  if(!backendAlive()){setStatus('Background offline',false);return;}
  if(!prefs.enabled){setStatus('Background ready',true);return;}
  if(heartbeatAlive())setStatus('Running',true);else setStatus('HUD starting…',false);
}
function windowsDir(){try{return (typeof process!=='undefined'&&process.env&&(process.env.WINDIR||process.env.SystemRoot))||(fs&&fs.existsSync('C:\\Windows')?'C:\\Windows':'');}catch(_){return '';}}
function tryCepProcessLaunch(exe,arg){try{if(window.cep&&window.cep.process&&typeof window.cep.process.createProcess==='function'){var pid=window.cep.process.createProcess(exe,'//B','//Nologo',arg);if(pid!==undefined&&pid!==null&&pid!==0&&pid!=='0')return true;}}catch(_){}return false;}
function tryNodeLaunch(exe,arg){try{var child=cp.spawn(exe,['//B','//Nologo',arg],{detached:true,stdio:'ignore'});if(child&&child.unref)child.unref();return true;}catch(_){}try{cp.execFile(exe,['//B','//Nologo',arg],function(){});return true;}catch(_2){}return false;}
function launchOverlay(force){
  if(!isBackground||!started||!prefs.enabled)return;
  if(!force&&heartbeatAlive())return;
  var now=Date.now();if(!force&&now-lastLaunch<2500)return;lastLaunch=now;
  try{
    if(!fs.existsSync(overlayScript)||!fs.existsSync(launcherScript))return;
    var wd=windowsDir(),wscript=wd?path.join(wd,'System32','wscript.exe'):'wscript.exe';
    var ok=tryCepProcessLaunch(wscript,launcherScript);if(!ok)ok=tryNodeLaunch(wscript,launcherScript);
  }catch(_){}
}

function sendCommand(obj){
  if(!started||!fs||!commandsDir||!obj||typeof obj!=='object')return false;
  try{
    var now=Date.now(),rand=Math.floor(Math.random()*1000000000),base=String(now)+'-'+String(rand)+'-'+String(Math.random()).substr(2);
    obj.clientTs=now;
    var tmp=path.join(commandsDir,base+'.tmp'),dst=path.join(commandsDir,base+'.json');
    fs.writeFileSync(tmp,JSON.stringify(obj),'utf8');fs.renameSync(tmp,dst);return true;
  }catch(_){return false;}
}
function processCommands(){
  if(!isBackground||!started||!window.LocalHueCoreAPI)return;
  var files=[];try{files=fs.readdirSync(commandsDir);}catch(_){return;}
  files.sort(function(a,b){try{var ma=fs.statSync(path.join(commandsDir,a)).mtime.getTime(),mb=fs.statSync(path.join(commandsDir,b)).mtime.getTime();if(ma!==mb)return ma-mb;}catch(_){}return a<b?-1:(a>b?1:0);});
  for(var i=0;i<files.length;i++){
    var name=files[i];if(!/\.json$/i.test(name))continue;
    var fp=path.join(commandsDir,name),text='';
    try{text=fs.readFileSync(fp,'utf8');fs.unlinkSync(fp);}catch(_r){continue;}
    try{
      var cmd=JSON.parse(text),type=String(cmd&&cmd.type||'');
      if(type==='syncPersisted'){
        if(cmd.state&&window.LocalHueCoreAPI.applyPersistedState){window.LocalHueCoreAPI.applyPersistedState(cmd.state,true);markBackgroundSeeded();}
        continue;
      }
      if(type==='overlayPrefs'){
        if(applyPrefsObject(cmd.prefs)){savePrefs();publish(true);if(prefs.enabled)launchOverlay(false);}
        continue;
      }
      window.LocalHueCoreAPI.dispatch(cmd);
      if(type==='harmonyMode'||type==='addAnchor'||type==='setAnchorDegree'||type==='deleteAnchor'||type==='pinCurrent'||type==='pinColor'||type==='deletePinned'||type==='clearHistory')markBackgroundSeeded();
    }catch(_p){}
  }
}
function buildState(){
  if(!window.LocalHueCoreAPI||!window.LocalHueCoreAPI.snapshot)return null;
  var s=window.LocalHueCoreAPI.snapshot();
  s.overlay={enabled:!!prefs.enabled,visible:!!prefs.enabled&&!!prefs.visible,topmost:!!prefs.topmost,locked:!!prefs.locked,opacity:prefs.opacity,resetToken:prefs.resetToken,sizes:copySizes()};
  s.backend={extensionId:extensionId,seeded:backgroundSeeded(),writtenAt:Date.now()};
  s.writtenAt=Date.now();return s;
}
function publish(force){
  if(!isBackground||!started)return;
  var coreKey='',overlayKey='';
  try{if(window.LocalHueCoreAPI&&typeof window.LocalHueCoreAPI.stateKey==='function')coreKey=window.LocalHueCoreAPI.stateKey();}catch(_k){}
  try{overlayKey=JSON.stringify({overlay:prefsObject(),seeded:backgroundSeeded()});}catch(_o){}
  if(!force&&coreKey&&overlayKey&&coreKey===lastCoreStateKey&&overlayKey===lastOverlayStateKey)return;
  var s=buildState();if(!s)return;
  var compare=JSON.stringify({core:s.version,currentRGB:s.currentRGB,globalStep:s.globalStep,globalSnap:s.globalSnap,document:s.document,modules:s.modules,overlay:s.overlay,sync:s.sync,seeded:s.backend&&s.backend.seeded});
  if(!force&&compare===lastState){lastCoreStateKey=coreKey;lastOverlayStateKey=overlayKey;return;}
  lastState=compare;lastCoreStateKey=coreKey;lastOverlayStateKey=overlayKey;
  atomicWrite(statePath,JSON.stringify(s));
}
function syncControls(){
  var e=$('overlayEnabled'),v=$('overlayVisible'),t=$('overlayTopmost'),l=$('overlayLocked'),o=$('overlayOpacity');
  if(e)e.checked=prefs.enabled;if(v)v.checked=prefs.visible;if(t)t.checked=prefs.topmost;if(l)l.checked=prefs.locked;if(o)o.value=Math.round(prefs.opacity*100);
  var ov=$('overlayOpacityValue');if(ov)ov.textContent=Math.round(prefs.opacity*100)+'%';
  var map=[['overlayHueWidth','hue','width'],['overlayHueHeight','hue','height'],['overlayHarmonyWidth','harmony','width'],['overlayHarmonyHeight','harmony','height'],['overlayToneWidth','tone','width'],['overlayToneHeight','tone','height'],['overlayHCWidth','hc','width'],['overlayHCHeight','hc','height'],['overlayStoreWidth','store','width']];
  for(var i=0;i<map.length;i++){var el=$(map[i][0]);if(el)el.value=Math.round(prefs.sizes[map[i][1]][map[i][2]]);}
}
function changed(){savePrefs();syncControls();if(isBackground){publish(true);if(prefs.enabled)launchOverlay(false);}else sendCommand({type:'overlayPrefs',prefs:prefsObject()});updateStatus();}
function bindControls(){
  if(isBackground)return;
  syncControls();
  var e=$('overlayEnabled'),v=$('overlayVisible'),t=$('overlayTopmost'),l=$('overlayLocked'),o=$('overlayOpacity'),show=$('overlayShowBtn'),hide=$('overlayHideBtn'),reset=$('overlayResetBtn');
  if(e)e.addEventListener('change',function(){prefs.enabled=this.checked;if(!prefs.enabled)prefs.visible=false;else prefs.visible=true;changed();});
  if(v)v.addEventListener('change',function(){prefs.visible=this.checked;changed();});
  if(t)t.addEventListener('change',function(){prefs.topmost=this.checked;changed();});
  if(l)l.addEventListener('change',function(){prefs.locked=this.checked;changed();});
  if(o)o.addEventListener('input',function(){prefs.opacity=clamp((Number(this.value)||96)/100,.35,1);changed();});
  if(show)show.addEventListener('click',function(){prefs.enabled=true;prefs.visible=true;changed();});
  if(hide)hide.addEventListener('click',function(){prefs.visible=false;changed();});
  if(reset)reset.addEventListener('click',function(){prefs.resetToken++;changed();});
  function bindSize(inputId,module,key,lo,hi){var el=$(inputId);if(!el)return;el.addEventListener('change',function(){var v=clamp(Number(this.value),lo,hi);if(!isFinite(v))v=prefs.sizes[module][key];prefs.sizes[module][key]=v;sizePrefsPresent=true;this.value=Math.round(v);changed();});}
  bindSize('overlayHueWidth','hue','width',180,720);bindSize('overlayHueHeight','hue','height',24,160);
  bindSize('overlayHarmonyWidth','harmony','width',220,720);bindSize('overlayHarmonyHeight','harmony','height',24,160);
  bindSize('overlayToneWidth','tone','width',180,720);bindSize('overlayToneHeight','tone','height',24,160);
  bindSize('overlayHCWidth','hc','width',180,720);bindSize('overlayHCHeight','hc','height',24,160);
  bindSize('overlayStoreWidth','store','width',180,720);
}
function readPrefsIfChanged(){
  if(!isBackground||!prefsPath)return;
  try{
    if(!fs.existsSync(prefsPath))return;
    var mt=fs.statSync(prefsPath).mtime.getTime();if(mt<=lastPrefsWrite)return;lastPrefsWrite=mt;
    var x=JSON.parse(fs.readFileSync(prefsPath,'utf8'));
    if(applyPrefsObject(x)){publish(true);if(prefs.enabled)launchOverlay(false);}
  }catch(_){}
}
function readBackgroundState(){
  if(isBackground||!statePath||!window.LocalHueCoreAPI)return;
  try{
    if(!fs.existsSync(statePath))return;
    var mt=fs.statSync(statePath).mtime.getTime();if(mt<=lastBackgroundStateWrite)return;lastBackgroundStateWrite=mt;
    var s=JSON.parse(fs.readFileSync(statePath,'utf8'));if(!s||!s.modules)return;
    if(s.overlay&&applyPrefsObject(s.overlay))syncControls();
    if(s.backend&&s.backend.seeded===false&&!initialSeedSent&&window.LocalHueCoreAPI.persistedState){
      initialSeedSent=true;sendCommand({type:'syncPersisted',state:window.LocalHueCoreAPI.persistedState(),seed:true});return;
    }
    if(s.sync&&window.LocalHueCoreAPI.applySyncSnapshot)window.LocalHueCoreAPI.applySyncSnapshot(s.sync);
  }catch(_){}
}

started=initNode();
if(started){
  loadPrefs();
  seedSizesFromCoreIfNeeded();
  if(!isBackground&&!fs.existsSync(prefsPath))savePrefs();
  bindControls();
  if(isBackground){
    publish(true);if(prefs.enabled)launchOverlay(false);beatBackend();
    // v3.1.6: keep HUD command latency low without forcing the heavier state
    // publish/prefs path to run at the same high frequency.
    setInterval(function(){processCommands();},35);
    setInterval(function(){beatBackend();readPrefsIfChanged();publish(false);},90);
    setInterval(function(){if(prefs.enabled&&!heartbeatAlive())launchOverlay(false);},1200);
  }else{
    readBackgroundState();
    setInterval(function(){readBackgroundState();updateStatus();},180);
  }
}
updateStatus();

window.LocalHueTransport={
  isBackground:isBackground,
  extensionId:extensionId,
  backendAlive:backendAlive,
  sendCommand:sendCommand,
  sendCoreState:function(state){return sendCommand({type:'syncPersisted',state:state});}
};

window.addEventListener('beforeunload',function(){try{if(isBackground)publish(true);}catch(_){} });
})();
