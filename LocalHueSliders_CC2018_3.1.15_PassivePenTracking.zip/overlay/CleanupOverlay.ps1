# Local Hue Sliders v3.1.15 stale HUD cleanup
$ErrorActionPreference = 'SilentlyContinue'

$targets = @()
try {
    $targets = @(Get-CimInstance Win32_Process | Where-Object {
        ($_.Name -eq 'powershell.exe' -or $_.Name -eq 'pwsh.exe') -and
        $_.CommandLine -like '*LocalHueOverlay.ps1*'
    })
} catch {
    try {
        $targets = @(Get-WmiObject Win32_Process | Where-Object {
            ($_.Name -eq 'powershell.exe' -or $_.Name -eq 'pwsh.exe') -and
            $_.CommandLine -like '*LocalHueOverlay.ps1*'
        })
    } catch {}
}

foreach ($p in $targets) {
    try { Stop-Process -Id ([int]$p.ProcessId) -Force -ErrorAction SilentlyContinue } catch {}
}

$bridgeDir = Join-Path ([IO.Path]::GetTempPath()) 'LocalHueSlidersBridgeV315'
foreach ($name in @('heartbeat.txt','backend-heartbeat.txt')) {
    try { Remove-Item -LiteralPath (Join-Path $bridgeDir $name) -Force -ErrorAction SilentlyContinue } catch {}
}
