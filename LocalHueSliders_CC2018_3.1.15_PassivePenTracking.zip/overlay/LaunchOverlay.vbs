Option Explicit
Dim shell, fso, dirPath, ps1Path, cmd
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dirPath = fso.GetParentFolderName(WScript.ScriptFullName)
ps1Path = fso.BuildPath(dirPath, "LocalHueOverlay.ps1")
cmd = "powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & ps1Path & Chr(34)
shell.Run cmd, 0, False
