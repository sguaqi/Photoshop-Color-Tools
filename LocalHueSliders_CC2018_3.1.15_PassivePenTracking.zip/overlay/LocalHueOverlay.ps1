# Local Hue Sliders v3.1.15 Transparent Overlay — high-refresh marker + performance-tuned Photoshop-bound HUD
# Runs on stock Windows PowerShell 5.1 / .NET WPF. No SDK or external runtime is required.
param()

$ErrorActionPreference = $(if ($env:LHS_OVERLAY_DEBUG -eq '1') { 'Continue' } else { 'SilentlyContinue' })

# Pen isolation base (v3.1.6): this HUD only needs mouse-compatible pointer input, not
# pressure/ink data.  Disable WPF's own Stylus/Touch stack *before* PresentationCore
# is loaded so WPF does not open a competing tablet context while Photoshop is
# using Windows Ink / WinTab for brush pressure.  Windows still promotes pen taps
# to normal mouse messages, which is exactly what the HUD input pump consumes.
# v3.1.7 goes further: the WPF HWNDs are display-only and never receive the pen.
# Set LHS_WPF_STYLUS=1 only for diagnostics to restore the legacy WPF stylus stack.
if ($env:LHS_WPF_STYLUS -ne '1') {
    try { [System.AppContext]::SetSwitch('Switch.System.Windows.Input.Stylus.DisableStylusAndTouchSupport', $true) } catch {}
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Xaml

if (-not ([System.Management.Automation.PSTypeName]'LHSWin32').Type) {
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class LHSWin32 {
    const int GWLP_HWNDPARENT = -8;
    const uint SWP_NOSIZE = 0x0001;
    const uint SWP_NOMOVE = 0x0002;
    const uint SWP_NOACTIVATE = 0x0010;
    static readonly IntPtr HWND_TOP = IntPtr.Zero;
    static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
    static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);

    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
    [DllImport("user32.dll", SetLastError=true)] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll", SetLastError=true)] public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
    [DllImport("user32.dll", EntryPoint="SetWindowLongPtr", SetLastError=true)] static extern IntPtr SetWindowLongPtr64(IntPtr hWnd, int nIndex, IntPtr dwNewLong);
    [DllImport("user32.dll", EntryPoint="SetWindowLong", SetLastError=true)] static extern int SetWindowLong32(IntPtr hWnd, int nIndex, int dwNewLong);
    [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT lpPoint);
    [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vKey);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr hWnd, uint gaFlags);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hWnd, IntPtr insertAfter, int x, int y, int cx, int cy, uint flags);

    public static IntPtr SetOwner(IntPtr hWnd, IntPtr owner) {
        if (hWnd == IntPtr.Zero) return IntPtr.Zero;
        if (IntPtr.Size == 8) return SetWindowLongPtr64(hWnd, GWLP_HWNDPARENT, owner);
        return new IntPtr(SetWindowLong32(hWnd, GWLP_HWNDPARENT, owner.ToInt32()));
    }

    public static void RaiseNoActivate(IntPtr hWnd, bool topmost) {
        if (hWnd == IntPtr.Zero) return;
        if (topmost) {
            SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        } else {
            // First leave the global topmost band, then raise only inside the normal/owned band.
            SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
            SetWindowPos(hWnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        }
    }
}
"@
}

# v3.1.7: the visible WPF windows are display-only.  A tiny native Win32
# input window sits above each module and consumes legacy mouse-compatible
# pen taps without ever creating a WPF Stylus/Tablet context.  This keeps the
# Photoshop pressure pipeline out of WPF for the whole pen-proximity cycle.
if (-not ([System.Management.Automation.PSTypeName]'LHSNativeInput').Type) {
Add-Type @"
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Runtime.InteropServices;

public sealed class LHSNativeInputEvent {
    public string ModuleId;
    public int Message;
    public int X;
    public int Y;
    public long Seq;
    public bool GlobalTracked;
}

public static class LHSNativeInput {
    const int WS_POPUP = unchecked((int)0x80000000);
    const int WS_EX_TOOLWINDOW = 0x00000080;
    const int WS_EX_LAYERED = 0x00080000;
    const int WS_EX_NOACTIVATE = 0x08000000;
    const int LWA_ALPHA = 0x00000002;
    const int SW_HIDE = 0;
    const int SW_SHOWNOACTIVATE = 4;
    const uint SWP_NOACTIVATE = 0x0010;
    const uint SWP_NOOWNERZORDER = 0x0200;
    const uint SWP_SHOWWINDOW = 0x0040;
    const int WM_MOUSEACTIVATE = 0x0021;
    const int MA_NOACTIVATE = 3;
    const int WM_MOUSEMOVE = 0x0200;
    const int WM_LBUTTONDOWN = 0x0201;
    const int WM_LBUTTONUP = 0x0202;
    const int WM_RBUTTONDOWN = 0x0204;
    const int WM_RBUTTONUP = 0x0205;
    const int WM_LBUTTONDBLCLK = 0x0203;
    const int WM_RBUTTONDBLCLK = 0x0206;
    const int WH_MOUSE_LL = 14;

    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    struct WNDCLASSEX {
        public uint cbSize; public uint style; [MarshalAs(UnmanagedType.FunctionPtr)] public WndProc lpfnWndProc; public int cbClsExtra; public int cbWndExtra;
        public IntPtr hInstance; public IntPtr hIcon; public IntPtr hCursor; public IntPtr hbrBackground;
        public string lpszMenuName; public string lpszClassName; public IntPtr hIconSm;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)]
    struct MSLLHOOKSTRUCT {
        public POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    delegate IntPtr WndProc(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);
    static readonly WndProc Proc = WindowProc;
    static readonly LowLevelMouseProc MouseHookProc = GlobalMouseProc;
    static readonly string ClassName = "LHSNativePenInput_315";
    static readonly ConcurrentQueue<LHSNativeInputEvent> Queue = new ConcurrentQueue<LHSNativeInputEvent>();
    static readonly Dictionary<IntPtr,string> Ids = new Dictionary<IntPtr,string>();
    static readonly object Gate = new object();
    static readonly object HookGate = new object();
    static long seq = 0;
    static bool registered = false;
    static IntPtr mouseHook = IntPtr.Zero;
    static string trackedModule = "";

    [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern ushort RegisterClassEx(ref WNDCLASSEX lpwcx);
    [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern IntPtr CreateWindowEx(int exStyle,string cls,string name,int style,int x,int y,int w,int h,IntPtr parent,IntPtr menu,IntPtr inst,IntPtr param);
    [DllImport("user32.dll")] static extern IntPtr DefWindowProc(IntPtr hWnd,uint msg,IntPtr wParam,IntPtr lParam);
    [DllImport("user32.dll")] static extern bool DestroyWindow(IntPtr hWnd);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd,int cmd);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hWnd,IntPtr insertAfter,int x,int y,int cx,int cy,uint flags);
    [DllImport("user32.dll")] static extern bool SetLayeredWindowAttributes(IntPtr hwnd,uint key,byte alpha,uint flags);
    [DllImport("user32.dll", EntryPoint="SetWindowLongPtr", SetLastError=true)] static extern IntPtr SetWindowLongPtr64(IntPtr hWnd,int nIndex,IntPtr dwNewLong);
    [DllImport("user32.dll", EntryPoint="SetWindowLong", SetLastError=true)] static extern int SetWindowLong32(IntPtr hWnd,int nIndex,int dwNewLong);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
    [DllImport("gdi32.dll")] static extern IntPtr GetStockObject(int obj);
    [DllImport("user32.dll", SetLastError=true)] static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);
    [DllImport("user32.dll", SetLastError=true)] static extern bool UnhookWindowsHookEx(IntPtr hhk);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr hwnd,ref POINT pt);

    static void EnsureClass() {
        if (registered) return;
        var wc = new WNDCLASSEX();
        wc.cbSize = (uint)Marshal.SizeOf(typeof(WNDCLASSEX));
        wc.lpfnWndProc = Proc; wc.hInstance = GetModuleHandle(null); wc.lpszClassName = ClassName; wc.hbrBackground = GetStockObject(4); // BLACK_BRUSH
        ushort a = RegisterClassEx(ref wc);
        registered = a != 0 || Marshal.GetLastWin32Error() == 1410; // class already exists
        if (!registered) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
    }

    public static IntPtr Create(string moduleId, IntPtr owner) {
        EnsureClass();
        int ex = WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_NOACTIVATE;
        IntPtr h = CreateWindowEx(ex,ClassName,"",WS_POPUP,0,0,1,1,owner,IntPtr.Zero,GetModuleHandle(null),IntPtr.Zero);
        if (h == IntPtr.Zero) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        SetLayeredWindowAttributes(h,0,1,LWA_ALPHA); // 1/255: visually imperceptible but still hit-testable
        lock(Gate) Ids[h] = moduleId ?? "";
        ShowWindow(h,SW_SHOWNOACTIVATE);
        return h;
    }

    public static void SetOwner(IntPtr h, IntPtr owner) {
        if (h == IntPtr.Zero) return;
        const int GWLP_HWNDPARENT = -8;
        if (IntPtr.Size == 8) SetWindowLongPtr64(h,GWLP_HWNDPARENT,owner);
        else SetWindowLong32(h,GWLP_HWNDPARENT,owner.ToInt32());
    }

    public static void SetBounds(IntPtr h,int x,int y,int w,int hgt,bool visible,bool topmost) {
        if (h == IntPtr.Zero) return;
        if (!visible) { ShowWindow(h,SW_HIDE); return; }
        if (topmost) {
            SetWindowPos(h,new IntPtr(-1),x,y,Math.Max(1,w),Math.Max(1,hgt),SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_SHOWWINDOW); // HWND_TOPMOST
        } else {
            SetWindowPos(h,new IntPtr(-2),x,y,Math.Max(1,w),Math.Max(1,hgt),SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_SHOWWINDOW); // HWND_NOTOPMOST
            SetWindowPos(h,IntPtr.Zero,x,y,Math.Max(1,w),Math.Max(1,hgt),SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_SHOWWINDOW); // HWND_TOP
        }
    }

    public static void Destroy(IntPtr h) {
        if (h == IntPtr.Zero) return;
        lock(Gate) Ids.Remove(h);
        DestroyWindow(h);
    }

    public static void StopGlobalTracking() {
        lock(HookGate) { StopGlobalTrackingNoLock(); }
    }

    static void StopGlobalTrackingNoLock() {
        IntPtr old = mouseHook;
        mouseHook = IntPtr.Zero;
        trackedModule = "";
        if (old != IntPtr.Zero) UnhookWindowsHookEx(old);
    }

    static bool StartGlobalTracking(string moduleId) {
        lock(HookGate) {
            StopGlobalTrackingNoLock();
            trackedModule = moduleId ?? "";
            mouseHook = SetWindowsHookEx(WH_MOUSE_LL, MouseHookProc, GetModuleHandle(null), 0);
            if (mouseHook == IntPtr.Zero) {
                trackedModule = "";
                return false;
            }
            return true;
        }
    }

    public static LHSNativeInputEvent[] Drain() {
        var list = new List<LHSNativeInputEvent>();
        LHSNativeInputEvent e; while (Queue.TryDequeue(out e)) list.Add(e);
        return list.ToArray();
    }

    static string ModuleFor(IntPtr hwnd) {
        string id=""; lock(Gate) { Ids.TryGetValue(hwnd,out id); }
        return id ?? "";
    }

    static void Enqueue(IntPtr hwnd,int msg,IntPtr lParam,bool globallyTracked) {
        string id=ModuleFor(hwnd);
        int raw=unchecked((int)lParam.ToInt64()); int x=(short)(raw & 0xffff), y=(short)((raw >> 16) & 0xffff);
        POINT pt=new POINT{X=x,Y=y};
        ClientToScreen(hwnd,ref pt);
        Queue.Enqueue(new LHSNativeInputEvent{ModuleId=id,Message=msg,X=pt.X,Y=pt.Y,Seq=System.Threading.Interlocked.Increment(ref seq),GlobalTracked=globallyTracked});
    }

    static void EnqueueGlobal(string id,int msg,POINT pt) {
        Queue.Enqueue(new LHSNativeInputEvent{ModuleId=id ?? "",Message=msg,X=pt.X,Y=pt.Y,Seq=System.Threading.Interlocked.Increment(ref seq),GlobalTracked=true});
    }

    static IntPtr GlobalMouseProc(int nCode, IntPtr wParam, IntPtr lParam) {
        IntPtr hookSnapshot = mouseHook;
        bool stopAfter = false;
        if (nCode >= 0 && hookSnapshot != IntPtr.Zero) {
            int msg = unchecked((int)wParam.ToInt64());
            if (msg == WM_MOUSEMOVE || msg == WM_LBUTTONUP) {
                var info = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(MSLLHOOKSTRUCT));
                string id; lock(HookGate) { id = trackedModule; }
                EnqueueGlobal(id,msg,info.pt);
                if (msg == WM_LBUTTONUP) stopAfter = true;
            }
        }
        IntPtr next = CallNextHookEx(hookSnapshot,nCode,wParam,lParam);
        if (stopAfter) StopGlobalTracking();
        return next;
    }

    static IntPtr WindowProc(IntPtr hwnd,uint msg,IntPtr wParam,IntPtr lParam) {
        if (msg == WM_MOUSEACTIVATE) return new IntPtr(MA_NOACTIVATE);

        // v3.1.15: never capture the pen/mouse.  A drag starts on the tiny no-activate
        // native sink, then a temporary WH_MOUSE_LL observer reads move/up coordinates
        // globally and immediately calls the next hook.  This is read-only tracking:
        // Photoshop keeps normal ownership of its Windows Ink / WinTab pointer context.
        if (msg == WM_LBUTTONDOWN || msg == WM_LBUTTONDBLCLK) {
            bool tracked = StartGlobalTracking(ModuleFor(hwnd));
            Enqueue(hwnd,(int)msg,lParam,tracked);
            return IntPtr.Zero;
        }
        if (msg == WM_RBUTTONDOWN || msg == WM_RBUTTONUP || msg == WM_RBUTTONDBLCLK) {
            Enqueue(hwnd,(int)msg,lParam,false);
            return IntPtr.Zero;
        }
        return DefWindowProc(hwnd,msg,wParam,lParam);
    }
}
"@
}

$createdNew = $false
$mutex = [System.Threading.Mutex]::new($true, 'LocalHueSlidersOverlay_v315', [ref]$createdNew)
if (-not $createdNew) { exit }

$bridgeDir = Join-Path ([IO.Path]::GetTempPath()) 'LocalHueSlidersBridgeV315'
$commandsDir = Join-Path $bridgeDir 'commands'
$statePath = Join-Path $bridgeDir 'state.json'
$heartbeatPath = Join-Path $bridgeDir 'heartbeat.txt'
$backendHeartbeatPath = Join-Path $bridgeDir 'backend-heartbeat.txt'
$appDir = Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'LocalHueSliders'
$layoutPath = Join-Path $appDir 'overlay-layout-v311.json'
[IO.Directory]::CreateDirectory($bridgeDir) | Out-Null
[IO.Directory]::CreateDirectory($commandsDir) | Out-Null
[IO.Directory]::CreateDirectory($appDir) | Out-Null
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)

$script:Windows = @{}
$script:C = @{}
$script:State = $null
$script:LastStateWrite = [DateTime]::MinValue
$script:LastHeartbeat = [DateTime]::MinValue
$script:LastResetToken = $null
$script:SelectDrag = $null
$script:AnchorDrag = $null
$script:LayoutDrag = $null
$script:LastAnchorSend = [DateTime]::MinValue
$script:LastInteractionPulse = [DateTime]::MinValue
$script:CommandSeq = [long]0
$script:Layout = @{}
$script:Initialized = $false
$script:LastInputActivity = [DateTime]::MinValue
$script:InputSinks = @{}
$script:InputSinkRects = @{}
$script:LastSinkRaise = [DateTime]::MinValue
$script:HexBrushCache = @{}
$script:BarSampleKeys = @{}
$script:HarmonyUiKey = ''
$script:StoreUiKey = ''
$script:PhotoshopMainHwnd = [IntPtr]::Zero
$script:PhotoshopProcessIds = @()
$script:HostUiActive = $false
$script:HostMinimized = $false
$script:LastHostRaise = [DateTime]::MinValue
$script:BoundOwnerHwnd = [IntPtr]::Zero

function Clamp([double]$v,[double]$a,[double]$b){ if($v -lt $a){return $a}; if($v -gt $b){return $b}; return $v }
function JS-Round([double]$v){ return [math]::Floor($v + 0.5) }
function Interaction-T([double]$t){
    $t=Clamp $t 0 1
    try{
        if($null -ne $script:State -and [bool]$script:State.globalSnap){
            $step=(Clamp ([double]$script:State.globalStep) .1 25)/100.0
            if($step -gt 0){$t=Clamp ((JS-Round ($t/$step))*$step) 0 1}
        }
    }catch{}
    return $t
}
function Quantize-Degree([double]$d){
    $d=Clamp $d -180 180
    try{
        if($null -ne $script:State -and [bool]$script:State.globalSnap){
            $step=360.0*((Clamp ([double]$script:State.globalStep) .1 25)/100.0)
            if($step -gt 0){$d=Clamp ((JS-Round ($d/$step))*$step) -180 180}
        }
    }catch{}
    return $d
}

function Get-CursorScreenPoint {
    $pt=New-Object LHSWin32+POINT
    if([LHSWin32]::GetCursorPos([ref]$pt)){return [System.Windows.Point]::new([double]$pt.X,[double]$pt.Y)}
    return $null
}
function Left-Button-Down { return (([LHSWin32]::GetAsyncKeyState(0x01) -band 0x8000) -ne 0) }
function Point-FromScreen($element,$screenPoint){
    try{return $element.PointFromScreen($screenPoint)}catch{return $null}
}
function RGBBrush($rgb){
    if($null -eq $rgb){ return [System.Windows.Media.Brushes]::Transparent }
    try { return [System.Windows.Media.SolidColorBrush]::new([System.Windows.Media.Color]::FromRgb([byte]$rgb[0],[byte]$rgb[1],[byte]$rgb[2])) } catch { return [System.Windows.Media.Brushes]::Gray }
}
function RGBObjBrush($c){
    try { return [System.Windows.Media.SolidColorBrush]::new([System.Windows.Media.Color]::FromRgb([byte]$c.r,[byte]$c.g,[byte]$c.b)) } catch { return [System.Windows.Media.Brushes]::Gray }
}
function HexBrush([string]$hex){ try { if($script:HexBrushCache.ContainsKey($hex)){return $script:HexBrushCache[$hex]};$b=[System.Windows.Media.SolidColorBrush]::new([System.Windows.Media.ColorConverter]::ConvertFromString($hex));try{$b.Freeze()}catch{};$script:HexBrushCache[$hex]=$b;return $b } catch { return [System.Windows.Media.Brushes]::Gray } }

function Load-Layout {
    $script:Layout = @{}
    if(Test-Path $layoutPath){
        try{
            $o = Get-Content -Raw -LiteralPath $layoutPath | ConvertFrom-Json
            foreach($id in @('hue','harmony','tone','hc','store')){
                $p = $o.PSObject.Properties[$id]
                if($null -ne $p -and $null -ne $p.Value){
                    $script:Layout[$id] = @{ left=[double]$p.Value.left; top=[double]$p.Value.top }
                }
            }
        }catch{}
    }
}
function Save-Layout {
    try{
        $o=@{}
        foreach($id in $script:Windows.Keys){ $w=$script:Windows[$id]; $o[$id]=@{left=[math]::Round($w.Left,1);top=[math]::Round($w.Top,1)} }
        [IO.File]::WriteAllText($layoutPath,($o|ConvertTo-Json -Depth 4),$utf8NoBom)
    }catch{}
}
function Default-Positions {
    $wa=[System.Windows.SystemParameters]::WorkArea
    $x=[math]::Max($wa.Left+20,$wa.Right-370)
    return @{
        hue=@{left=$x;top=$wa.Top+70}; harmony=@{left=$x;top=$wa.Top+135}; tone=@{left=$x;top=$wa.Top+270}; hc=@{left=$x;top=$wa.Top+335}; store=@{left=$x;top=$wa.Top+400}
    }
}
function Reset-Positions {
    $d=Default-Positions
    foreach($id in $script:Windows.Keys){$w=$script:Windows[$id];$w.Left=$d[$id].left;$w.Top=$d[$id].top}
    Save-Layout
}

function Send-Command($obj){
    try{
        # Hashtable dot-assignment can fail on Windows PowerShell 5.1 when the key does not exist.
        # Always use IDictionary key assignment so commands are actually written.
        $script:CommandSeq++
        $ticks=[DateTime]::UtcNow.Ticks
        if($obj -is [System.Collections.IDictionary]){$obj['ts']=$ticks;$obj['seq']=$script:CommandSeq}
        $json=$obj|ConvertTo-Json -Compress -Depth 8
        # DateTime.UtcNow can have coarse resolution on older Windows builds.
        # A monotonic sequence suffix keeps begin/move/final commands in exact creation order.
        $base=('{0:D20}-{1:D10}-{2}' -f $ticks,$script:CommandSeq,[Guid]::NewGuid().ToString('N'))
        $tmp=Join-Path $commandsDir ($base+'.tmp')
        $dst=Join-Path $commandsDir ($base+'.json')
        [IO.File]::WriteAllText($tmp,$json,$utf8NoBom)
        [IO.File]::Move($tmp,$dst)
    }catch{}
}

function New-StripBitmap($samples){
    try{
        $n=[int]$samples.Count
        if($n -lt 2){return $null}
        $wb=[System.Windows.Media.Imaging.WriteableBitmap]::new($n,1,96,96,[System.Windows.Media.PixelFormats]::Bgra32,$null)
        $pixels=[byte[]]::new($n*4)
        for($i=0;$i -lt $n;$i++){
            $s=$samples[$i];$p=$i*4
            $pixels[$p]=[byte]$s[2];$pixels[$p+1]=[byte]$s[1];$pixels[$p+2]=[byte]$s[0];$pixels[$p+3]=255
        }
        $rect=[System.Windows.Int32Rect]::new(0,0,$n,1)
        $wb.WritePixels($rect,$pixels,$n*4,0)
        $wb.Freeze();return $wb
    }catch{return $null}
}

function Apply-NoActivate($window){
    $window.Add_SourceInitialized({
        param($sender,$e)
        try{
            $h=([System.Windows.Interop.WindowInteropHelper]::new($sender)).Handle
            $GWL_EXSTYLE=-20;$WS_EX_TOOLWINDOW=0x00000080;$WS_EX_TRANSPARENT=0x00000020;$WS_EX_NOACTIVATE=0x08000000
            $ex=[LHSWin32]::GetWindowLong($h,$GWL_EXSTYLE)
            # Display-only HWND: all real input is handled by LHSNativeInput.
            [LHSWin32]::SetWindowLong($h,$GWL_EXSTYLE,($ex -bor $WS_EX_TOOLWINDOW -bor $WS_EX_TRANSPARENT -bor $WS_EX_NOACTIVATE))|Out-Null
            # v3.1.11: keep every HUD module an owned tool window of Photoshop.
            # Owned windows stay above their owner and inherit minimize/hide behavior.
            if($script:PhotoshopMainHwnd -ne [IntPtr]::Zero){[LHSWin32]::SetOwner($h,$script:PhotoshopMainHwnd)|Out-Null}
        }catch{}
    })
}

function New-ModuleWindow([string]$id){
    $w=New-Object System.Windows.Window
    $w.WindowStyle=[System.Windows.WindowStyle]::None
    $w.AllowsTransparency=$true
    $w.Background=[System.Windows.Media.Brushes]::Transparent
    $w.ResizeMode=[System.Windows.ResizeMode]::NoResize
    $w.ShowInTaskbar=$false
    $w.ShowActivated=$false
    $w.Topmost=$false
    $w.SizeToContent=[System.Windows.SizeToContent]::WidthAndHeight
    $w.SnapsToDevicePixels=$true
    Apply-NoActivate $w

    $root=New-Object System.Windows.Controls.Grid
    $root.Background=[System.Windows.Media.Brushes]::Transparent
    $c1=New-Object System.Windows.Controls.ColumnDefinition;$c1.Width=10
    $c2=New-Object System.Windows.Controls.ColumnDefinition;$c2.Width=[System.Windows.GridLength]::Auto
    $root.ColumnDefinitions.Add($c1);$root.ColumnDefinitions.Add($c2)

    $grip=New-Object System.Windows.Controls.Border
    $grip.Width=10;$grip.Background=[System.Windows.Media.Brushes]::Transparent;$grip.Cursor=[System.Windows.Input.Cursors]::SizeAll;$grip.Tag=@{kind='layout';id=$id}
    [System.Windows.Controls.Grid]::SetColumn($grip,0)
    $dots=New-Object System.Windows.Controls.TextBlock;$dots.Text=[string][char]0x22EE;$dots.Foreground=HexBrush '#8EFFFFFF';$dots.FontSize=12;$dots.VerticalAlignment='Center';$dots.HorizontalAlignment='Center';$dots.Opacity=.45;$grip.Child=$dots
    $root.Children.Add($grip)|Out-Null

    $content=New-Object System.Windows.Controls.StackPanel
    $content.Orientation='Vertical';$content.Background=[System.Windows.Media.Brushes]::Transparent
    [System.Windows.Controls.Grid]::SetColumn($content,1);$root.Children.Add($content)|Out-Null
    $w.Content=$root

    $moveHandler={
        param($sender,$e)
        if($e.ChangedButton -ne [System.Windows.Input.MouseButton]::Left){return}
        $mid=[string]$sender.Tag['id']
        if($script:State -and $script:State.overlay.locked){return}
        try{
            $mw=$script:Windows[$mid];$sp=Get-CursorScreenPoint
            if($null -ne $mw -and $null -ne $sp){
                $script:LayoutDrag=@{id=$mid;startScreen=$sp;startLeft=[double]$mw.Left;startTop=[double]$mw.Top}
                $script:LastInputActivity=Get-Date
            }
        }catch{}
        $e.Handled=$true
    }
    $grip.Add_PreviewMouseLeftButtonDown($moveHandler)

    $script:Windows[$id]=$w
    $script:C[$id]=@{root=$root;grip=$grip;content=$content}
    return $w
}

function New-Bar([double]$height){
    $root=New-Object System.Windows.Controls.Grid;$root.Width=320;$root.Height=$height;$root.Margin='2,2,3,3';$root.Background=[System.Windows.Media.Brushes]::Transparent;$root.Cursor=[System.Windows.Input.Cursors]::Cross
    $bg=New-Object System.Windows.Controls.Border;$bg.CornerRadius=6;$bg.BorderThickness=1;$bg.BorderBrush=HexBrush '#AA353535';$bg.Background=HexBrush '#FF444444';$bg.ClipToBounds=$true;$bg.IsHitTestVisible=$false
    $shadow=New-Object System.Windows.Media.Effects.DropShadowEffect;$shadow.BlurRadius=6;$shadow.ShadowDepth=1;$shadow.Opacity=.38;$shadow.Color=[System.Windows.Media.Colors]::Black;$bg.Effect=$shadow
    $canvas=New-Object System.Windows.Controls.Canvas;$canvas.Background=[System.Windows.Media.Brushes]::Transparent;$canvas.ClipToBounds=$true
    $root.Children.Add($bg)|Out-Null;$root.Children.Add($canvas)|Out-Null

    # Explicit interaction surface. Do not rely on bubbling through the visual layers:
    # old CEP/WPF + transparent/no-activate windows can route those events inconsistently.
    $surface=New-Object System.Windows.Controls.Border
    $surface.Width=320;$surface.Height=$height;$surface.Background=[System.Windows.Media.Brushes]::Transparent;$surface.Cursor=[System.Windows.Input.Cursors]::Cross
    [System.Windows.Controls.Panel]::SetZIndex($surface,5)
    [System.Windows.Controls.Canvas]::SetLeft($surface,0);[System.Windows.Controls.Canvas]::SetTop($surface,0)

    $black=New-Object System.Windows.Controls.Border;$black.Width=4;$black.Height=$height;$black.Background=HexBrush '#D9000000';$black.IsHitTestVisible=$false
    $white=New-Object System.Windows.Controls.Border;$white.Width=2;$white.Height=$height;$white.Background=[System.Windows.Media.Brushes]::White;$white.IsHitTestVisible=$false
    $hit=New-Object System.Windows.Controls.Border;$hit.Width=12;$hit.Height=$height;$hit.Background=[System.Windows.Media.Brushes]::Transparent;$hit.Cursor=[System.Windows.Input.Cursors]::SizeWE
    # v3.1.13: marker motion uses RenderTransform instead of Canvas.Left.  This keeps
    # the drag path out of WPF layout/arrange and lets the compositor move the marker
    # much more smoothly on high-refresh displays.
    $blackTx=New-Object System.Windows.Media.TranslateTransform;$whiteTx=New-Object System.Windows.Media.TranslateTransform;$hitTx=New-Object System.Windows.Media.TranslateTransform
    $black.RenderTransform=$blackTx;$white.RenderTransform=$whiteTx;$hit.RenderTransform=$hitTx
    [System.Windows.Controls.Canvas]::SetTop($black,0);[System.Windows.Controls.Canvas]::SetTop($white,0);[System.Windows.Controls.Canvas]::SetTop($hit,0)
    [System.Windows.Controls.Panel]::SetZIndex($black,20);[System.Windows.Controls.Panel]::SetZIndex($white,21);[System.Windows.Controls.Panel]::SetZIndex($hit,30)
    $canvas.Children.Add($surface)|Out-Null;$canvas.Children.Add($black)|Out-Null;$canvas.Children.Add($white)|Out-Null;$canvas.Children.Add($hit)|Out-Null
    return @{root=$root;bg=$bg;canvas=$canvas;surface=$surface;black=$black;marker=$white;markerHit=$hit;blackTx=$blackTx;markerTx=$whiteTx;markerHitTx=$hitTx;t=.5;bitmap=$null;pixels=$null;imageBrush=$null;sampleCount=0}
}
function Set-BarImage($bar,$samples){
    try{
        $n=[int]$samples.Count;if($n -lt 2){return}
        if($null -eq $bar.bitmap -or [int]$bar.sampleCount -ne $n){
            $bar.bitmap=[System.Windows.Media.Imaging.WriteableBitmap]::new($n,1,96,96,[System.Windows.Media.PixelFormats]::Bgra32,$null)
            $bar.pixels=[byte[]]::new($n*4);$bar.sampleCount=$n
            $bar.imageBrush=[System.Windows.Media.ImageBrush]::new($bar.bitmap);$bar.imageBrush.Stretch=[System.Windows.Media.Stretch]::Fill;$bar.bg.Background=$bar.imageBrush
        }
        $pixels=$bar.pixels
        for($i=0;$i -lt $n;$i++){$ss=$samples[$i];$p=$i*4;$pixels[$p]=[byte]$ss[2];$pixels[$p+1]=[byte]$ss[1];$pixels[$p+2]=[byte]$ss[0];$pixels[$p+3]=255}
        $bar.bitmap.WritePixels([System.Windows.Int32Rect]::new(0,0,$n,1),$pixels,$n*4,0)
    }catch{}
}
function Set-Marker($bar,[double]$t){
    $t=Clamp $t 0 1;$bar.t=$t;$w=[double]$bar.root.Width;$x=$t*$w
    # Height/Top are geometry concerns and are updated by Apply-BarGeometry/New-Bar.
    # During drag only the compositor transform changes, avoiding a full layout pass.
    $bar.blackTx.X=$x-2;$bar.markerTx.X=$x-1;$bar.markerHitTx.X=$x-6
}
function Event-T($e,$root){$p=$e.GetPosition($root);$w=[double]$root.ActualWidth;if($w -le 0){$w=[double]$root.Width};return Clamp ($p.X/$w) 0 1}
function Add-SelectionTargetHandlers($target,[string]$module){
    $target.Tag=@{kind='select';module=$module}
    $target.Add_PreviewMouseLeftButtonDown({
        param($sender,$e)
        if($e.ChangedButton -ne [System.Windows.Input.MouseButton]::Left){return}
        try{$mid=[string]$sender.Tag['module']}catch{return}
        $b=$script:C[$mid].bar;if($null -eq $b){return}
        $sp=Get-CursorScreenPoint;if($null -eq $sp){return}
        $p=Point-FromScreen $b.root $sp;if($null -eq $p){return}
        $w=[double]$b.root.ActualWidth;if($w -le 0){$w=[double]$b.root.Width}
        $t=Interaction-T (Clamp ($p.X/$w) 0 1)
        $script:SelectDrag=@{module=$mid;lastT=$t}
        $script:LastInputActivity=Get-Date
        Set-Marker $b $t
        Send-Command @{type='interactionBegin';module=$mid}
        $script:LastInteractionPulse=Get-Date
        $e.Handled=$true
    })
}

function Add-SelectionHandlers($bar,[string]$module){
    # Two explicit input surfaces: the full strip, and a wider invisible hit area
    # around the white selection marker. The marker hit area is higher in Z order,
    # so it wins when it overlaps a Harmony relation line.
    Add-SelectionTargetHandlers $bar.surface $module
    Add-SelectionTargetHandlers $bar.markerHit $module
}


function New-SimpleModule([string]$id){
    $w=New-ModuleWindow $id;$bar=New-Bar 42;$script:C[$id].content.Children.Add($bar.root)|Out-Null;$script:C[$id].bar=$bar;Add-SelectionHandlers $bar $id
}

function New-HarmonyModule {
    $id='harmony';$w=New-ModuleWindow $id
    $modes=New-Object System.Windows.Controls.StackPanel;$modes.Orientation='Horizontal';$modes.Margin='2,0,0,2';$script:C[$id].content.Children.Add($modes)|Out-Null
    $labels=@{Analogous=([string][char]0x2194);Complement=([string][char]0x2502);Split=([string][char]0x2234);Triad=([string][char]0x25B3);Square=([string][char]0x25A1);Hexadic=([string][char]0x2723);Custom=([string][char]0x2162)}
    $script:C[$id].modeButtons=@{}
    foreach($mode in @('Analogous','Complement','Split','Triad','Square','Hexadic','Custom')){
        $b=New-Object System.Windows.Controls.Button;$b.Width=26;$b.Height=24;$b.Margin='0,0,4,0';$b.Content=$labels[$mode];$b.FontSize=11;$b.Foreground=HexBrush '#FFE0E0E0';$b.Background=HexBrush '#D92C2C2C';$b.BorderBrush=HexBrush '#AA555555';$b.BorderThickness=1;$b.Padding=0;$b.Focusable=$false;$b.ToolTip=$mode;$b.Tag=@{kind='harmonyMode';mode=$mode}
        $b.Add_Click({param($sender,$e) Send-Command @{type='harmonyMode';mode=[string]$sender.Tag['mode']};$e.Handled=$true})
        $modes.Children.Add($b)|Out-Null;$script:C[$id].modeButtons[$mode]=$b
    }
    $bar=New-Bar 42;$script:C[$id].content.Children.Add($bar.root)|Out-Null;$script:C[$id].bar=$bar;Add-SelectionHandlers $bar 'harmony'
    $sw=New-Object System.Windows.Controls.WrapPanel;$sw.Margin='2,1,0,0';$sw.MaxWidth=320;$script:C[$id].content.Children.Add($sw)|Out-Null;$script:C[$id].swatches=$sw
    $bar.root.Add_MouseRightButtonDown({
        param($sender,$e)
        if($null -eq $script:State -or $script:State.modules.harmony.mode -ne 'Custom'){return}
        $b=$script:C.harmony.bar;$t=Event-T $e $b.root;Send-Command @{type='addAnchor';t=$t};$e.Handled=$true
    })
}


function New-StoreModule {
    $id='store';$w=New-ModuleWindow $id
    $toolbar=New-Object System.Windows.Controls.StackPanel;$toolbar.Orientation='Horizontal';$toolbar.Margin='2,0,0,3';$script:C[$id].content.Children.Add($toolbar)|Out-Null
    $pin=New-Object System.Windows.Controls.Button;$pin.Content='+ Pin';$pin.Tag=@{kind='pinCurrent'};$pin.Height=22;$pin.Padding='7,0,7,0';$pin.Margin='0,0,5,0';$pin.Focusable=$false;$pin.Foreground=HexBrush '#FFE2E2E2';$pin.Background=HexBrush '#D92E2E2E';$pin.BorderBrush=HexBrush '#AA555555';$pin.Add_Click({Send-Command @{type='pinCurrent'}});$toolbar.Children.Add($pin)|Out-Null
    $clear=New-Object System.Windows.Controls.Button;$clear.Content='Clear';$clear.Tag=@{kind='clearHistory'};$clear.Height=22;$clear.Padding='7,0,7,0';$clear.Focusable=$false;$clear.Foreground=HexBrush '#FFD0D0D0';$clear.Background=HexBrush '#D92E2E2E';$clear.BorderBrush=HexBrush '#AA555555';$clear.Add_Click({Send-Command @{type='clearHistory'}});$toolbar.Children.Add($clear)|Out-Null
    $doc=New-Object System.Windows.Controls.TextBlock;$doc.VerticalAlignment='Center';$doc.Margin='8,0,0,0';$doc.FontSize=9;$doc.Foreground=HexBrush '#AAFFFFFF';$doc.MaxWidth=190;$doc.TextTrimming='CharacterEllipsis';$toolbar.Children.Add($doc)|Out-Null;$script:C[$id].doc=$doc
    foreach($rowName in @('history','pinned')){
        $row=New-Object System.Windows.Controls.StackPanel;$row.Orientation='Horizontal';$row.Margin='2,1,0,1';$lab=New-Object System.Windows.Controls.TextBlock;$lab.Text=($(if($rowName -eq 'history'){'H'}else{'P'}));$lab.Width=12;$lab.VerticalAlignment='Center';$lab.FontSize=9;$lab.Foreground=HexBrush '#99FFFFFF';$row.Children.Add($lab)|Out-Null
        $wrap=New-Object System.Windows.Controls.WrapPanel;$wrap.MaxWidth=305;$row.Children.Add($wrap)|Out-Null;$script:C[$id][$rowName]=$wrap;$script:C[$id].content.Children.Add($row)|Out-Null
    }
}

function Build-UI {
    Load-Layout
    New-SimpleModule 'hue';New-HarmonyModule;New-SimpleModule 'tone';New-SimpleModule 'hc';New-StoreModule
    $d=Default-Positions
    foreach($id in $script:Windows.Keys){$w=$script:Windows[$id];if($script:Layout.ContainsKey($id)){$w.Left=$script:Layout[$id].left;$w.Top=$script:Layout[$id].top}else{$w.Left=$d[$id].left;$w.Top=$d[$id].top}}
}

function Update-HarmonyLines($h){
    if($null -ne $script:AnchorDrag){return}
    $bar=$script:C.harmony.bar;$canvas=$bar.canvas
    $remove=@()
    foreach($child in $canvas.Children){
        try{if($child.Tag -is [System.Collections.IDictionary] -and ([string]$child.Tag['kind'] -eq 'rel' -or [string]$child.Tag['kind'] -eq 'anchor')){$remove+=$child}}catch{}
    }
    foreach($child in $remove){$canvas.Children.Remove($child)}
    foreach($ln in $h.lines){
        $hit=New-Object System.Windows.Controls.Grid;$hit.Width=10;$hit.Height=$bar.root.Height;$hit.Background=[System.Windows.Media.Brushes]::Transparent
        $hit.Tag=@{kind=$(if([bool]$ln.draggable){'anchor'}else{'rel'});id=[string]$ln.id;degree=[double]$ln.degree};[System.Windows.Controls.Panel]::SetZIndex($hit,12)
        $v=New-Object System.Windows.Controls.Border;$v.Width=3;$v.HorizontalAlignment='Center';$v.VerticalAlignment='Stretch';$v.Background=RGBBrush $ln.rgb;$v.BorderBrush=HexBrush '#AA101010';$v.BorderThickness=[System.Windows.Thickness]::new(0.5,0,0.5,0);$hit.Children.Add($v)|Out-Null
        $x=(Clamp ([double]$ln.pos) 0 1)*[double]$bar.root.Width;[System.Windows.Controls.Canvas]::SetLeft($hit,$x-5);[System.Windows.Controls.Canvas]::SetTop($hit,0)
        if([bool]$ln.draggable){
            $hit.Add_PreviewMouseLeftButtonDown({
                param($sender,$e)
                if($e.ChangedButton -ne [System.Windows.Input.MouseButton]::Left){return}
                $tag=$sender.Tag;$b=$script:C.harmony.bar;$sp=Get-CursorScreenPoint
                if($null -eq $sp){return};$p=Point-FromScreen $b.root $sp;if($null -eq $p){return}
                $script:AnchorDrag=@{id=[string]$tag['id'];startX=[double]$p.X;startDegree=[double]$tag['degree'];lastDegree=[double]$tag['degree']}
                $script:LastInputActivity=Get-Date
                Send-Command @{type='interactionBegin';module='anchorLine'}
                $e.Handled=$true
            })
            $hit.Add_MouseRightButtonDown({
                param($sender,$e)
                $tag=$sender.Tag;Send-Command @{type='deleteAnchor';id=[string]$tag['id']};$e.Handled=$true
            })
        }else{$hit.IsHitTestVisible=$false}
        $canvas.Children.Add($hit)|Out-Null
    }
    [System.Windows.Controls.Panel]::SetZIndex($bar.black,20);[System.Windows.Controls.Panel]::SetZIndex($bar.marker,21);[System.Windows.Controls.Panel]::SetZIndex($bar.markerHit,30)
}


function Update-HarmonySwatches($h){
    $wrap=$script:C.harmony.swatches;$wrap.Children.Clear()
    foreach($item in $h.swatches){
        $b=New-Object System.Windows.Controls.Button;$b.Height=20;$b.Margin='0,0,4,3';$b.Padding='4,0,5,0';$b.Focusable=$false;$b.Foreground=HexBrush '#FFD8D8D8';$b.Background=HexBrush '#C52B2B2B';$b.BorderBrush=HexBrush '#99555555';$b.BorderThickness=1;$b.Tag=@{kind='harmonySwatch';pos=[double]$item.pos}
        $sp=New-Object System.Windows.Controls.StackPanel;$sp.Orientation='Horizontal'
        $dot=New-Object System.Windows.Shapes.Ellipse;$dot.Width=9;$dot.Height=9;$dot.Margin='0,0,3,0';$dot.Fill=RGBBrush $item.rgb;$dot.Stroke=HexBrush '#AAFFFFFF';$dot.StrokeThickness=.5;$sp.Children.Add($dot)|Out-Null
        $txt=New-Object System.Windows.Controls.TextBlock;$txt.Text=[string]$item.label;$txt.FontSize=9;$sp.Children.Add($txt)|Out-Null;$b.Content=$sp
        $b.Add_Click({param($sender,$e) Send-Command @{type='select';module='harmony';t=[double]$sender.Tag['pos']};$e.Handled=$true})
        $wrap.Children.Add($b)|Out-Null
    }
}


function Same-RGB($a,$b){try{return ([int]$a.r -eq [int]$b.r -and [int]$a.g -eq [int]$b.g -and [int]$a.b -eq [int]$b.b)}catch{return $false}}
function Update-StoreRow($wrap,$items,[bool]$pinned,$current){
    $wrap.Children.Clear()
    foreach($c in $items){
        $sw=New-Object System.Windows.Controls.Border;$sw.Width=18;$sw.Height=18;$sw.Margin='0,0,4,3';$sw.CornerRadius=3;$sw.Background=RGBObjBrush $c;$sw.BorderBrush=$(if(Same-RGB $c $current){[System.Windows.Media.Brushes]::White}else{HexBrush '#AA4F4F4F'});$sw.BorderThickness=$(if(Same-RGB $c $current){2}else{1});$sw.Cursor=[System.Windows.Input.Cursors]::Hand;$sw.ToolTip=('RGB {0}, {1}, {2}' -f $c.r,$c.g,$c.b)
        $sw.Tag=@{kind='storeColor';pinned=$pinned;r=[int]$c.r;g=[int]$c.g;b=[int]$c.b}
        $sw.Add_MouseLeftButtonDown({
            param($sender,$e)
            $tag=$sender.Tag;$src=$(if([bool]$tag['pinned']){'pinned'}else{'history'})
            Send-Command @{type='useColor';source=$src;rgb=@{r=[int]$tag['r'];g=[int]$tag['g'];b=[int]$tag['b']}};$e.Handled=$true
        })
        $sw.Add_MouseRightButtonDown({
            param($sender,$e)
            $tag=$sender.Tag;$rgb=@{r=[int]$tag['r'];g=[int]$tag['g'];b=[int]$tag['b']}
            if([bool]$tag['pinned']){Send-Command @{type='deletePinned';rgb=$rgb}}else{Send-Command @{type='pinColor';rgb=$rgb}}
            $e.Handled=$true
        })
        $wrap.Children.Add($sw)|Out-Null
    }
}


function Update-ModuleVisibility($id,$visible,$overlay){
    $w=$script:Windows[$id];if($null -eq $w){return}
    # v3.1.12 host-follow: the HUD exists only while Photoshop is the active visible host.
    $should=[bool]$overlay.enabled -and [bool]$overlay.visible -and [bool]$visible -and [bool]$script:HostUiActive
    if($should){if(-not $w.IsVisible){$w.Show()}}else{if($w.IsVisible){$w.Hide()}}
    $w.Topmost=([bool]$overlay.topmost -and [bool]$script:HostUiActive);$w.Opacity=Clamp ([double]$overlay.opacity) .35 1
    $script:C[$id].grip.Visibility=$(if([bool]$overlay.locked){[System.Windows.Visibility]::Collapsed}else{[System.Windows.Visibility]::Visible})
}

function Get-HudModuleSize($s,[string]$id,[double]$fallbackWidth,[double]$fallbackHeight){
    $w=$fallbackWidth;$h=$fallbackHeight
    try{
        if($null -ne $s.overlay -and $null -ne $s.overlay.sizes){
            $p=$s.overlay.sizes.PSObject.Properties[$id]
            if($null -ne $p -and $null -ne $p.Value){
                if($null -ne $p.Value.width){$w=[double]$p.Value.width}
                if($null -ne $p.Value.height){$h=[double]$p.Value.height}
            }
        }
    }catch{}
    $minW=$(if($id -eq 'harmony'){220}else{180})
    return @{width=(Clamp $w $minW 720);height=(Clamp $h 24 160)}
}
function Apply-BarGeometry($bar,[double]$width,[double]$height){
    $width=Clamp $width 180 720;$height=Clamp $height 24 160
    $bar.root.Width=$width;$bar.root.Height=$height
    $bar.surface.Width=$width;$bar.surface.Height=$height
    $bar.black.Height=$height;$bar.marker.Height=$height;$bar.markerHit.Height=$height
}
function Apply-StoreWidth([double]$width){
    $width=Clamp $width 180 720
    try{$script:C.store.content.Width=$width}catch{}
    try{$script:C.store.doc.MaxWidth=[math]::Max(40,$width-132)}catch{}
    try{$script:C.store.history.MaxWidth=[math]::Max(120,$width-18)}catch{}
    try{$script:C.store.pinned.MaxWidth=[math]::Max(120,$width-18)}catch{}
}

function Update-State($s){
    $script:State=$s
    if($null -eq $script:LastResetToken){$script:LastResetToken=[int]$s.overlay.resetToken}elseif([int]$s.overlay.resetToken -ne $script:LastResetToken){$script:LastResetToken=[int]$s.overlay.resetToken;Reset-Positions}
    if(-not [bool]$s.overlay.enabled){Destroy-NativeInputSinks;foreach($w in $script:Windows.Values){$w.Close()};[System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown();return}

    foreach($id in @('hue','harmony','tone','hc','store')){Update-ModuleVisibility $id $s.modules.$id.visible $s.overlay}

    # HUD dimensions remain overlay-owned in v3.1.12.  Core/CEP preview heights remain
    # available in modules.*.height, but they no longer resize the Native HUD.
    foreach($id in @('hue','tone','hc')){
        $m=$s.modules.$id;$bar=$script:C[$id].bar;$sz=Get-HudModuleSize $s $id 320 42
        Apply-BarGeometry $bar ([double]$sz.width) ([double]$sz.height)
        $sampleKey='';try{$sampleKey=[string]$m.sampleKey}catch{}
        if($sampleKey -eq '' -or -not $script:BarSampleKeys.ContainsKey($id) -or [string]$script:BarSampleKeys[$id] -ne $sampleKey){Set-BarImage $bar $m.samples;if($sampleKey -ne ''){$script:BarSampleKeys[$id]=$sampleKey}}
        if($null -eq $script:SelectDrag -or $script:SelectDrag.module -ne $id){Set-Marker $bar ([double]$m.marker)}
    }
    $h=$s.modules.harmony;$bar=$script:C.harmony.bar;$hsz=Get-HudModuleSize $s 'harmony' 320 42
    Apply-BarGeometry $bar ([double]$hsz.width) ([double]$hsz.height)
    try{$script:C.harmony.swatches.MaxWidth=[double]$hsz.width}catch{}
    $hSampleKey='';try{$hSampleKey=[string]$h.sampleKey}catch{}
    if($hSampleKey -eq '' -or -not $script:BarSampleKeys.ContainsKey('harmony') -or [string]$script:BarSampleKeys['harmony'] -ne $hSampleKey){Set-BarImage $bar $h.samples;if($hSampleKey -ne ''){$script:BarSampleKeys['harmony']=$hSampleKey}}
    if($null -eq $script:SelectDrag -or $script:SelectDrag.module -ne 'harmony'){Set-Marker $bar ([double]$h.marker)}
    $hUiKey='';try{$hUiKey=([string]$h.uiKey)+'|'+([string]$hsz.width)+'x'+([string]$hsz.height)}catch{}
    if($hUiKey -eq '' -or $script:HarmonyUiKey -ne $hUiKey){
        foreach($mode in $script:C.harmony.modeButtons.Keys){$b=$script:C.harmony.modeButtons[$mode];if($mode -eq [string]$h.mode){$b.Background=HexBrush '#E03B466B';$b.BorderBrush=HexBrush '#FF879DEB'}else{$b.Background=HexBrush '#D92C2C2C';$b.BorderBrush=HexBrush '#AA555555'}}
        Update-HarmonyLines $h;Update-HarmonySwatches $h
        $script:HarmonyUiKey=$hUiKey
    }

    $ssz=Get-HudModuleSize $s 'store' 320 42;Apply-StoreWidth ([double]$ssz.width)
    $storeKey='';try{$storeKey=[string]$s.modules.store.uiKey}catch{}
    if($storeKey -eq '' -or $script:StoreUiKey -ne $storeKey){
        $script:C.store.doc.Text=('Pinned - '+[string]$s.modules.store.docName)
        Update-StoreRow $script:C.store.history $s.modules.store.history $false $s.currentRGB
        Update-StoreRow $script:C.store.pinned $s.modules.store.pinned $true $s.currentRGB
        $script:StoreUiKey=$storeKey
    }
    $script:Initialized=$true
    Sync-NativeInputSinks $true
}

function Get-TaggedHit($moduleId,$screenPoint){
    try{
        $w=$script:Windows[[string]$moduleId]
        if($null -eq $w -or -not $w.IsVisible){return $null}
        $local=$w.PointFromScreen($screenPoint)
        $hit=$w.InputHitTest($local)
        while($null -ne $hit){
            try{
                if($hit -is [System.Windows.FrameworkElement]){
                    $tag=$hit.Tag
                    if($tag -is [System.Collections.IDictionary] -and $tag.Contains('kind')){return $tag}
                }
            }catch{}
            $parent=$null
            try{$parent=[System.Windows.Media.VisualTreeHelper]::GetParent($hit)}catch{}
            if($null -eq $parent){try{$parent=[System.Windows.LogicalTreeHelper]::GetParent($hit)}catch{}}
            $hit=$parent
        }
    }catch{}
    return $null
}

function Start-LayoutDrag($moduleId,$screenPoint,[bool]$native=$false){
    if($script:State -and $script:State.overlay.locked){return}
    try{
        $mw=$script:Windows[[string]$moduleId]
        if($null -ne $mw){
            $script:LayoutDrag=@{id=[string]$moduleId;startScreen=$screenPoint;startLeft=[double]$mw.Left;startTop=[double]$mw.Top;native=$native}
            $script:LastInputActivity=Get-Date
        }
    }catch{}
}
function Start-SelectDrag($moduleId,$screenPoint,[bool]$native=$false){
    try{
        $mid=[string]$moduleId;$b=$script:C[$mid].bar;if($null -eq $b){return}
        $p=Point-FromScreen $b.root $screenPoint;if($null -eq $p){return}
        $w=[double]$b.root.ActualWidth;if($w -le 0){$w=[double]$b.root.Width};if($w -le 0){return}
        $t=Interaction-T (Clamp ($p.X/$w) 0 1)
        $script:SelectDrag=@{module=$mid;lastT=$t;native=$native};$script:LastInputActivity=Get-Date
        Set-Marker $b $t;Send-Command @{type='interactionBegin';module=$mid};$script:LastInteractionPulse=Get-Date
    }catch{}
}
function Start-AnchorDrag($tag,$screenPoint,[bool]$native=$false){
    try{
        $b=$script:C.harmony.bar;$p=Point-FromScreen $b.root $screenPoint;if($null -eq $p){return}
        $script:AnchorDrag=@{id=[string]$tag['id'];startX=[double]$p.X;startDegree=[double]$tag['degree'];lastDegree=[double]$tag['degree'];native=$native}
        $script:LastInputActivity=Get-Date;Send-Command @{type='interactionBegin';module='anchorLine'}
    }catch{}
}
function Handle-NativeButtonDown($evt,[bool]$right){
    $sp=[System.Windows.Point]::new([double]$evt.X,[double]$evt.Y)
    $tag=Get-TaggedHit ([string]$evt.ModuleId) $sp
    if($null -eq $tag){return}
    $kind=[string]$tag['kind']
    if($right){
        if($kind -eq 'anchor'){Send-Command @{type='deleteAnchor';id=[string]$tag['id']};return}
        if($kind -eq 'select' -and [string]$tag['module'] -eq 'harmony'){
            try{
                if($null -ne $script:State -and [string]$script:State.modules.harmony.mode -eq 'Custom'){
                    $b=$script:C.harmony.bar;$p=Point-FromScreen $b.root $sp;$w=[double]$b.root.ActualWidth;if($w -le 0){$w=[double]$b.root.Width}
                    if($null -ne $p -and $w -gt 0){Send-Command @{type='addAnchor';t=(Clamp ($p.X/$w) 0 1)}}
                }
            }catch{}
            return
        }
        if($kind -eq 'storeColor'){
            $rgb=@{r=[int]$tag['r'];g=[int]$tag['g'];b=[int]$tag['b']}
            if([bool]$tag['pinned']){Send-Command @{type='deletePinned';rgb=$rgb}}else{Send-Command @{type='pinColor';rgb=$rgb}}
        }
        return
    }
    $tracked=$false;try{$tracked=[bool]$evt.GlobalTracked}catch{}
    switch($kind){
        'layout' {Start-LayoutDrag ([string]$tag['id']) $sp $tracked;break}
        'select' {Start-SelectDrag ([string]$tag['module']) $sp $tracked;break}
        'anchor' {Start-AnchorDrag $tag $sp $tracked;break}
        'harmonyMode' {Send-Command @{type='harmonyMode';mode=[string]$tag['mode']};break}
        'harmonySwatch' {Send-Command @{type='select';module='harmony';t=[double]$tag['pos']};break}
        'pinCurrent' {Send-Command @{type='pinCurrent'};break}
        'clearHistory' {Send-Command @{type='clearHistory'};break}
        'storeColor' {
            $src=$(if([bool]$tag['pinned']){'pinned'}else{'history'})
            Send-Command @{type='useColor';source=$src;rgb=@{r=[int]$tag['r'];g=[int]$tag['g'];b=[int]$tag['b']}}
            break
        }
    }
}
function Native-DragActive {
    try{
        if($null -ne $script:LayoutDrag -and [bool]$script:LayoutDrag.native){return $true}
        if($null -ne $script:SelectDrag -and [bool]$script:SelectDrag.native){return $true}
        if($null -ne $script:AnchorDrag -and [bool]$script:AnchorDrag.native){return $true}
    }catch{}
    return $false
}
function Apply-NativeDragPoint($evt){
    if(-not (Native-DragActive)){return}
    $sp=[System.Windows.Point]::new([double]$evt.X,[double]$evt.Y)
    $script:LastInputActivity=Get-Date

    if($null -ne $script:LayoutDrag -and [bool]$script:LayoutDrag.native){
        try{
            $d=$script:LayoutDrag;$w=$script:Windows[[string]$d.id]
            if($null -ne $w){
                $src=[System.Windows.PresentationSource]::FromVisual($w)
                $dx=$sp.X-$d.startScreen.X;$dy=$sp.Y-$d.startScreen.Y
                if($null -ne $src -and $null -ne $src.CompositionTarget){
                    $v=$src.CompositionTarget.TransformFromDevice.Transform([System.Windows.Vector]::new($dx,$dy));$dx=$v.X;$dy=$v.Y
                }
                $w.Left=[double]$d.startLeft+$dx;$w.Top=[double]$d.startTop+$dy
            }
        }catch{}
    }

    if($null -ne $script:SelectDrag -and [bool]$script:SelectDrag.native){
        try{
            $d=$script:SelectDrag;$mid=[string]$d.module;$b=$script:C[$mid].bar
            if($null -ne $b){
                $p=Point-FromScreen $b.root $sp;$w=[double]$b.root.ActualWidth;if($w -le 0){$w=[double]$b.root.Width}
                if($null -ne $p -and $w -gt 0){$t=Interaction-T (Clamp ($p.X/$w) 0 1);$d.lastT=$t;Set-Marker $b $t}
            }
            if(((Get-Date)-$script:LastInteractionPulse).TotalMilliseconds -ge 800){$script:LastInteractionPulse=Get-Date;Send-Command @{type='interactionBegin';module=$mid}}
        }catch{}
    }

    if($null -ne $script:AnchorDrag -and [bool]$script:AnchorDrag.native){
        try{
            $d=$script:AnchorDrag;$b=$script:C.harmony.bar
            if($null -ne $b){
                $p=Point-FromScreen $b.root $sp
                if($null -ne $p){$deg=[double]$d.startDegree+(($p.X-[double]$d.startX)/[double]$b.root.Width*360);$deg=Quantize-Degree $deg;$d.lastDegree=$deg
                    if(((Get-Date)-$script:LastAnchorSend).TotalMilliseconds -ge 35){$script:LastAnchorSend=Get-Date;Send-Command @{type='setAnchorDegree';id=[string]$d.id;degree=$deg;final=$false}}
                }
            }
        }catch{}
    }
}
function Finish-NativeDrag($evt){
    if(-not (Native-DragActive)){return}
    if($null -ne $evt){Apply-NativeDragPoint $evt}
    if($null -ne $script:LayoutDrag -and [bool]$script:LayoutDrag.native){Save-Layout;$script:LayoutDrag=$null}
    if($null -ne $script:SelectDrag -and [bool]$script:SelectDrag.native){
        try{$d=$script:SelectDrag;$t=[double]$d.lastT;$mid=[string]$d.module;$script:SelectDrag=$null;Send-Command @{type='select';module=$mid;t=$t}}catch{$script:SelectDrag=$null;Send-Command @{type='interactionEnd'}}
    }
    if($null -ne $script:AnchorDrag -and [bool]$script:AnchorDrag.native){
        try{$d=$script:AnchorDrag;$deg=[double]$d.lastDegree;$aid=[string]$d.id;$script:AnchorDrag=$null;Send-Command @{type='setAnchorDegree';id=$aid;degree=$deg;final=$true}}catch{$script:AnchorDrag=$null;Send-Command @{type='interactionEnd'}}
    }
}
function Process-NativeInputEvents {
    try{
        $events=[LHSNativeInput]::Drain()
        $pendingMove=$null
        foreach($evt in $events){
            $msg=[int]$evt.Message
            if($msg -eq 0x0200){$pendingMove=$evt;continue}
            if($null -ne $pendingMove){Apply-NativeDragPoint $pendingMove;$pendingMove=$null}
            switch($msg){
                0x0201 {Handle-NativeButtonDown $evt $false;break}
                0x0203 {Handle-NativeButtonDown $evt $false;break}
                0x0202 {Finish-NativeDrag $evt;break}
                0x0204 {Handle-NativeButtonDown $evt $true;break}
                0x0206 {Handle-NativeButtonDown $evt $true;break}
            }
        }
        if($null -ne $pendingMove){Apply-NativeDragPoint $pendingMove}
    }catch{}
}
function Ensure-NativeInputSink([string]$id){
    try{
        if($script:PhotoshopMainHwnd -eq [IntPtr]::Zero){return [IntPtr]::Zero}
        if(-not $script:InputSinks.ContainsKey($id) -or $script:InputSinks[$id] -eq [IntPtr]::Zero){
            $script:InputSinks[$id]=[LHSNativeInput]::Create($id,$script:PhotoshopMainHwnd)
        }else{
            [LHSNativeInput]::SetOwner($script:InputSinks[$id],$script:PhotoshopMainHwnd)
        }
        return $script:InputSinks[$id]
    }catch{return [IntPtr]::Zero}
}
function Sync-NativeInputSinks([bool]$force=$false){
    $raise=((Get-Date)-$script:LastSinkRaise).TotalMilliseconds -ge 450
    if(-not $force -and $null -eq $script:LayoutDrag -and -not $raise){return}
    if($raise){$script:LastSinkRaise=Get-Date;$force=$true}
    foreach($id in @('hue','harmony','tone','hc','store')){
        try{
            $w=$script:Windows[$id];$h=Ensure-NativeInputSink $id
            if($h -eq [IntPtr]::Zero){continue}
            if(-not $script:HostUiActive -or $null -eq $w -or -not $w.IsVisible -or $w.ActualWidth -le 1 -or $w.ActualHeight -le 1){[LHSNativeInput]::SetBounds($h,0,0,1,1,$false,$false);continue}
            $p1=$w.PointToScreen([System.Windows.Point]::new(0,0));$p2=$w.PointToScreen([System.Windows.Point]::new($w.ActualWidth,$w.ActualHeight))
            $x=[int][math]::Round($p1.X);$y=[int][math]::Round($p1.Y);$ww=[int][math]::Ceiling($p2.X-$p1.X);$hh=[int][math]::Ceiling($p2.Y-$p1.Y)
            $top=$true;try{$top=[bool]$script:State.overlay.topmost}catch{}
            $key=('{0},{1},{2},{3},{4},{5}' -f $x,$y,$ww,$hh,$true,$top)
            if($force -or -not $script:InputSinkRects.ContainsKey($id) -or [string]$script:InputSinkRects[$id] -ne $key){
                [LHSNativeInput]::SetBounds($h,$x,$y,$ww,$hh,$true,$top);$script:InputSinkRects[$id]=$key
            }
        }catch{}
    }
}
function Destroy-NativeInputSinks {
    try{[LHSNativeInput]::StopGlobalTracking()}catch{}
    foreach($id in @($script:InputSinks.Keys)){try{[LHSNativeInput]::Destroy($script:InputSinks[$id])}catch{}}
    $script:InputSinks=@{};$script:InputSinkRects=@{}
}

function Process-InputDrag {
    # v3.1.15: keep the idle/native-input pump at 16 ms. Passive-hook drags are event-driven;
    # the 5 ms interval only drains/coalesces passive-hook move messages at up to ~200 Hz. On a
    # 120/144/165/180 Hz display this keeps the high-refresh marker path, while idle CPU
    # remains at the v3.1.12 level and pen motion no longer depends on Photoshop cursor polling.
    if(-not (Local-InputBusy)){
        try{if($null -ne $script:inputTimer -and $script:inputTimer.Interval.TotalMilliseconds -lt 15){$script:inputTimer.Interval=[TimeSpan]::FromMilliseconds(16)}}catch{}
        return
    }
    try{if($null -ne $script:inputTimer -and $script:inputTimer.Interval.TotalMilliseconds -gt 6){$script:inputTimer.Interval=[TimeSpan]::FromMilliseconds(5)}}catch{}
    # Native-sink drags are event-driven in v3.1.15 when the passive global hook is available.
    # Their move/up coordinates come from the read-only low-level hook, so do not mix them
    # with GetCursorPos/GetAsyncKeyState. If hook installation failed, native=false falls back
    # to the original polling path automatically.
    if(Native-DragActive){$script:LastInputActivity=Get-Date;return}
    $left=Left-Button-Down
    $sp=Get-CursorScreenPoint
    if(Local-InputBusy){$script:LastInputActivity=Get-Date}

    if($null -ne $script:LayoutDrag){
        if($left -and $null -ne $sp){
            try{
                $d=$script:LayoutDrag;$w=$script:Windows[[string]$d.id]
                if($null -ne $w){
                    $src=[System.Windows.PresentationSource]::FromVisual($w)
                    $dx=$sp.X-$d.startScreen.X;$dy=$sp.Y-$d.startScreen.Y
                    if($null -ne $src -and $null -ne $src.CompositionTarget){
                        $v=$src.CompositionTarget.TransformFromDevice.Transform([System.Windows.Vector]::new($dx,$dy));$dx=$v.X;$dy=$v.Y
                    }
                    $w.Left=[double]$d.startLeft+$dx;$w.Top=[double]$d.startTop+$dy
                }
            }catch{}
        }else{Save-Layout;$script:LayoutDrag=$null}
    }

    if($null -ne $script:SelectDrag){
        try{
            $d=$script:SelectDrag;$mid=[string]$d.module;$b=$script:C[$mid].bar
            if($null -ne $b -and $null -ne $sp){
                $p=Point-FromScreen $b.root $sp;$w=[double]$b.root.ActualWidth;if($w -le 0){$w=[double]$b.root.Width}
                if($null -ne $p -and $w -gt 0){$t=Interaction-T (Clamp ($p.X/$w) 0 1);$d.lastT=$t;Set-Marker $b $t}
            }
            if($left -and ((Get-Date)-$script:LastInteractionPulse).TotalMilliseconds -ge 800){$script:LastInteractionPulse=Get-Date;Send-Command @{type='interactionBegin';module=$mid}}
            if(-not $left){$t=[double]$d.lastT;$script:SelectDrag=$null;Send-Command @{type='select';module=$mid;t=$t}}
        }catch{if(-not $left){$script:SelectDrag=$null;Send-Command @{type='interactionEnd'}}}
    }

    if($null -ne $script:AnchorDrag){
        try{
            $d=$script:AnchorDrag;$b=$script:C.harmony.bar
            if($null -ne $b -and $null -ne $sp){
                $p=Point-FromScreen $b.root $sp
                if($null -ne $p){$deg=[double]$d.startDegree+(($p.X-[double]$d.startX)/[double]$b.root.Width*360);$deg=Quantize-Degree $deg;$d.lastDegree=$deg
                    if($left -and ((Get-Date)-$script:LastAnchorSend).TotalMilliseconds -ge 35){$script:LastAnchorSend=Get-Date;Send-Command @{type='setAnchorDegree';id=[string]$d.id;degree=$deg;final=$false}}
                }
            }
            if(-not $left){$deg=[double]$d.lastDegree;$aid=[string]$d.id;$script:AnchorDrag=$null;Send-Command @{type='setAnchorDegree';id=$aid;degree=$deg;final=$true}}
        }catch{if(-not $left){$script:AnchorDrag=$null;Send-Command @{type='interactionEnd'}}}
    }
}

function Local-InputBusy {
    return ($null -ne $script:LayoutDrag -or $null -ne $script:SelectDrag -or $null -ne $script:AnchorDrag)
}

function Read-StateIfChanged {
    if(-not (Test-Path $statePath)){return}
    try{$fi=Get-Item -LiteralPath $statePath;if($fi.LastWriteTimeUtc -le $script:LastStateWrite){return};$text=[IO.File]::ReadAllText($statePath);$s=$text|ConvertFrom-Json;if($null -eq $s -or $null -eq $s.modules){return};$script:LastStateWrite=$fi.LastWriteTimeUtc;Update-State $s}catch{}
}
# v3.1.12 Photoshop-bound window lifecycle.
# The HUD remains a detached process (so the CEP Control Center may close), but its
# visible/input windows are explicitly owned by the Photoshop main HWND.  A fast,
# cheap foreground/minimize poll controls presentation; the slower process/heartbeat
# poll still owns shutdown detection.
$script:SeenPhotoshopWindow = $false
$script:SeenBackendHeartbeat = $false
$script:HostMissingTicks = 0

function Get-PhotoshopHostState {
    try {
        $procs = @(Get-Process -Name Photoshop -ErrorAction SilentlyContinue)
        if ($procs.Count -eq 0) { return @{ ProcessAlive=$false; WindowAlive=$false; MainHwnd=[IntPtr]::Zero; ProcessIds=@() } }
        $main = [IntPtr]::Zero
        $ids = @()
        foreach ($p in $procs) {
            try { $ids += [int]$p.Id } catch {}
            try { if ($main -eq [IntPtr]::Zero -and $p.MainWindowHandle -ne [IntPtr]::Zero) { $main = $p.MainWindowHandle } } catch {}
        }
        return @{ ProcessAlive=$true; WindowAlive=($main -ne [IntPtr]::Zero); MainHwnd=$main; ProcessIds=$ids }
    } catch {
        # A transient query failure must never kill the HUD while Photoshop is usable.
        return @{ ProcessAlive=$true; WindowAlive=($script:PhotoshopMainHwnd -ne [IntPtr]::Zero); MainHwnd=$script:PhotoshopMainHwnd; ProcessIds=$script:PhotoshopProcessIds }
    }
}

function Test-FreshFile([string]$Path,[double]$MaxAgeMs) {
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return $false }
        $age = ([DateTime]::UtcNow - (Get-Item -LiteralPath $Path).LastWriteTimeUtc).TotalMilliseconds
        return ($age -ge 0 -and $age -le $MaxAgeMs)
    } catch { return $false }
}

function Test-ForegroundBelongsToPhotoshop([IntPtr]$mainHwnd) {
    if($mainHwnd -eq [IntPtr]::Zero){return $false}
    try{
        $fg=[LHSWin32]::GetForegroundWindow()
        if($fg -eq [IntPtr]::Zero){return $false}
        if($fg -eq $mainHwnd){return $true}
        # Dialogs/tool windows owned by Photoshop stay part of the Photoshop UI family.
        try{if([LHSWin32]::GetAncestor($fg,3) -eq $mainHwnd){return $true}}catch{} # GA_ROOTOWNER=3
        $fgPid=[uint32]0
        [LHSWin32]::GetWindowThreadProcessId($fg,[ref]$fgPid)|Out-Null
        foreach($id in @($script:PhotoshopProcessIds)){if([uint32]$id -eq $fgPid){return $true}}
    }catch{}
    return $false
}

function Bind-HudToPhotoshop([bool]$force=$false) {
    $owner=$script:PhotoshopMainHwnd
    if($owner -eq [IntPtr]::Zero){return}
    if(-not $force -and $script:BoundOwnerHwnd -eq $owner){return}
    foreach($w in @($script:Windows.Values)){
        try{
            $h=([System.Windows.Interop.WindowInteropHelper]::new($w)).Handle
            if($h -ne [IntPtr]::Zero){[LHSWin32]::SetOwner($h,$owner)|Out-Null}
        }catch{}
    }
    foreach($id in @($script:InputSinks.Keys)){
        try{[LHSNativeInput]::SetOwner($script:InputSinks[$id],$owner)}catch{}
    }
    $script:BoundOwnerHwnd=$owner
}

function Refresh-HudHostVisibility {
    if($null -eq $script:State){
        if(-not $script:HostUiActive){foreach($w in @($script:Windows.Values)){try{if($w.IsVisible){$w.Hide()}}catch{}}}
        Sync-NativeInputSinks $true
        return
    }
    foreach($id in @('hue','harmony','tone','hc','store')){
        try{Update-ModuleVisibility $id $script:State.modules.$id.visible $script:State.overlay}catch{}
    }
    Sync-NativeInputSinks $true
}

function Raise-HudAbovePhotoshop([bool]$force=$false) {
    if(-not $script:HostUiActive){return}
    if(-not $force -and ((Get-Date)-$script:LastHostRaise).TotalMilliseconds -lt 500){return}
    $script:LastHostRaise=Get-Date
    $top=$true
    try{$top=[bool]$script:State.overlay.topmost}catch{}
    Bind-HudToPhotoshop
    foreach($w in @($script:Windows.Values)){
        try{
            if(-not $w.IsVisible){continue}
            $w.Topmost=$top
            $h=([System.Windows.Interop.WindowInteropHelper]::new($w)).Handle
            if($h -ne [IntPtr]::Zero){[LHSWin32]::RaiseNoActivate($h,$top)}
        }catch{}
    }
    Sync-NativeInputSinks $true
}

function Update-PhotoshopFollowState {
    $main=$script:PhotoshopMainHwnd
    if($main -eq [IntPtr]::Zero -or -not ([LHSWin32]::IsWindow($main))){
        if($script:HostUiActive){$script:HostUiActive=$false;Refresh-HudHostVisibility}
        return
    }
    $visible=$false;$minimized=$false
    try{$visible=[LHSWin32]::IsWindowVisible($main)}catch{}
    try{$minimized=[LHSWin32]::IsIconic($main)}catch{}
    $foreground=Test-ForegroundBelongsToPhotoshop $main
    # Follow Photoshop like a native tool palette: hidden when PS is minimized or another
    # application owns the foreground; restored immediately when Photoshop becomes active.
    $active=($visible -and -not $minimized -and $foreground)
    $changed=($active -ne $script:HostUiActive -or $minimized -ne $script:HostMinimized)
    $script:HostMinimized=$minimized
    if($changed){
        $script:HostUiActive=$active
        if($active){Bind-HudToPhotoshop $true}
        Refresh-HudHostVisibility
        if($active){Raise-HudAbovePhotoshop $true}
    }elseif($active){
        Raise-HudAbovePhotoshop
    }
}

function Shutdown-Hud {
    try { Destroy-NativeInputSinks } catch {}
    try { foreach($w in @($script:Windows.Values)){ $w.Close() } } catch {}
    try { [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown() } catch {}
}

function Check-HostLifecycle {
    $hostState = Get-PhotoshopHostState
    $backendFresh = Test-FreshFile $backendHeartbeatPath 3800
    if ($backendFresh) { $script:SeenBackendHeartbeat = $true }
    if ([bool]$hostState.WindowAlive) {
        $script:SeenPhotoshopWindow = $true
        $newHwnd=[IntPtr]$hostState.MainHwnd
        $newIds=@($hostState.ProcessIds)
        $ownerChanged=($newHwnd -ne [IntPtr]::Zero -and $newHwnd -ne $script:PhotoshopMainHwnd)
        $script:PhotoshopMainHwnd=$newHwnd
        $script:PhotoshopProcessIds=$newIds
        if($ownerChanged){$script:BoundOwnerHwnd=[IntPtr]::Zero;Bind-HudToPhotoshop $true}
    }

    # Once Photoshop has no process at all there is no reason for a detached HUD to stay.
    if (-not [bool]$hostState.ProcessAlive) { Shutdown-Hud; return }

    # During normal startup MainWindowHandle may be zero for a moment, so only treat a
    # missing window as shutdown after we have already observed the real Photoshop window.
    $windowGone = ($script:SeenPhotoshopWindow -and -not [bool]$hostState.WindowAlive)
    # The invisible CEP backend dies with Photoshop.  Use its heartbeat as confirmation /
    # fallback for shutdown states where Photoshop.exe is still lingering in Task Manager.
    $backendGone = ($script:SeenBackendHeartbeat -and -not $backendFresh)

    if ($windowGone -or $backendGone) {
        $script:HostMissingTicks++
        if ($script:HostMissingTicks -ge 2) { Shutdown-Hud }
    } else {
        $script:HostMissingTicks = 0
    }
    Update-PhotoshopFollowState
}

function Heartbeat { try{[IO.File]::WriteAllText($heartbeatPath,([DateTime]::UtcNow.Ticks.ToString()),$utf8NoBom)}catch{} }

# Resolve Photoshop before the WPF HWNDs are first shown so their owner relationship is
# established from the beginning rather than repaired after a z-order race.
$initialHost=Get-PhotoshopHostState
if([bool]$initialHost.WindowAlive){$script:PhotoshopMainHwnd=[IntPtr]$initialHost.MainHwnd;$script:PhotoshopProcessIds=@($initialHost.ProcessIds);$script:SeenPhotoshopWindow=$true}
Build-UI
$script:inputTimer=New-Object System.Windows.Threading.DispatcherTimer
$script:inputTimer.Interval=[TimeSpan]::FromMilliseconds(16)
$script:inputTimer.Add_Tick({Process-NativeInputEvents;Process-InputDrag;Sync-NativeInputSinks})
$script:inputTimer.Start()
$timer=New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval=[TimeSpan]::FromMilliseconds(80)
$timer.Add_Tick({if((-not (Local-InputBusy)) -and ((Get-Date)-$script:LastInputActivity).TotalMilliseconds -gt 35){Read-StateIfChanged};if(((Get-Date)-$script:LastHeartbeat).TotalMilliseconds -gt 900){$script:LastHeartbeat=Get-Date;Heartbeat}})
$timer.Start()
# Fast host-follow timer uses only cached HWND Win32 calls (no process scan), so minimizing,
# Alt-Tabbing and restoring Photoshop updates the HUD within ~120 ms without pen-path cost.
$follow=New-Object System.Windows.Threading.DispatcherTimer
$follow.Interval=[TimeSpan]::FromMilliseconds(120)
$follow.Add_Tick({Update-PhotoshopFollowState})
$follow.Start()
$life=New-Object System.Windows.Threading.DispatcherTimer
$life.Interval=[TimeSpan]::FromSeconds(1.0)
$life.Add_Tick({Check-HostLifecycle})
$life.Start()
# Prime lifecycle/follow state immediately instead of waiting for the first timer tick.
Check-HostLifecycle
Update-PhotoshopFollowState
Heartbeat
try{[System.Windows.Threading.Dispatcher]::Run()}finally{Destroy-NativeInputSinks;try{Remove-Item -LiteralPath $heartbeatPath -Force}catch{};try{$mutex.ReleaseMutex()}catch{};$mutex.Dispose()}
